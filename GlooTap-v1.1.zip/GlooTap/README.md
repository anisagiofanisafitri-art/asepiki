# GlooTap v1.2
Tombol melayang yang mengirim tap cepat ke titik yang kamu tentukan (misal tombol gloo wall).
- sampai 4 tombol, masing-masing punya target, jumlah tap, jeda, dan mode tahan (spam)
- opsi tampil hanya saat Free Fire dibuka
- ukuran dan transparansi tombol bisa diatur
- tanpa root, tanpa PC, tanpa izin overlay (AccessibilityService + TYPE_ACCESSIBILITY_OVERLAY)

Build: push ke GitHub (branch main), buka tab Actions, unduh artifact `GlooTap-apk`.
