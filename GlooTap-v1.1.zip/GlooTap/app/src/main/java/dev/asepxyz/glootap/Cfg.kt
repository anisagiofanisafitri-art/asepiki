package dev.asepxyz.glootap

import android.content.Context

object Cfg {
    const val SLOTS = 4

    private fun sp(c: Context) = c.getSharedPreferences("glootap", Context.MODE_PRIVATE)

    // ---- pengaturan per tombol (slot 0..3) ----
    fun slotOn(c: Context, i: Int) = sp(c).getBoolean("s${i}_on", i == 0)
    fun slotTaps(c: Context, i: Int) = sp(c).getInt("s${i}_taps", 2).coerceIn(1, 10)
    fun slotGap(c: Context, i: Int) = sp(c).getInt("s${i}_gap", 25).coerceIn(5, 500)
    fun slotHold(c: Context, i: Int) = sp(c).getBoolean("s${i}_hold", false)

    fun setSlot(c: Context, i: Int, on: Boolean, taps: Int, gap: Int, hold: Boolean) {
        sp(c).edit()
            .putBoolean("s${i}_on", on)
            .putInt("s${i}_taps", taps.coerceIn(1, 10))
            .putInt("s${i}_gap", gap.coerceIn(5, 500))
            .putBoolean("s${i}_hold", hold)
            .apply()
    }

    // ---- pengaturan umum ----
    fun overlayOn(c: Context) = sp(c).getBoolean("overlay_on", true)
    fun setOverlayOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("overlay_on", on).apply()
    }

    fun autoHide(c: Context) = sp(c).getBoolean("autohide", false)
    fun setAutoHide(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("autohide", on).apply()
    }

    fun size(c: Context) = sp(c).getInt("size", 56).coerceIn(36, 96)
    fun alpha(c: Context) = sp(c).getInt("alpha", 70).coerceIn(20, 100)
    fun setLook(c: Context, size: Int, alpha: Int) {
        sp(c).edit()
            .putInt("size", size.coerceIn(36, 96))
            .putInt("alpha", alpha.coerceIn(20, 100))
            .apply()
    }

    // ---- pengaturan cepat dari panel gerigi ----
    fun setSlotOn(c: Context, i: Int, on: Boolean) {
        sp(c).edit().putBoolean("s${i}_on", on).apply()
    }
    fun setSlotTaps(c: Context, i: Int, v: Int) {
        sp(c).edit().putInt("s${i}_taps", v.coerceIn(1, 10)).apply()
    }
    fun setSlotGap(c: Context, i: Int, v: Int) {
        sp(c).edit().putInt("s${i}_gap", v.coerceIn(5, 500)).apply()
    }
    fun setSlotHold(c: Context, i: Int, on: Boolean) {
        sp(c).edit().putBoolean("s${i}_hold", on).apply()
    }

    // kunci posisi tombol merah (false = bisa digeser)
    fun locked(c: Context) = sp(c).getBoolean("locked", false)
    fun setLocked(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("locked", on).apply()
    }

    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("haptic", on).apply()
    }

    // posisi disimpan per orientasi (l = landscape, p = portrait), -1 = belum diatur
    fun getPos(c: Context, key: String, land: Boolean): Pair<Int, Int> {
        val o = if (land) "l" else "p"
        val s = sp(c)
        return Pair(s.getInt("${key}_x_$o", -1), s.getInt("${key}_y_$o", -1))
    }

    fun setPos(c: Context, key: String, land: Boolean, x: Int, y: Int) {
        val o = if (land) "l" else "p"
        sp(c).edit().putInt("${key}_x_$o", x).putInt("${key}_y_$o", y).apply()
    }
}
