package dev.asepxyz.glootap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class GlooService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GlooService? = null

        private val GAME_PKGS = setOf("com.dts.freefireth", "com.dts.freefiremax")
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var slots: List<Slot> = emptyList()
    private var gearView: TextView? = null
    private var panel: ScrollView? = null
    private var built = false
    private var inGame = false

    // ---------- util ----------

    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val isLand: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun circle(fill: Int, strokePx: Int = 0, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    private fun rect(fill: Int, radiusPx: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = radiusPx.toFloat()
        }

    private fun baseLp(w: Int, h: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- lifecycle ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshOverlay()
    }

    private val hideRunnable = Runnable {
        if (inGame) {
            inGame = false
            refreshOverlay()
        }
    }

    // jendela pihak ketiga yang sering muncul saat login game (Garena, Google, Facebook, dll)
    private fun isLoginWindow(pkg: String): Boolean =
        pkg.contains("garena") || pkg.contains("google") || pkg.contains("gms") ||
            pkg.contains("facebook") || pkg.contains("vk.") || pkg.contains("twitter") ||
            pkg.contains("webview") || pkg.contains("chrome") || pkg.contains("permissioncontroller")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // abaikan jendela sistem / keyboard / app ini sendiri supaya tombol tidak kedip
        if (pkg == packageName || pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") || pkg.contains("keyboard")
        ) return

        if (pkg in GAME_PKGS) {
            handler.removeCallbacks(hideRunnable)
            if (!inGame) {
                inGame = true
                refreshOverlay()
            }
        } else if (inGame && !isLoginWindow(pkg)) {
            // app lain beneran dibuka: sembunyikan setelah jeda, bukan langsung
            handler.removeCallbacks(hideRunnable)
            handler.postDelayed(hideRunnable, 2500)
        }
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (built) reload()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardownOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardownOverlay()
        instance = null
        super.onDestroy()
    }

    // ---------- overlay ----------

    fun reload() {
        teardownOverlay()
        refreshOverlay()
    }

    private fun refreshOverlay() {
        val want = Cfg.overlayOn(this) && (!Cfg.autoHide(this) || inGame)
        if (want && !built) buildOverlay()
        else if (!want && built) teardownOverlay()
    }

    private fun buildOverlay() {
        built = true
        buildSlots()
        showGear()
    }

    private fun buildSlots() {
        val list = ArrayList<Slot>()
        for (i in 0 until Cfg.SLOTS) {
            if (Cfg.slotOn(this, i)) {
                val s = Slot(i)
                s.show()
                list.add(s)
            }
        }
        slots = list
    }

    private fun refreshSlots() {
        slots.forEach { it.remove() }
        buildSlots()
    }

    private fun teardownOverlay() {
        closePanel()
        slots.forEach { it.remove() }
        slots = emptyList()
        gearView?.let { runCatching { wm.removeView(it) } }
        gearView = null
        built = false
    }

    // ---------- gerigi + panel ----------

    private fun showGear() {
        val (sw, sh) = screenSize()
        val size = px(30)
        val g = TextView(this).apply {
            text = "\u2699"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            background = circle(Color.argb(150, 40, 40, 40))
        }
        val (gx, gy) = Cfg.getPos(this, "gear", isLand)
        val lp = baseLp(size, size).apply {
            x = if (gx >= 0) gx else (sw * 0.82f).toInt()
            y = if (gy >= 0) gy else (sh * 0.08f).toInt()
        }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        g.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (moved || abs(dx) > slop || abs(dy) > slop) {
                        moved = true
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(g, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Cfg.setPos(this, "gear", isLand, lp.x, lp.y) else togglePanel()
                }
            }
            true
        }
        gearView = g
        wm.addView(g, lp)
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else showPanel()
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        gearView?.background = circle(Color.argb(150, 40, 40, 40))
    }

    private fun lbl(text: String, sizeSp: Float = 13f, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = sizeSp
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun chip(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(px(14), px(6), px(14), px(6))
        background = rect(Color.rgb(70, 70, 82), px(10))
        setOnClickListener { onClick() }
    }

    private fun rowBox() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, px(4), 0, px(4))
    }

    private fun stepRow(name: String, value: () -> String, change: (Int) -> Unit): LinearLayout {
        val row = rowBox()
        val v = lbl(value(), 14f, true)
        v.gravity = Gravity.CENTER
        v.setMinWidth(px(52))
        row.addView(lbl(name), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(chip("\u2212") {
            change(-1)
            v.text = value()
        })
        row.addView(v)
        row.addView(chip("+") {
            change(1)
            v.text = value()
        })
        return row
    }

    private fun toggleRow(name: String, read: () -> Boolean, write: (Boolean) -> Unit): LinearLayout {
        val row = rowBox()
        val state = chip("") {}
        fun paint() {
            val on = read()
            state.text = if (on) "ON" else "OFF"
            state.background = rect(
                if (on) Color.rgb(46, 160, 67) else Color.rgb(90, 90, 100),
                px(10)
            )
        }
        state.setOnClickListener {
            write(!read())
            paint()
        }
        paint()
        row.addView(lbl(name), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(state)
        return row
    }

    private fun showPanel() {
        val ctx = this
        val (sw, sh) = screenSize()
        val width = minOf(px(300), (sw * 0.9f).toInt())

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(14), px(16), px(14))
            background = rect(Color.argb(240, 28, 28, 36), px(16))
        }
        box.addView(lbl("GlooTap", 17f, true))

        box.addView(toggleRow("Kunci posisi tombol merah", { Cfg.locked(ctx) }) { on ->
            Cfg.setLocked(ctx, on)
            slots.forEach { it.applyLock() }
        })
        box.addView(toggleRow("Getar saat ditekan", { Cfg.haptic(ctx) }) { on ->
            Cfg.setHaptic(ctx, on)
        })
        box.addView(toggleRow("Hanya tampil saat Free Fire", { Cfg.autoHide(ctx) }) { on ->
            Cfg.setAutoHide(ctx, on)
        })
        box.addView(stepRow("Ukuran tombol", { Cfg.size(ctx).toString() }) { d ->
            Cfg.setLook(ctx, Cfg.size(ctx) + d * 4, Cfg.alpha(ctx))
            slots.forEach { it.applyLook() }
        })
        box.addView(stepRow("Transparansi (%)", { Cfg.alpha(ctx).toString() }) { d ->
            Cfg.setLook(ctx, Cfg.size(ctx), Cfg.alpha(ctx) + d * 10)
            slots.forEach { it.applyLook() }
        })

        for (i in 0 until Cfg.SLOTS) {
            val title = if (i == 0) "Tombol 1 (GW)" else "Tombol ${i + 1}"
            box.addView(toggleRow(title, { Cfg.slotOn(ctx, i) }) { on ->
                Cfg.setSlotOn(ctx, i, on)
                refreshSlots()
                closePanel()
                showPanel()
            })
            if (Cfg.slotOn(ctx, i)) {
                box.addView(stepRow("    Jumlah tap", { Cfg.slotTaps(ctx, i).toString() }) { d ->
                    Cfg.setSlotTaps(ctx, i, Cfg.slotTaps(ctx, i) + d)
                })
                box.addView(stepRow("    Jeda (ms)", { Cfg.slotGap(ctx, i).toString() }) { d ->
                    Cfg.setSlotGap(ctx, i, Cfg.slotGap(ctx, i) + d * 10)
                })
                box.addView(toggleRow("    Mode tahan (spam terus)", { Cfg.slotHold(ctx, i) }) { on ->
                    Cfg.setSlotHold(ctx, i, on)
                })
            }
        }

        val close = chip("Tutup") { closePanel() }
        val closeLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        closeLp.topMargin = px(10)
        box.addView(close, closeLp)

        box.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = minOf(box.measuredHeight, (sh * 0.85f).toInt())

        val scroll = ScrollView(ctx)
        scroll.addView(box)
        val lp = baseLp(width, h)
        lp.gravity = Gravity.CENTER
        panel = scroll
        gearView?.background = circle(Color.argb(230, 255, 193, 7))
        wm.addView(scroll, lp)
    }

    // ---------- satu tombol merah (tap jatuh tepat di bawah tombol ini) ----------

    private inner class Slot(val idx: Int) {
        private val label = if (idx == 0) "GW" else "${idx + 1}"
        private val btnSize: Int
            get() = px(Cfg.size(this@GlooService))

        private var trigger: TextView? = null
        private var trigLp: WindowManager.LayoutParams? = null
        private var busy = false
        private var lastFire = 0L
        private var holding = false
        private var holdStart = 0L
        private var gesture: GestureDescription? = null

        private val release = Runnable { setPass(false) }

        private val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                busy = false
                handler.post { next() }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                busy = false
                handler.postDelayed({ next() }, 10)
            }
        }

        // mode tahan: kirim batch tap lagi selama jari masih menempel (maks 30 detik sebagai pengaman)
        private fun next() {
            val g = gesture
            if (holding && g != null && SystemClock.uptimeMillis() - holdStart < 30000L) {
                busy = true
                if (!dispatchGesture(g, cb, null)) {
                    busy = false
                    holding = false
                    handler.post(release)
                }
            } else {
                holding = false
                handler.postDelayed(release, 30)
            }
        }

        private fun paint() {
            val t = trigger ?: return
            val ctx = this@GlooService
            val red = Color.argb(255, 229, 57, 53)
            // terkunci: merah polos. tidak terkunci: ada cincin kuning, bisa digeser
            t.background = if (Cfg.locked(ctx)) circle(red) else circle(red, px(3), Color.YELLOW)
            t.alpha = Cfg.alpha(ctx) / 100f
        }

        fun applyLock() {
            paint()
        }

        fun applyLook() {
            val t = trigger ?: return
            val lp = trigLp ?: return
            val ns = btnSize
            // ukuran berubah dari tengah, jadi titik tap tidak bergeser jauh
            lp.x -= (ns - lp.width) / 2
            lp.y -= (ns - lp.height) / 2
            lp.width = ns
            lp.height = ns
            paint()
            runCatching { wm.updateViewLayout(t, lp) }
            saveLayout()
        }

        fun show() {
            val ctx = this@GlooService
            val (sw, sh) = screenSize()
            val t = TextView(ctx).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            val (sx, sy) = Cfg.getPos(ctx, "t$idx", isLand)
            val lp = baseLp(btnSize, btnSize).apply {
                x = if (sx >= 0) sx else (sw * 0.82f).toInt()
                y = if (sy >= 0) sy else (sh * (0.2f + 0.18f * idx)).toInt()
            }
            val slop = ViewConfiguration.get(ctx).scaledTouchSlop
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            t.setOnTouchListener { _, ev ->
                val locked = Cfg.locked(ctx)
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                        if (locked) {
                            t.scaleX = 0.9f
                            t.scaleY = 0.9f
                            if (Cfg.haptic(ctx)) {
                                t.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                            }
                            // langsung tembak saat ditekan, tanpa nunggu jari diangkat
                            holding = Cfg.slotHold(ctx, idx)
                            holdStart = SystemClock.uptimeMillis()
                            fire()
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!locked) {
                            val dx = ev.rawX - downX
                            val dy = ev.rawY - downY
                            if (moved || abs(dx) > slop || abs(dy) > slop) {
                                moved = true
                                lp.x = startX + dx.toInt()
                                lp.y = startY + dy.toInt()
                                wm.updateViewLayout(t, lp)
                            }
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        t.scaleX = 1f
                        t.scaleY = 1f
                        if (!locked) {
                            if (moved) saveLayout()
                        } else {
                            holding = false
                            if (!busy) handler.postDelayed(release, 30)
                        }
                    }
                }
                true
            }
            trigger = t
            trigLp = lp
            paint()
            wm.addView(t, lp)
        }

        fun saveLayout() {
            val lp = trigLp ?: return
            Cfg.setPos(this@GlooService, "t$idx", isLand, lp.x, lp.y)
        }

        fun remove() {
            holding = false
            handler.removeCallbacks(release)
            trigger?.let { runCatching { wm.removeView(it) } }
            trigger = null
        }

        // tombol dibuat tembus sentuh sebentar supaya tap buatan jatuh ke game di bawahnya,
        // bukan ke tombol merah ini sendiri
        private fun setPass(on: Boolean) {
            val t = trigger ?: return
            val lp = trigLp ?: return
            lp.flags = if (on) {
                lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            runCatching { wm.updateViewLayout(t, lp) }
        }

        fun fire() {
            val t = trigger ?: return
            val ctx = this@GlooService
            val loc = IntArray(2)
            t.getLocationOnScreen(loc)
            val cx = loc[0] + t.width / 2f
            val cy = loc[1] + t.height / 2f

            val hold = Cfg.slotHold(ctx, idx)
            val max = GestureDescription.getMaxStrokeCount()
            val n = if (hold) max else Cfg.slotTaps(ctx, idx).coerceAtMost(max)
            val gap = Cfg.slotGap(ctx, idx)
            // tekan ~30 ms supaya terbaca game, jeda dihitung dari lepas ke tekan berikutnya
            val dur = 30L
            val pitch = dur + gap
            val b = GestureDescription.Builder()
            for (i in 0 until n) {
                val path = Path().apply { moveTo(cx, cy) }
                b.addStroke(GestureDescription.StrokeDescription(path, i * pitch, dur))
            }
            val total = (n - 1) * pitch + dur

            val now = SystemClock.uptimeMillis()
            if (busy && now - lastFire < total + 400) return
            busy = true
            lastFire = now
            gesture = b.build()

            setPass(true)
            handler.postDelayed({
                val g = gesture
                if (g == null || !dispatchGesture(g, cb, null)) {
                    busy = false
                    holding = false
                    setPass(false)
                    toast("Tap gagal dikirim")
                }
            }, 15)
            // pengaman untuk tap biasa: pastikan tombol bisa disentuh lagi
            if (!hold) handler.postDelayed(release, 15 + total + 400)
        }
    }
}
