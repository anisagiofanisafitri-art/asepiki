package dev.asepxyz.glootap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class SlotViews(
        val on: CheckBox,
        val taps: EditText,
        val gap: EditText,
        val hold: CheckBox
    )

    private lateinit var status: TextView
    private lateinit var cbAuto: CheckBox
    private lateinit var etSize: EditText
    private lateinit var etAlpha: EditText
    private val slotViews = ArrayList<SlotViews>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setPadding(0, dp(18), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun numberField() = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
    }

    private fun row(name: String, field: EditText): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val tv = TextView(this)
        tv.text = name
        r.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(field, LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT))
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "GlooTap v1.2"
            textSize = 24f
        })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        root.addView(button("Buka pengaturan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        for (i in 0 until Cfg.SLOTS) {
            val title = if (i == 0) "Tombol 1 (GW)" else "Tombol ${i + 1}"
            root.addView(heading(title))
            val on = CheckBox(this).apply { text = "Aktif" }
            root.addView(on)
            val taps = numberField()
            root.addView(row("Jumlah tap per tekan (1-10)", taps))
            val gap = numberField()
            root.addView(row("Jeda antar tap, ms (5-500)", gap))
            val hold = CheckBox(this).apply { text = "Mode tahan: spam terus selama ditekan" }
            root.addView(hold)
            slotViews.add(SlotViews(on, taps, gap, hold))
        }

        root.addView(heading("Tampilan"))
        etSize = numberField()
        root.addView(row("Ukuran tombol, dp (36-96)", etSize))
        etAlpha = numberField()
        root.addView(row("Transparansi, persen (20-100)", etAlpha))
        cbAuto = CheckBox(this).apply { text = "Tampilkan tombol hanya saat Free Fire dibuka" }
        root.addView(cbAuto)

        root.addView(button("Simpan semua") {
            for (i in 0 until Cfg.SLOTS) {
                val v = slotViews[i]
                Cfg.setSlot(
                    this, i,
                    v.on.isChecked,
                    v.taps.text.toString().toIntOrNull() ?: 2,
                    v.gap.text.toString().toIntOrNull() ?: 25,
                    v.hold.isChecked
                )
            }
            Cfg.setLook(
                this,
                etSize.text.toString().toIntOrNull() ?: 56,
                etAlpha.text.toString().toIntOrNull() ?: 70
            )
            Cfg.setAutoHide(this, cbAuto.isChecked)
            GlooService.instance?.reload()
            refresh()
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
        })

        root.addView(heading("Tombol melayang"))
        root.addView(button("Tampilkan") {
            Cfg.setOverlayOn(this, true)
            GlooService.instance?.reload()
        })
        root.addView(button("Sembunyikan") {
            Cfg.setOverlayOn(this, false)
            GlooService.instance?.reload()
        })

        root.addView(TextView(this).apply {
            text = "Cara pakai:\n" +
                "1. Aktifkan layanan GlooTap di Aksesibilitas.\n" +
                "2. Buka game. Tombol merah (cincin kuning = bisa digeser) tinggal ditaruh TEPAT di atas tombol gloo wall aslinya.\n" +
                "3. Tap gerigi kecil, nyalakan Kunci posisi, lalu tutup. Cincin kuning hilang berarti sudah terkunci.\n" +
                "4. Tekan tombol merah: tap otomatis jatuh di tempat tombol itu berada. Jumlah tap, jeda, ukuran, dan lainnya diatur dari panel gerigi.\n\n" +
                "Catatan: jeda 80-150 ms biasanya paling aman buat game. Posisi tersimpan terpisah untuk portrait dan landscape."
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = if (GlooService.instance != null)
            "Status: layanan aktif"
        else
            "Status: layanan belum aktif. Nyalakan GlooTap di pengaturan Aksesibilitas."
        for (i in 0 until Cfg.SLOTS) {
            val v = slotViews[i]
            v.on.isChecked = Cfg.slotOn(this, i)
            v.taps.setText(Cfg.slotTaps(this, i).toString())
            v.gap.setText(Cfg.slotGap(this, i).toString())
            v.hold.isChecked = Cfg.slotHold(this, i)
        }
        etSize.setText(Cfg.size(this).toString())
        etAlpha.setText(Cfg.alpha(this).toString())
        cbAuto.isChecked = Cfg.autoHide(this)
    }
}
