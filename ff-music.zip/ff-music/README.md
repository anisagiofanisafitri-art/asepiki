# FF Music v3.7
Floating music player buat main game (Free Fire dkk) — album per suasana, booster HP, Mode Game.

## Fitur
- **Album** (Santai, Bantai, bikin sendiri): kelompokin lagu per suasana, pindah antar album, urutin.
- **Cari lagu** langsung dari app (YouTube Music via Piped), atau tulis judul / tempel link / upload file HP.
- **Bagikan album ke teman** lewat kode teks (`ffm1:...`) — teman tinggal Impor. File upload tidak ikut.
- **Floating player**: bubble geser (posisi diingat), kontrol, volume musik sendiri, timer tidur, info baterai/suhu/RAM.
- **Mode Game**: 1 tombol = animasi layar penuh + boost RAM + Jangan Ganggu total (telepon, chat & notif dibungkam, musik/game & alarm tetap jalan) + nyalain musik + buka game.
- **Booster**: tutup app background (non-sistem) biar RAM lega.
- **Equalizer** (Normal/Bass/Vokal/Treble) + Kenceng+, layar tetap nyala, pause otomatis kalau headset dicabut.
- Cache lagu offline (maks 300 MB).

### Baru di v3.7: Video bisa dimiringin
- Video tegak (TikTok, Shorts) sekarang **ikut posisi HP**: miringin HP, layar langsung mendatar. Dulu video tegak dikunci tegak. Video mendatar tetap otomatis mendatar.
- Tombol **PUTAR** di player: tiap ketuk ganti mode **MIRING** (kunci mendatar) → **TEGAK** (kunci tegak) → **AUTO** (ikut posisi HP).
- Layar **Scroll** juga bisa dimiringin (video otomatis dipas ulang ke ukuran layar).
- Catatan: mode ini ikut sensor HP walau kunci rotasi layar sistem menyala. Belum dites di HP sungguhan.

### Baru di v3.6: TikTok massal + Scroll offline ala TikTok
- Tab Video > **TikTok massal**: ketik kata kunci (atau tap preset: *jj wanglin*, *jj xiao yan*, *kata kata*), pilih **50 / 100 / 200 / 300 / 500** video, tekan **Cari & unduh**. Pencarian lewat TikWM, lalu semua video masuk antrian unduh di latar belakang (notifikasi + Batal) dan jadi **video offline**.
- Tiap kata kunci jadi satu **koleksi** di daftar Offline (1 kartu per koleksi, jadi daftar gak panjang walau 500 video). Tahan lama kartu = hapus koleksi.
- **Scroll**: geser atas = video berikutnya, geser bawah = sebelumnya, ketuk = jeda, video diulang terus sampai digeser. Tombol **Scroll** (urut, lanjut dari terakhir) dan **Acak**; ada juga **Scroll semua video offline**. Tombol Hapus di pojok untuk buang video yang jelek. Musik dipause otomatis selama nonton.
- **Hemat memori** (aktif bawaan): kualitas biasa ±5 MB per video (500 video ≈ 2,5 GB). Matikan untuk HD ±10 MB.
- Video yang sudah pernah diunduh dilewati. Kalau link hasil pencarian kedaluwarsa di tengah antrian panjang, otomatis ambil ulang lewat halaman TikTok-nya.
- Catatan jujur: TikWM gratis dibatasi 1 permintaan/detik dan kadang menolak, jadi pencarian 500 video butuh ±30 detik dan hasilnya bisa kurang dari jumlah yang diminta kalau kata kuncinya sedikit hasilnya. Belum dites di HP/jaringan sungguhan (lingkungan pembuat tanpa akses jaringan & Android SDK).

### Baru di v3.5: API YouTube & TikTok dari Videy Bot
- YouTube sekarang lewat penyedia yang sama dengan Videy Bot (`Providers.kt`): savetube → ytdlpyton → savenow → ytdown.to → ytdown.io → ytmp3.mobi. Piped jadi cadangan terakhir.
- TikTok: TikWM → yuulabs → savetik (cadangan bertingkat).
- Cari lagu langsung ke YouTube (tanpa Piped), jadi tab Tambah gak ikut mati kalau Piped mati.
- **Setelan > API sendiri**: tempel API YouTube/TikTok milikmu (pakai `{url}`, YouTube juga boleh `{fmt}` dan `{id}`) + API key bila perlu. Dicoba paling dulu.
- Catatan jujur: YouTube lewat penyedia ini 360p–1080p, satu kualitas per panggilan (ganti kualitas = ambil ulang). 1440p/4K cuma lewat Piped/Cobalt. Belum dites di HP/jaringan sungguhan (lingkungan pembuat tanpa akses jaringan & Android SDK), jadi cek dulu setelah build.

### Baru di v3.4: Video offline (disimpan di dalam app)
- Tombol **SIMPAN** di player, atau **Simpan link ke offline** di tab Video: video YouTube/TikTok/link diunduh ke penyimpanan app sesuai kualitas yang dipilih (sampai 4K), lalu bisa ditonton **tanpa internet**.
- **Upload video dari HP** otomatis disalin ke dalam app (bisa dimatiin lewat toggle), jadi tetap aman walau file aslinya dihapus.
- Unduhan jalan di **latar belakang** (notifikasi progress + tombol Batal), lanjut walau layar mati atau app ditutup. Per potongan 4 MB, kalau putus ngulang potongan itu aja.
- YouTube 720p ke atas disimpan sebagai 2 file (video + audio) dan digabung otomatis pas diputar.
- Daftar **Offline** di tab Video: ukuran per video, total memori terpakai, tahan lama untuk hapus satu, atau hapus semua.
- Catatan: siaran live/HLS belum bisa disimpan. Video disimpan di penyimpanan privat app (bukan di dalam file APK), jadi ikut hilang kalau app di-uninstall / data dihapus. Update biasa (tanda tangan sama) tidak menghapusnya.

### Baru di v3.3

**Update tanpa nabrak**
- Semua build (debug/release, laptop/GitHub) sekarang ditandatangani **kunci tetap** (`app/ffmusic.jks`). Dulu GitHub bikin kunci acak tiap build, makanya APK baru bentrok sama yang lama.
- `versionCode` naik otomatis tiap build di GitHub, dan **tiap push ke `main` otomatis jadi Release** (`v<isi version.txt>.<nomor build>`, contoh `v3.3.12`). Mau rilis versi besar: ubah `version.txt` atau push tag `v3.4`.
- **Update di dalam app** (Setelan > Update aplikasi): cek GitHub Releases, unduh dengan progress, cek tanda tangan, lalu pasang langsung nimpa app lama. Cek otomatis tiap buka app (maks 6 jam sekali).
- Kalau tanda tangan beda, app jelasin kenapa (bukan error misterius) dan kasih jalan keluar.
- PENTING, **sekali aja**: HP yang sekarang terpasang app lama (kunci acak) harus di-uninstall dulu sebelum pasang v3.3. Backup album dulu pakai tombol Bagikan di tab Album. Setelah itu semua update berikutnya langsung nimpa.
- Kalau repo ini PUBLIC, sebaiknya pakai keystore sendiri (secret `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) karena kunci di repo bisa dilihat orang. Kalau secret diisi, itu yang dipakai.

**Video (tab baru)**
- Putar dari **link YouTube**, **link TikTok**, link video langsung (.mp4 .webm .m3u8), atau **upload video dari HP** (gak disalin, langsung diputar).
- **Share langsung**: di YouTube/TikTok tekan Bagikan lalu pilih *FF Music Video*. Link youtube/tiktok juga bisa dibuka lewat app ini.
- Kualitas **144p sampai 4K** (kalau sumbernya ada). Kalau satu kualitas gagal (misal HP gak bisa decode 4K), otomatis turun satu tingkat. Bisa ganti kualitas pas nonton.
- Player fullscreen: dobel tap loncat 10 detik, geser kiri = cahaya, geser kanan = volume, kecepatan 0.5x-2x, FIT/ZOOM/PENUH, putar layar, kunci layar, PiP, lanjut dari menit terakhir, daftar terakhir diputar.
- Musik otomatis di-pause & bubble disembunyiin pas nonton, lanjut lagi setelah selesai.
- API pihak ketiga: YouTube lewat **Piped**, TikTok lewat **TikWM**. Gratis tapi kadang mati/dibatasi. Opsional isi server **Cobalt** sendiri di Setelan buat cadangan (dan situs lain).

**Perbaikan**
- Acak (shuffle) gak diem lagi setelah lagu pertama: acak sekarang tanpa ngulang sampai semua keputar, lagu rusak otomatis dilewati, dan ada pengaman kalau lagu selesai tapi gak lanjut.
- Upload banyak lagu sekaligus: nama file unik, file kosong/gagal disalin ditolak dan dilaporkan.

### Baru di v3.2: TURBO MAKSIMAL
- Layar dipaksa ke **refresh rate tertinggi** selama floating aktif (kalau HP punya layar 90/120 Hz), jadi geser & tembak lebih licin.
- **Wifi low-latency** + **CPU tetap nyala** (wake lock) biar ping & frame stabil.
- **Boost 2 putaran** (app yang bangun lagi ikut ditutup), auto-boost sampai tiap 1 menit.
- Opsional: **animasi sistem dimatiin** pas Turbo (butuh izin sekali lewat ADB, ada tombol salin perintah di Setelan).
- Tombol **TURBO** juga ada di floating player.
- Semua ikon pakai simbol Unicode polos (bukan emoji warna-warni).
- Catatan jujur: overclock CPU/GPU & touch sampling butuh root / diatur setelan HP & game, gak bisa dari app biasa.

### Baru di v3.1
- **Equalizer 5 pita custom** (60Hz–14kHz) + preset Normal/Bass/Vokal/Treble/**Game** (langkah kaki lebih jelas) + **Bass booster**, **Virtualizer 3D**, **Kenceng+** pakai slider.
- **Kecepatan putar** 0.75x–1.5x, **fade-in** tiap lagu, timer tidur sampai 90 menit.
- **Floating player**: tombol **⚡ Boost** langsung dari dalam game, ganti kecepatan & EQ 1 tap, **♥ Favorit**, bubble nempel ke tepi layar, panel gak keluar layar.
- **HUD**: baterai, suhu (merah kalau panas), RAM, dan **ping jaringan** real-time.
- **Booster+**: daftar app yang jangan ditutup, **auto-boost berkala** (3/5/10 mnt), statistik total RAM dilegakan, tes ping, peringatan Hemat Baterai & HP panas.
- **Mode Game**: Equalizer Game otomatis (balik normal pas floating dimatikan).
- **Kontrol headset / Bluetooth** & layar kunci (MediaSession).
- **Album**: urutkan A–Z, acak, balik, hapus lagu dobel; album **Favorit**; hitungan berapa kali lagu diputar.

## Build
Push ke GitHub -> tab **Actions** -> download APK di **Artifacts**.

## Rilis buat teman (link download tetap)
1. Edit `APP_URL` di `app/src/main/java/com/asep/ffmusic/Ui.kt` jadi link repo kamu.
2. Buat tag: `git tag v3.1 && git push origin v3.1` -> APK otomatis muncul di halaman **Releases**.
3. Kirim link `https://github.com/USERNAME/ff-music/releases/latest` ke teman.

### Biar teman bisa update tanpa uninstall (sangat disarankan)
Bikin keystore sekali, simpan di GitHub Secrets:
```
keytool -genkeypair -v -keystore ffm.jks -alias ffm -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 ffm.jks   # hasilnya -> secret KEYSTORE_BASE64
```
Secrets yang dibutuhkan: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (ffm), `KEY_PASSWORD`.
**Simpan file ffm.jks baik-baik** — kalau hilang, update gak bisa ditimpa.
