# FF Music v3.0
Floating music player buat main game (Free Fire dkk) — album per suasana, booster HP, Mode Game.

## Fitur
- **Album** (Santai, Bantai, bikin sendiri): kelompokin lagu per suasana, pindah antar album, urutin.
- **Cari lagu** langsung dari app (YouTube Music via Piped), atau tulis judul / tempel link / upload file HP.
- **Bagikan album ke teman** lewat kode teks (`ffm1:...`) — teman tinggal Impor. File upload tidak ikut.
- **Floating player**: bubble geser (posisi diingat), kontrol, volume musik sendiri, timer tidur, info baterai/suhu/RAM.
- **Mode Game**: 1 tombol = animasi layar penuh + boost RAM + Jangan Ganggu total (telepon, chat & notif dibungkam, musik/game & alarm tetap jalan) + nyalain musik + buka game.
- **Booster**: tutup app background (non-sistem) biar RAM lega.
- **Equalizer** (Normal/Bass/Vokal/Treble) + Kenceng+, layar tetap nyala, pause otomatis kalau headset dicabut.
- Cache lagu offline (maks 300 MB).

## Build
Push ke GitHub -> tab **Actions** -> download APK di **Artifacts**.

## Rilis buat teman (link download tetap)
1. Edit `APP_URL` di `app/src/main/java/com/asep/ffmusic/Ui.kt` jadi link repo kamu.
2. Buat tag: `git tag v3.0 && git push origin v3.0` -> APK otomatis muncul di halaman **Releases**.
3. Kirim link `https://github.com/USERNAME/ff-music/releases/latest` ke teman.

### Biar teman bisa update tanpa uninstall (sangat disarankan)
Bikin keystore sekali, simpan di GitHub Secrets:
```
keytool -genkeypair -v -keystore ffm.jks -alias ffm -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 ffm.jks   # hasilnya -> secret KEYSTORE_BASE64
```
Secrets yang dibutuhkan: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (ffm), `KEY_PASSWORD`.
**Simpan file ffm.jks baik-baik** — kalau hilang, update gak bisa ditimpa.
