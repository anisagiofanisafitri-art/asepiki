# FF Music v3.2
Floating music player buat main game (Free Fire dkk) — album per suasana, booster HP, Mode Game.

## Fitur
- **Album** (Santai, Bantai, bikin sendiri): kelompokin lagu per suasana, pindah antar album, urutin.
- **Cari lagu** langsung dari app (YouTube Music via Piped), atau tulis judul / tempel link / upload file HP.
- **Bagikan album ke teman** lewat kode teks (`ffm1:...`) — teman tinggal Impor. File upload tidak ikut.
- **Floating player**: bubble geser (posisi diingat), kontrol, volume musik sendiri, timer tidur, info baterai/suhu/RAM.
- **Mode Game**: 1 tombol = animasi layar penuh + boost RAM + Jangan Ganggu total (telepon, chat & notif dibungkam, musik/game & alarm tetap jalan) + nyalain musik + buka game.
- **Booster**: tutup app background (non-sistem) biar RAM lega.
- **Equalizer** (Normal/Bass/Vokal/Treble) + Kenceng+, layar tetap nyala, pause otomatis kalau headset dicabut.
- Cache lagu offline (maks 300 MB).

### Baru di v3.2: TURBO MAKSIMAL
- Layar dipaksa ke **refresh rate tertinggi** selama floating aktif (kalau HP punya layar 90/120 Hz), jadi geser & tembak lebih licin.
- **Wifi low-latency** + **CPU tetap nyala** (wake lock) biar ping & frame stabil.
- **Boost 2 putaran** (app yang bangun lagi ikut ditutup), auto-boost sampai tiap 1 menit.
- Opsional: **animasi sistem dimatiin** pas Turbo (butuh izin sekali lewat ADB, ada tombol salin perintah di Setelan).
- Tombol **TURBO** juga ada di floating player.
- Semua ikon pakai simbol Unicode polos (bukan emoji warna-warni).
- Catatan jujur: overclock CPU/GPU & touch sampling butuh root / diatur setelan HP & game, gak bisa dari app biasa.

### Baru di v3.1
- **Equalizer 5 pita custom** (60Hz–14kHz) + preset Normal/Bass/Vokal/Treble/**Game** (langkah kaki lebih jelas) + **Bass booster**, **Virtualizer 3D**, **Kenceng+** pakai slider.
- **Kecepatan putar** 0.75x–1.5x, **fade-in** tiap lagu, timer tidur sampai 90 menit.
- **Floating player**: tombol **⚡ Boost** langsung dari dalam game, ganti kecepatan & EQ 1 tap, **♥ Favorit**, bubble nempel ke tepi layar, panel gak keluar layar.
- **HUD**: baterai, suhu (merah kalau panas), RAM, dan **ping jaringan** real-time.
- **Booster+**: daftar app yang jangan ditutup, **auto-boost berkala** (3/5/10 mnt), statistik total RAM dilegakan, tes ping, peringatan Hemat Baterai & HP panas.
- **Mode Game**: Equalizer Game otomatis (balik normal pas floating dimatikan).
- **Kontrol headset / Bluetooth** & layar kunci (MediaSession).
- **Album**: urutkan A–Z, acak, balik, hapus lagu dobel; album **Favorit**; hitungan berapa kali lagu diputar.

## Build
Push ke GitHub -> tab **Actions** -> download APK di **Artifacts**.

## Rilis buat teman (link download tetap)
1. Edit `APP_URL` di `app/src/main/java/com/asep/ffmusic/Ui.kt` jadi link repo kamu.
2. Buat tag: `git tag v3.1 && git push origin v3.1` -> APK otomatis muncul di halaman **Releases**.
3. Kirim link `https://github.com/USERNAME/ff-music/releases/latest` ke teman.

### Biar teman bisa update tanpa uninstall (sangat disarankan)
Bikin keystore sekali, simpan di GitHub Secrets:
```
keytool -genkeypair -v -keystore ffm.jks -alias ffm -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 ffm.jks   # hasilnya -> secret KEYSTORE_BASE64
```
Secrets yang dibutuhkan: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (ffm), `KEY_PASSWORD`.
**Simpan file ffm.jks baik-baik** — kalau hilang, update gak bisa ditimpa.
