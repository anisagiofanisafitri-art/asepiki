# FF Music v2
Floating music player buat main game (Free Fire dkk).
Push ke GitHub -> tab Actions -> download APK di Artifacts.
