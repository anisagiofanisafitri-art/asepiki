package com.asep.ffmusic

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

// Rantai penyedia YouTube & TikTok yang sama dengan Videy Bot (src/downloader/providers).
//  YouTube : API sendiri (Setelan) -> savetube -> ytdlpyton -> savenow -> ytdown.to -> ytdown.io -> ytmp3.mobi
//  TikTok  : API sendiri (Setelan) -> (tikwm di VideoResolver) -> yuulabs -> savetik
// Semua dipanggil dari thread latar belakang (bukan main thread).
object Providers {
    class Media(val title: String, val url: String, val provider: String, val referer: String? = null)

    // API sendiri dari Setelan. Pakai {url} (wajib), {id} dan {fmt} (opsional) sebagai penanda.
    @Volatile var ytApi: String = ""
    @Volatile var tikApi: String = ""
    @Volatile var apiKey: String = ""

    fun load(c: Context) {
        ytApi = (Store.str(c, "ytapi") ?: "").trim()
        tikApi = (Store.str(c, "tikapi") ?: "").trim()
        apiKey = (Store.str(c, "apikey") ?: "").trim()
    }

    private const val UA_M = "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36"

    private fun http(
        u: String, method: String = "GET", headers: Map<String, String> = emptyMap(),
        body: String? = null, readMs: Int = 20000
    ): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.requestMethod = method
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IllegalStateException("HTTP $code")
        return text
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun form(vararg p: Pair<String, String>) = p.joinToString("&") { "${enc(it.first)}=${enc(it.second)}" }
    private fun ytUrl(id: String) = "https://www.youtube.com/watch?v=$id"

    // kualitas terdekat yang <= keinginan (360/480/720/1080)
    fun ytFormat(want: Int): String = listOf(360, 480, 720, 1080).lastOrNull { it <= want }?.toString() ?: "360"

    // ======================= YouTube =======================

    // fmt: "360" | "480" | "720" | "1080" | "mp3". Coba satu-satu, error digabung kalau semua gagal.
    fun ytMedia(id: String, fmt: String): Media {
        val errs = mutableListOf<String>()
        val steps = mutableListOf<Pair<String, () -> Media>>()
        if (ytApi.startsWith("http")) steps.add("api-sendiri" to { viaTemplate("api-sendiri", ytApi, ytUrl(id), id, fmt) })
        steps.add("savetube" to { savetube(id, fmt) })
        steps.add("ytdlpyton" to { ytdlpyton(id, fmt) })
        steps.add("savenow" to { savenow(id, fmt) })
        steps.add("ytdownto" to { ytdownTo(id, fmt) })
        steps.add("ytdownio" to { ytdownIo(id, fmt) })
        steps.add("ytmp3mobi" to { ytmp3Mobi(id, fmt) })
        for ((name, run) in steps) {
            try { return run() } catch (e: Exception) { errs.add("$name: ${e.message?.take(60)}") }
        }
        throw IllegalStateException(errs.joinToString("; "))
    }

    fun ytAudio(id: String): String? = try { ytMedia(id, "mp3").url } catch (_: Exception) { null }

    private val SAVETUBE_KEY = "C5D58EF67A7584E4A29F6C35BBC4EB12"

    private fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun decrypt(encB64: String): JSONObject {
        val data = Base64.decode(encB64, Base64.DEFAULT)
        val iv = data.copyOfRange(0, 16)
        val content = data.copyOfRange(16, data.size)
        val ci = Cipher.getInstance("AES/CBC/PKCS5Padding")
        ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(hex(SAVETUBE_KEY), "AES"), IvParameterSpec(iv))
        return JSONObject(String(ci.doFinal(content)))
    }

    private fun savetube(id: String, fmt: String): Media {
        val h = mapOf(
            "accept" to "*/*", "content-type" to "application/json",
            "origin" to "https://yt.savetube.me", "referer" to "https://yt.savetube.me/",
            "user-agent" to "Postify/1.0.0"
        )
        val cdn = JSONObject(http("https://media.savetube.me/api/random-cdn", headers = h)).getString("cdn")
        val info = JSONObject(http("https://$cdn/v2/info", "POST", h, JSONObject().put("url", ytUrl(id)).toString()))
        val d = decrypt(info.getString("data"))
        val audio = fmt == "mp3"
        val body = JSONObject().put("id", id)
            .put("downloadType", if (audio) "audio" else "video")
            .put("quality", if (audio) "128" else fmt)
            .put("key", d.getString("key"))
        val dl = JSONObject(http("https://$cdn/download", "POST", h, body.toString()))
        val u = dl.getJSONObject("data").getString("downloadUrl")
        return Media(d.optString("title").ifBlank { "YouTube" }, u, "savetube")
    }

    private fun ytdlpyton(id: String, fmt: String): Media {
        val link = enc(ytUrl(id))
        val ep = if (fmt == "mp3") "https://ytdlpyton.nvlgroup.my.id/download/audio?url=$link&mode=url"
        else "https://ytdlpyton.nvlgroup.my.id/download/?url=$link&resolution=$fmt&mode=url"
        val j = JSONObject(http(ep, readMs = 60000))
        val u = j.optString("download_url")
        if (!u.startsWith("http")) throw IllegalStateException("gak ada link")
        return Media(j.optString("title").ifBlank { "YouTube" }, u, "ytdlpyton")
    }

    private fun savenow(id: String, fmt: String): Media {
        val base = "https://p.savenow.to"
        val key = "dfcb6d76f2f6a9894gjkege8a4ab232222"
        val init = JSONObject(http("$base/ajax/download.php?copyright=0&format=${if (fmt == "mp3") "mp3" else fmt}&url=${enc(ytUrl(id))}&api=$key", readMs = 60000))
        val pu = init.optString("progress_url")
        if (!init.optBoolean("success", false) || pu.isEmpty()) throw IllegalStateException("init gagal")
        repeat(24) {
            val p = JSONObject(http(pu, readMs = 20000))
            val du = p.optString("download_url")
            if (p.optInt("success", 0) == 1 && du.startsWith("http")) {
                return Media(init.optJSONObject("info")?.optString("title")?.ifBlank { null } ?: "YouTube", du, "savenow")
            }
            if (p.optInt("success", 0) == -1) throw IllegalStateException("ditolak")
            Thread.sleep(2500)
        }
        throw IllegalStateException("kelamaan")
    }

    private fun ytdownTo(id: String, fmt: String): Media {
        val audio = fmt == "mp3"
        val h = mapOf(
            "Content-Type" to "application/x-www-form-urlencoded; charset=UTF-8", "Accept" to "*/*",
            "X-Requested-With" to "XMLHttpRequest", "User-Agent" to "Mozilla/5.0", "Referer" to "https://app.ytdown.to/id12/"
        )
        val api = JSONObject(http("https://app.ytdown.to/proxy.php", "POST", h, form("url" to ytUrl(id)), 30000)).getJSONObject("api")
        val items = api.getJSONArray("mediaItems")
        fun find(type: String, q: String?): JSONObject? {
            var first: JSONObject? = null
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                if (o.optString("type") != type) continue
                if (first == null) first = o
                if (q != null && o.optString("mediaQuality") == q) return o
            }
            return first
        }
        val target = (if (audio) find("Audio", "128K") else find("Video", "HD")) ?: throw IllegalStateException("format gak ada")
        repeat(8) {
            try {
                val chk = JSONObject(http(target.getString("mediaUrl"), headers = mapOf("User-Agent" to "Mozilla/5.0"), readMs = 15000))
                if (chk.optString("status") == "completed" && chk.optString("fileUrl").startsWith("http")) {
                    return Media(api.optString("title").ifBlank { "YouTube" }, chk.getString("fileUrl"), "ytdownto")
                }
            } catch (_: Exception) {}
            Thread.sleep(3000)
        }
        throw IllegalStateException("kelamaan")
    }

    private fun ytdownIo(id: String, fmt: String): Media {
        val audio = fmt == "mp3"
        val h = mapOf(
            "accept" to "*/*", "content-type" to "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie" to "PHPSESSID=ofu9rbop984f7ovqdsp72q9t82", "origin" to "https://ytdown.io",
            "referer" to "https://ytdown.io/en/", "user-agent" to UA_M, "x-requested-with" to "XMLHttpRequest"
        )
        val api = JSONObject(http("https://ytdown.io/proxy.php", "POST", h, form("url" to ytUrl(id)), 30000)).getJSONObject("api")
        val items = api.optJSONArray("mediaItems") ?: JSONArray()
        fun finalUrl(mediaUrl: String): String =
            JSONObject(http("https://ytdown.io/proxy.php", "POST", h, form("url" to mediaUrl), 30000))
                .optJSONObject("api")?.optString("fileUrl").orEmpty()
        val title = api.optString("title").ifBlank { "YouTube" }
        if (audio) {
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                if (o.optString("type").equals("audio", true) && o.optString("mediaUrl").isNotEmpty()) {
                    val u = finalUrl(o.getString("mediaUrl"))
                    if (u.startsWith("http")) return Media(title, u, "ytdownio")
                }
            }
            throw IllegalStateException("audio gak ada")
        }
        val wanted = mapOf("360" to "640x360", "480" to "854x480", "720" to "1280x720", "1080" to "1920x1080")[fmt]
        var pick: JSONObject? = null
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i)
            if (!o.optString("type").equals("video", true)) continue
            if (o.optString("mediaRes") !in listOf("640x360", "854x480", "1280x720", "1920x1080")) continue
            if (pick == null) pick = o
            if (o.optString("mediaRes") == wanted) { pick = o; break }
        }
        val p = pick ?: throw IllegalStateException("video gak ada")
        val u = finalUrl(p.getString("mediaUrl"))
        if (!u.startsWith("http")) throw IllegalStateException("link akhir kosong")
        return Media(title, u, "ytdownio")
    }

    private fun ytmp3Mobi(id: String, fmt: String): Media {
        val h = mapOf(
            "User-Agent" to "Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7271.123 Mobile Safari/537.36",
            "Referer" to "https://id.ytmp3.mobi/"
        )
        val init = JSONObject(http("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}", headers = h, readMs = 60000))
        val cu = init.optString("convertURL")
        if (cu.isEmpty()) throw IllegalStateException("init gagal")
        val sep = if (cu.contains("?")) "&" else "?"
        val conv = JSONObject(http("$cu${sep}v=$id&f=${if (fmt == "mp3") "mp3" else "mp4"}&_=${Math.random()}", headers = h, readMs = 60000))
        val pu = conv.optString("progressURL")
        val du = conv.optString("downloadURL")
        if (pu.isEmpty() || du.isEmpty()) throw IllegalStateException("convert gagal")
        var progress = 0
        var title = conv.optString("title")
        var n = 0
        while (progress < 3 && n < 30) {
            val d = JSONObject(http(pu, headers = h, readMs = 20000))
            if (d.optInt("error", 0) > 0) throw IllegalStateException("server error ${d.optInt("error")}")
            progress = d.optInt("progress", 0)
            d.optString("title").takeIf { it.isNotEmpty() }?.let { title = it }
            if (progress < 3) Thread.sleep(1000)
            n++
        }
        if (progress < 3) throw IllegalStateException("kelamaan")
        return Media(title.ifBlank { "YouTube" }, du, "ytmp3mobi")
    }

    // ======================= Cari lagu/video YouTube (tanpa Piped) =======================
    class Hit(val title: String, val id: String, val by: String)

    // endpoint web internal YouTube (kunci web publik) — sama prinsipnya dengan paket yt-search di bot
    fun ytSearch(q: String): List<Hit> {
        val body = JSONObject()
            .put("context", JSONObject().put("client", JSONObject()
                .put("clientName", "WEB").put("clientVersion", "2.20240101.00.00").put("hl", "id").put("gl", "ID")))
            .put("query", q).put("params", "EgIQAQ==")
        val h = mapOf("Content-Type" to "application/json", "User-Agent" to UA_M, "Origin" to "https://www.youtube.com")
        val j = JSONObject(http("https://www.youtube.com/youtubei/v1/search?prettyPrint=false&key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8", "POST", h, body.toString(), 15000))
        val sections = j.optJSONObject("contents")?.optJSONObject("twoColumnSearchResultsRenderer")
            ?.optJSONObject("primaryContents")?.optJSONObject("sectionListRenderer")?.optJSONArray("contents") ?: JSONArray()
        val out = mutableListOf<Hit>()
        for (i in 0 until sections.length()) {
            val items = sections.getJSONObject(i).optJSONObject("itemSectionRenderer")?.optJSONArray("contents") ?: continue
            for (k in 0 until items.length()) {
                val v = items.getJSONObject(k).optJSONObject("videoRenderer") ?: continue
                val id = v.optString("videoId")
                if (id.length != 11) continue
                val title = v.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
                val by = v.optJSONObject("ownerText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
                if (title.isNotEmpty()) out.add(Hit(title, id, by))
                if (out.size >= 12) return out
            }
        }
        return out
    }

    // ======================= TikTok =======================

    // urutan: API sendiri -> yuulabs -> savetik (tikwm dicoba lebih dulu di VideoResolver)
    fun tiktokMedia(url: String): Media {
        val errs = mutableListOf<String>()
        val steps = mutableListOf<Pair<String, () -> Media>>()
        steps.add("yuulabs" to { yuulabs(url) })
        steps.add("savetik" to { savetik(url) })
        for ((name, run) in steps) {
            try { return run() } catch (e: Exception) { errs.add("$name: ${e.message?.take(60)}") }
        }
        throw IllegalStateException(errs.joinToString("; "))
    }

    fun tiktokOwn(url: String): Media? =
        if (tikApi.startsWith("http")) try { viaTemplate("api-sendiri", tikApi, url, "", "") } catch (_: Exception) { null } else null

    private fun yuulabs(url: String): Media {
        val j = JSONObject(http("https://api.yuulabs.web.id/api/downloader/tiktok?url=${enc(url)}", headers = mapOf("user-agent" to UA_M), readMs = 30000))
        val r = j.optJSONObject("result")
        if (!j.optBoolean("status", false) || r == null) throw IllegalStateException(j.optString("message", "respon aneh"))
        val u = r.optString("hdVideo").ifBlank { r.optString("videoUrl") }
        if (!u.startsWith("http")) throw IllegalStateException("gak ada video")
        return Media(r.optString("description").ifBlank { "TikTok" }, u, "yuulabs", "https://api.yuulabs.web.id/")
    }

    private fun savetik(url: String): Media {
        val h = mapOf(
            "content-type" to "application/x-www-form-urlencoded; charset=UTF-8", "x-requested-with" to "XMLHttpRequest",
            "user-agent" to "Mozilla/5.0 (Linux; Android 10)", "origin" to "https://savetik.io",
            "referer" to "https://savetik.io/id/download-tiktok-photos", "accept" to "*/*"
        )
        val r = JSONObject(http("https://savetik.io/api/ajaxSearch", "POST", h, form("q" to url, "cursor" to "0", "page" to "0", "lang" to "id"), 45000))
        val html = r.optString("data")
        if (html.isEmpty()) throw IllegalStateException("html kosong")
        fun href(label: String): String? =
            Regex("href=\"([^\"]+)\"[^>]*>\\s*(?:<[^>]*>\\s*)*" + Regex.escape(label)).find(html)?.groupValues?.get(1)?.replace("&amp;", "&")
        val mp4 = href("Unduh MP4 [1]") ?: href("Unduh MP4 [2]") ?: href("Unduh MP4 HD") ?: throw IllegalStateException("bukan video / gak ada")
        val title = Regex("<h3[^>]*>([^<]*)</h3>").find(html)?.groupValues?.get(1)?.trim().orEmpty()
        return Media(title.ifBlank { "TikTok" }, mp4, "savetik", "https://savetik.io/")
    }

    // ======================= Cari video TikTok (buat unduh massal) =======================
    class TikVid(val id: String, val title: String, val url: String, val page: String)
    class TikPage(val videos: List<TikVid>, val cursor: Long, val more: Boolean)

    // satu halaman hasil pencarian TikWM (maks 30 video). sd=true -> video biasa (hemat memori), false -> HD
    fun tiktokSearch(q: String, cursor: Long, sd: Boolean): TikPage {
        var last: Exception? = null
        repeat(3) {
            for (host in listOf("https://www.tikwm.com", "https://tikwm.com")) {
                try {
                    val h = mapOf(
                        "Content-Type" to "application/x-www-form-urlencoded; charset=UTF-8", "User-Agent" to UA_M,
                        "Origin" to host, "Referer" to "$host/", "Cookie" to "current_language=en"
                    )
                    val j = JSONObject(http("$host/api/feed/search", "POST", h,
                        form("keywords" to q, "count" to "30", "cursor" to cursor.toString(), "HD" to "1"), 30000))
                    if (j.optInt("code", 0) != 0) {
                        val msg = j.optString("msg")
                        last = IllegalStateException("tikwm: " + msg.take(60))
                        // batas gratis 1 permintaan/detik
                        if (Regex("limit|second|too many", RegexOption.IGNORE_CASE).containsMatchIn(msg)) Thread.sleep(1400)
                        continue
                    }
                    val d = j.optJSONObject("data") ?: JSONObject()
                    val arr = d.optJSONArray("videos") ?: JSONArray()
                    fun abs(u: String) = when {
                        u.startsWith("http") -> u
                        u.startsWith("/") -> "$host$u"
                        else -> ""
                    }
                    val out = mutableListOf<TikVid>()
                    for (i in 0 until arr.length()) {
                        val v = arr.getJSONObject(i)
                        val id = v.optString("video_id").ifEmpty { v.optString("id") }
                        if (!Regex("^\\d{6,25}$").matches(id)) continue
                        if (v.optInt("duration", 1) <= 0) continue          // postingan foto
                        val play = abs(v.optString("play"))
                        val hd = abs(v.optString("hdplay"))
                        val u = if (sd) play.ifEmpty { hd } else hd.ifEmpty { play }
                        if (u.isEmpty()) continue
                        val uid = v.optJSONObject("author")?.optString("unique_id").orEmpty().ifEmpty { "x" }
                        out.add(TikVid(id, v.optString("title").trim(), u, "https://www.tiktok.com/@$uid/video/$id"))
                    }
                    return TikPage(out, d.optLong("cursor", cursor + arr.length()), d.optBoolean("hasMore", arr.length() > 0))
                } catch (e: Exception) { last = e }
            }
        }
        throw last ?: IllegalStateException("tikwm gagal")
    }

    // ======================= API sendiri (template) =======================
    private val URL_KEYS = listOf(
        "nowm", "nowatermark", "no_watermark", "withoutwm", "hdplay", "play", "video_nowm", "video", "videourl",
        "download_url", "downloadurl", "download", "link", "mp4", "mp3", "audio", "audiourl", "url"
    )

    private fun findUrl(n: Any?, depth: Int = 0): String? {
        if (n == null || depth > 4) return null
        when (n) {
            is String -> return if (n.startsWith("http", true)) n else null
            is JSONArray -> { for (i in 0 until n.length()) findUrl(n.opt(i), depth + 1)?.let { return it } }
            is JSONObject -> {
                val low = HashMap<String, Any?>()
                n.keys().forEach { low[it.lowercase()] = n.opt(it) }
                for (k in URL_KEYS + listOf("data", "result", "results")) {
                    if (low.containsKey(k)) findUrl(low[k], depth + 1)?.let { return it }
                }
            }
        }
        return null
    }

    // tpl contoh: https://api-kamu/tiktok?url={url}   atau   https://api-kamu/yt?url={url}&format={fmt}
    private fun viaTemplate(name: String, tpl: String, url: String, id: String, fmt: String): Media {
        val h = mutableMapOf("User-Agent" to "Mozilla/5.0", "Accept" to "application/json")
        if (apiKey.isNotEmpty()) { h["x-api-key"] = apiKey; h["Authorization"] = "Bearer $apiKey" }
        val u = tpl.replace("{url}", enc(url)).replace("{id}", id).replace("{fmt}", fmt)
        val j = JSONObject(http(u, headers = h, readMs = 30000))
        val body = j.optJSONObject("data") ?: j.optJSONObject("result") ?: j
        val v = findUrl(body) ?: throw IllegalStateException("gak ada link video")
        val title = body.optString("title").ifBlank { body.optString("desc") }.ifBlank { name }
        return Media(title, v, name)
    }
}
