package com.asep.ffmusic

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

// Player video fullscreen: link YouTube/TikTok, link video langsung, atau file dari HP. Sampai 4K.
class VideoActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()

    private lateinit var player: ExoPlayer
    private lateinit var holder: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var gestureLayer: View
    private lateinit var controls: FrameLayout
    private lateinit var titleTv: TextView
    private lateinit var qualBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var aspectBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var prevBtn: TextView
    private lateinit var nextBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeCur: TextView
    private lateinit var timeDur: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var osdTv: TextView
    private lateinit var errBox: LinearLayout
    private lateinit var errTv: TextView
    private lateinit var unlockTv: TextView

    private var queue = listOf<VideoItem>()
    private var qi = 0
    private var streams = listOf<VideoResolver.Stream>()
    private var si = 0
    private var result: VideoResolver.Result? = null
    private var token = 0
    private var wantH = 1080
    private var resolving = false

    private var vw = 0
    private var vh = 0
    private var resizeMode = 0                  // 0 FIT, 1 ZOOM (potong sisi), 2 PENUH (ditarik)
    private var locked = false
    private var inPip = false
    private var userRotated = false
    private var controlsVisible = true
    private var seeking = false
    private var pausedMusic = false
    private var speedIdx = 2
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private val speedLabels = listOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x")
    private val aspectLabels = listOf("FIT", "ZOOM", "PENUH")
    private var bright = -1f
    private var volAcc = -1f

    private val hideRunnable = Runnable { showControls(false) }
    private val osdHide = Runnable { osdTv.visibility = View.GONE }
    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 500) }
    }

    // ---------------- lifecycle ----------------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        hideBars()
        wantH = intArrayOf(360, 720, 1080, 1440, 2160)[Store.int(this, "vq", 2).coerceIn(0, 4)]
        buildUi()
        buildPlayer()
        // bubble musik disembunyiin & musik di-pause selama nonton (nanti dilanjut lagi)
        svc("HIDE_SET") { it.putExtra("on", true) }
        if (PlayerState.running && PlayerState.playing) { svc("TOGGLE"); pausedMusic = true }
        handleIntent(intent)
        ui.post(ticker)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handleIntent(i)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStop() {
        super.onStop()
        savePos()
        if (!inPip && ::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        savePos()
        try { player.release() } catch (_: Throwable) {}
        io.shutdownNow()
        svc("HIDE_SET") { it.putExtra("on", false) }
        if (pausedMusic && !PlayerState.playing) svc("TOGGLE")
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (locked) { showUnlock(); return }
        super.onBackPressed()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::player.isInitialized && player.isPlaying && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (inPip) {
            controls.visibility = View.GONE
            osdTv.visibility = View.GONE
            unlockTv.visibility = View.GONE
        } else if (!locked) showControls(true)
    }

    private fun svc(action: String, f: (Intent) -> Unit = {}) {
        if (!PlayerState.running) return
        try { startService(Intent(this, OverlayService::class.java).setAction(action).also(f)) } catch (_: Throwable) {}
    }

    private fun hideBars() {
        val ic = WindowCompat.getInsetsController(window, window.decorView)
        ic.hide(WindowInsetsCompat.Type.systemBars())
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ---------------- input (dari app, Share, atau link) ----------------
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val items = mutableListOf<VideoItem>()
        var start = 0
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u = VideoResolver.firstUrl(i.getStringExtra(Intent.EXTRA_TEXT) ?: "")
                if (u != null) items.add(VideoItem(u, u, "link"))
            }
            Intent.ACTION_VIEW -> {
                val d = i.data
                if (d != null) {
                    if (d.scheme == "http" || d.scheme == "https") items.add(VideoItem(d.toString(), d.toString(), "link"))
                    else items.add(VideoItem(nameOf(d), d.toString(), "local"))
                }
            }
            else -> {
                val srcs = i.getStringArrayExtra("srcs")
                val titles = i.getStringArrayExtra("titles")
                val kinds = i.getStringArrayExtra("kinds")
                if (srcs != null && titles != null && kinds != null && srcs.size == titles.size && srcs.size == kinds.size) {
                    for (k in srcs.indices) items.add(VideoItem(titles[k], srcs[k], kinds[k]))
                }
                start = i.getIntExtra("start", 0)
            }
        }
        if (items.isEmpty()) {
            Toast.makeText(this, "Gak ada video/link yang bisa diputar", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        queue = items
        load(start.coerceIn(0, items.size - 1))
    }

    private fun nameOf(u: Uri): String {
        var name = u.lastPathSegment ?: "Video"
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (k >= 0 && c.moveToFirst()) name = c.getString(k)
            }
        } catch (_: Exception) {}
        return name.substringBeforeLast('.')
    }

    // ---------------- muat & putar ----------------
    private fun load(i: Int, startPos: Long = -1L) {
        savePos()
        qi = i
        val item = queue[i]
        val my = ++token
        titleTv.text = item.title
        errBox.visibility = View.GONE
        resolving = true
        spinner.visibility = View.VISIBLE
        player.stop()
        prevBtn.alpha = if (queue.size > 1) 1f else 0.35f
        nextBtn.alpha = if (queue.size > 1) 1f else 0.35f
        val pos = if (startPos >= 0) startPos else resumePos(item)
        if (item.kind == "local") {
            streams = listOf(VideoResolver.Stream("Lokal", 0, 0, item.src, null, "local"))
            si = 0
            result = null
            resolving = false
            playStream(pos)
        } else if (item.kind == "saved") {
            // video offline: diputar dari penyimpanan app, gak butuh internet
            val parts = item.src.split("|")
            val vf = File(parts[0])
            val af = parts.getOrNull(1)?.let { File(it) }
            resolving = false
            spinner.visibility = View.GONE
            if (!vf.exists() || (af != null && !af.exists())) {
                showError("File offline hilang (mungkin terhapus).\nHapus dari daftar lalu simpan ulang.")
                return
            }
            streams = listOf(
                VideoResolver.Stream("Offline", 0, 0, Uri.fromFile(vf).toString(), af?.let { Uri.fromFile(it).toString() }, "local")
            )
            si = 0
            result = null
            spinner.visibility = View.VISIBLE
            playStream(pos)
        } else {
            io.execute {
                try {
                    val r = VideoResolver.resolve(this, item.src, wantH)
                    ui.post {
                        if (my != token || isFinishing) return@post
                        resolving = false
                        result = r
                        streams = r.streams
                        si = VideoResolver.pick(streams, wantH)
                        titleTv.text = r.title
                        Store.addVideo(this, VideoItem(r.title, item.src, "link"))
                        playStream(pos)
                    }
                } catch (e: Exception) {
                    ui.post {
                        if (my == token && !isFinishing) {
                            resolving = false
                            spinner.visibility = View.GONE
                            showError(e.message ?: "Gagal ambil video")
                        }
                    }
                }
            }
        }
    }

    private fun playStream(pos: Long) {
        val s = streams.getOrNull(si) ?: return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(VideoResolver.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(20000)
        val msf = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
        fun item(u: String, hls: Boolean): MediaItem =
            MediaItem.Builder().setUri(Uri.parse(u)).apply { if (hls) setMimeType(MimeTypes.APPLICATION_M3U8) }.build()
        val audio = s.audioUrl
        val src: MediaSource = if (audio != null) {
            // YouTube 720p ke atas: video & audio terpisah, digabung di player
            MergingMediaSource(msf.createMediaSource(item(s.url, false)), msf.createMediaSource(item(audio, false)))
        } else msf.createMediaSource(item(s.url, s.hls))
        if (pos > 0) player.setMediaSource(src, pos) else player.setMediaSource(src)
        player.prepare()
        player.playWhenReady = true
        player.setPlaybackSpeed(speeds[speedIdx])
        qualBtn.text = s.label + " ▾"
    }

    private fun showError(msg: String) {
        errTv.text = msg
        errBox.visibility = View.VISIBLE
        showControls(true)
    }

    private fun savePos() {
        if (!::player.isInitialized) return
        val item = queue.getOrNull(qi) ?: return
        val d = player.duration
        val p = player.currentPosition
        if (d <= 0) return
        Store.putInt(this, "vp:" + item.src.hashCode(), if (p > d - 8000 || p < 5000) 0 else p.toInt())
    }

    private fun resumePos(item: VideoItem): Long = Store.int(this, "vp:" + item.src.hashCode(), 0).toLong()

    private fun buildPlayer() {
        player = ExoPlayer.Builder(this)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(20000, 90000, 1500, 3000).build())
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        player.setVideoSurfaceView(surface)
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                spinner.visibility = if (state == Player.STATE_BUFFERING || resolving) View.VISIBLE else View.GONE
                if (state == Player.STATE_READY) errBox.visibility = View.GONE
                if (state == Player.STATE_ENDED) {
                    savePos()
                    if (qi + 1 < queue.size) load(qi + 1) else { showControls(true); playBtn.text = "↻" }
                }
            }

            override fun onIsPlayingChanged(p: Boolean) {
                playBtn.text = if (p) "❚❚" else "▶\uFE0E"
                if (p) scheduleHide() else if (player.playbackState != Player.STATE_ENDED) showControls(true)
            }

            override fun onVideoSizeChanged(v: VideoSize) {
                vw = (v.width * v.pixelWidthHeightRatio).toInt()
                vh = v.height
                layoutVideo()
                if (!userRotated && v.width > 0 && !inPip) {
                    requestedOrientation = if (v.width >= v.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
            }

            override fun onPlayerError(e: PlaybackException) {
                // kualitas ini gagal (misal HP gak bisa decode 4K VP9) -> otomatis turun satu tingkat
                if (si + 1 < streams.size && streams[si].source != "local") {
                    val bad = streams[si].label
                    si++
                    Toast.makeText(this@VideoActivity, "$bad gagal, pindah ke ${streams[si].label}", Toast.LENGTH_SHORT).show()
                    playStream(player.currentPosition)
                } else showError("Gagal memutar video (${e.errorCodeName}).\nCoba kualitas lain atau muat ulang.")
            }
        })
    }

    // ---------------- UI ----------------
    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(Color.parseColor("#44FFFFFF"), 16)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun roundBtn(label: String, size: Int, textSp: Float, main: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = textSp
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (main) oval(PURPLE, PINK) else oval(Color.parseColor("#66000000"), Color.parseColor("#66000000"))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        holder = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        holder.addView(surface, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        holder.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob ->
            if (r - l != orr - ol || bt - t != ob - ot) layoutVideo()
        }
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))

        // gesture: tap = tampil/sembunyi kontrol, dobel tap = loncat 10 dtk, geser kiri = cahaya, geser kanan = volume
        gestureLayer = View(this)
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean { volAcc = -1f; return true }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showUnlock() else showControls(!controlsVisible)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < gestureLayer.width / 2f) seekBy(-10_000) else seekBy(10_000)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || gestureLayer.height == 0) return false
                if (abs(dy) < abs(dx) * 1.2f) return false
                val frac = dy / gestureLayer.height
                if (e1.x < gestureLayer.width / 2f) adjustBrightness(frac) else adjustVolume(frac)
                return true
            }
        })
        gestureLayer.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
        root.addView(gestureLayer, FrameLayout.LayoutParams(-1, -1))

        controls = FrameLayout(this)

        // ---- bar atas ----
        titleTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        qualBtn = chip("— ▾") { showQualityMenu() }
        speedBtn = chip(speedLabels[speedIdx]) {
            speedIdx = (speedIdx + 1) % speeds.size
            player.setPlaybackSpeed(speeds[speedIdx])
            speedBtn.text = speedLabels[speedIdx]
            osd("Kecepatan ${speedLabels[speedIdx]}")
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT))
            setPadding(dp(28), dp(14), dp(20), dp(30))
            addView(TextView(context).apply {
                text = "←"; textSize = 26f; setTextColor(Color.WHITE); setPadding(dp(4), 0, dp(16), 0)
                setOnClickListener { finish() }
            })
            addView(titleTv)
            addView(qualBtn)
            addView(speedBtn)
        }
        controls.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- tengah ----
        prevBtn = roundBtn("|◀\uFE0E", 46, 15f, false) {
            if (player.currentPosition > 3000 || qi == 0) player.seekTo(0) else load(qi - 1)
        }
        playBtn = roundBtn("▶\uFE0E", 68, 26f, true) {
            if (player.playbackState == Player.STATE_ENDED) { player.seekTo(0); player.play() }
            else if (player.isPlaying) player.pause() else player.play()
        }
        nextBtn = roundBtn("▶\uFE0E|", 46, 15f, false) {
            if (qi + 1 < queue.size) load(qi + 1) else osd("Ini video terakhir")
        }
        val centerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(prevBtn)
            addView(roundBtn("−10", 50, 13f, false) { seekBy(-10_000) })
            addView(playBtn)
            addView(roundBtn("+10", 50, 13f, false) { seekBy(10_000) })
            addView(nextBtn)
        }
        controls.addView(centerRow, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ---- bar bawah ----
        timeCur = TextView(this).apply { text = "0:00"; setTextColor(Color.WHITE); textSize = 12f }
        timeDur = TextView(this).apply { text = "--:--"; setTextColor(Color.WHITE); textSize = 12f }
        seek = SeekBar(this).apply {
            max = 1000
            tint()
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && player.duration > 0) timeCur.text = fmt(player.duration * p / 1000)
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true; ui.removeCallbacks(hideRunnable) }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    val d = player.duration
                    if (d > 0) player.seekTo(d * (s?.progress ?: 0) / 1000)
                    scheduleHide()
                }
            })
        }
        aspectBtn = chip(aspectLabels[resizeMode]) {
            resizeMode = (resizeMode + 1) % 3
            aspectBtn.text = aspectLabels[resizeMode]
            layoutVideo()
            osd("Tampilan ${aspectLabels[resizeMode]}")
        }
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, 0)
            addView(aspectBtn)
            addView(chip("PUTAR") {
                userRotated = true
                requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            })
            addView(chip("KUNCI") { setLocked(true) })
            addView(chip("PiP") { enterPip() })
            addView(chip("SIMPAN") { saveOffline() })
        }
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT))
            setPadding(dp(28), dp(34), dp(28), dp(16))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(timeCur)
                addView(seek)
                addView(timeDur)
            })
            addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) })
        }
        controls.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        // ---- loading, OSD, error, buka kunci ----
        spinner = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(CYAN)
            visibility = View.GONE
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))

        osdTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.parseColor("#B3000000"), 16)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            visibility = View.GONE
        }
        root.addView(osdTv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(70) })

        errTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        errBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#F0101020"), 18, Color.parseColor("#44FF2E93"))
            setPadding(dp(20), dp(18), dp(20), dp(16))
            visibility = View.GONE
            addView(errTv)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(chip("Coba lagi") { load(qi, if (player.currentPosition > 0) player.currentPosition else -1L) })
                addView(chip("Tutup") { finish() })
            })
        }
        root.addView(errBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { setMargins(dp(40), 0, dp(40), 0) })

        unlockTv = TextView(this).apply {
            text = "BUKA KUNCI"
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.parseColor("#B3000000"), 18, CYAN)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            visibility = View.GONE
            setOnClickListener { setLocked(false) }
        }
        root.addView(unlockTv, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(32) })

        setContentView(root)
    }

    // ---------------- kontrol ----------------
    private fun showControls(show: Boolean) {
        if (locked && show) return
        controlsVisible = show
        ui.removeCallbacks(hideRunnable)
        controls.animate().cancel()
        if (show) {
            controls.visibility = View.VISIBLE
            controls.animate().alpha(1f).setDuration(160).start()
            scheduleHide()
        } else {
            controls.animate().alpha(0f).setDuration(160).withEndAction {
                if (!controlsVisible) controls.visibility = View.GONE
            }.start()
        }
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (::player.isInitialized && player.isPlaying && controlsVisible && !seeking) ui.postDelayed(hideRunnable, 3500)
    }

    private fun setLocked(l: Boolean) {
        locked = l
        if (l) {
            showControls(false)
            showUnlock()
        } else {
            unlockTv.visibility = View.GONE
            showControls(true)
        }
    }

    private fun showUnlock() {
        unlockTv.visibility = View.VISIBLE
        ui.postDelayed({ if (locked) unlockTv.visibility = View.GONE }, 2500)
    }

    // simpan video yang lagi diputar ke dalam app biar bisa ditonton offline (jalan di latar belakang)
    private fun saveOffline() {
        val item = queue.getOrNull(qi) ?: return
        when (item.kind) {
            "saved" -> osd("Sudah tersimpan offline")
            "local" -> {
                Downloads.enqueue(this, Downloads.Job(item.title, "copy", item.src, 0))
                osd("Menyalin ke dalam app, cek notifikasi")
            }
            else -> {
                val s = streams.getOrNull(si)
                if (s == null || s.hls) { osd("Siaran live belum bisa disimpan"); return }
                Downloads.enqueue(this, Downloads.Job(result?.title ?: item.title, "link", item.src, s.height))
                osd("Mulai unduh ${s.label}, cek notifikasi")
            }
        }
    }

    private fun showQualityMenu() {
        val r = result
        if (r != null && r.kind == "cobalt") {
            val hs = intArrayOf(360, 480, 720, 1080, 1440, 2160)
            AlertDialog.Builder(this).setTitle("Kualitas")
                .setItems(hs.map { "${it}p" }.toTypedArray()) { _, w ->
                    wantH = hs[w]
                    load(qi, player.currentPosition)
                }.show()
            return
        }
        if (streams.size <= 1) { osd("Cuma ada satu kualitas"); return }
        val items = streams.mapIndexed { i, s -> s.label + if (i == si) "   ✓" else "" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Kualitas")
            .setItems(items) { _, w ->
                si = w
                wantH = streams[w].height.takeIf { it > 0 } ?: wantH
                playStream(player.currentPosition)
            }.show()
    }

    private fun seekBy(ms: Long) {
        val d = player.duration
        var t = player.currentPosition + ms
        t = if (d > 0) t.coerceIn(0L, d) else maxOf(0L, t)
        player.seekTo(t)
        osd(if (ms < 0) "−${-ms / 1000} dtk" else "+${ms / 1000} dtk")
    }

    private fun adjustBrightness(f: Float) {
        if (bright < 0) bright = try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) { 0.5f }
        bright = (bright + f).coerceIn(0.02f, 1f)
        window.attributes = window.attributes.also { it.screenBrightness = bright }
        osd("Cahaya ${(bright * 100).toInt()}%")
    }

    private fun adjustVolume(f: Float) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (volAcc < 0) volAcc = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
            volAcc = (volAcc + f).coerceIn(0f, 1f)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(volAcc * max), 0)
            osd("Volume ${(volAcc * 100).toInt()}%")
        } catch (_: Exception) {}
    }

    private fun osd(s: String) {
        osdTv.text = s
        osdTv.visibility = View.VISIBLE
        ui.removeCallbacks(osdHide)
        ui.postDelayed(osdHide, 800)
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val ratio = if (vw > 0 && vh > 0) (vw.toFloat() / vh).coerceIn(0.42f, 2.39f) else 16f / 9f
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational((ratio * 1000).toInt(), 1000)).build()
            )
        } catch (_: Throwable) {
            Toast.makeText(this, "PiP gak didukung di HP ini", Toast.LENGTH_SHORT).show()
        }
    }

    // ukuran video di layar: FIT / ZOOM / PENUH
    private fun layoutVideo() {
        val cw = holder.width
        val ch = holder.height
        if (cw == 0 || ch == 0 || vw == 0 || vh == 0) return
        val va = vw.toFloat() / vh
        val ca = cw.toFloat() / ch
        var w = cw
        var h = ch
        when (resizeMode) {
            0 -> if (va > ca) h = (cw / va).toInt() else w = (ch * va).toInt()
            1 -> if (va > ca) w = (ch * va).toInt() else h = (cw / va).toInt()
            else -> {}
        }
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w
            lp.height = h
            lp.gravity = Gravity.CENTER
            surface.layoutParams = lp
        }
    }

    private fun tick() {
        if (!::player.isInitialized) return
        val d = player.duration
        val p = player.currentPosition
        val known = d > 0
        if (!seeking) {
            seek.progress = if (known) (p * 1000 / d).toInt() else 0
            timeCur.text = fmt(p)
        }
        seek.secondaryProgress = if (known) (player.bufferedPosition * 1000 / d).toInt() else 0
        timeDur.text = if (known) fmt(d) else "--:--"
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
