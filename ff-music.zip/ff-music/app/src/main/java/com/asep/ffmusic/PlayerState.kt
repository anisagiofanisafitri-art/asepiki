package com.asep.ffmusic

// State bersama antara service & activity (satu proses)
object PlayerState {
    @Volatile var running = false
    @Volatile var playing = false
    @Volatile var title = ""
    @Volatile var idx = -1
    @Volatile var pos = 0L
    @Volatile var dur = 0L
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
