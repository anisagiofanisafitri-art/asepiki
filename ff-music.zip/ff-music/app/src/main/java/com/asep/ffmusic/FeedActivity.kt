package com.asep.ffmusic

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// Scroll video offline ala TikTok: geser ke atas = berikutnya, ke bawah = sebelumnya, ketuk = jeda.
// Video diulang terus sampai digeser. Cuma memutar file yang sudah tersimpan di dalam app (tanpa internet).
class FeedActivity : Activity() {
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var titleTv: TextView
    private lateinit var countTv: TextView
    private lateinit var pauseTv: TextView

    private var items = mutableListOf<VideoItem>()
    private var idx = 0
    private var tag = ""
    private var shuffle = false
    private var userPaused = false
    private var busy = false
    private var pausedMusic = false

    private var downY = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null
    private var vw = 0
    private var vh = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        tag = intent.getStringExtra("tag") ?: ""
        shuffle = intent.getBooleanExtra("shuffle", false)

        // cuma file tunggal yang masih ada (video YouTube 720p+ yang dipisah video/audio gak ikut)
        items = Store.saved(this)
            .filter { !it.src.contains("|") && File(it.src).length() > 0 && (tag.isEmpty() || it.tag == tag) }
            .toMutableList()
        if (items.isEmpty()) {
            Toast.makeText(this, "Belum ada video offline di sini", Toast.LENGTH_LONG).show()
            finish(); return
        }
        if (shuffle) items.shuffle() else idx = Store.int(this, "fp:$tag", 0).coerceIn(0, items.size - 1)

        buildUi()
        buildPlayer()
        hideBars()

        // musik & bubble disembunyiin selama nonton (sama kayak player video)
        svc("HIDE_SET") { it.putExtra("on", true) }
        if (PlayerState.running && PlayerState.playing) { svc("TOGGLE"); pausedMusic = true }

        player.setMediaItems(items.map { MediaItem.fromUri(Uri.fromFile(File(it.src))) })
        player.repeatMode = Player.REPEAT_MODE_ONE
        player.prepare()
        player.seekTo(idx, 0)
        player.playWhenReady = true
        showInfo()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onResume() {
        super.onResume()
        if (::player.isInitialized && !userPaused) player.play()
    }

    override fun onStop() {
        super.onStop()
        saveIdx()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        saveIdx()
        try { player.release() } catch (_: Throwable) {}
        svc("HIDE_SET") { it.putExtra("on", false) }
        if (pausedMusic && !PlayerState.playing) svc("TOGGLE")
        super.onDestroy()
    }

    private fun saveIdx() {
        if (!shuffle && items.isNotEmpty()) Store.putInt(this, "fp:$tag", idx)
    }

    private fun svc(action: String, f: (Intent) -> Unit = {}) {
        if (!PlayerState.running) return
        try { startService(Intent(this, OverlayService::class.java).setAction(action).also(f)) } catch (_: Throwable) {}
    }

    private fun hideBars() {
        val ic = WindowCompat.getInsetsController(window, window.decorView)
        ic.hide(WindowInsetsCompat.Type.systemBars())
        ic.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        titleTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; maxLines = 4
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setPadding(dp(16), 0, dp(16), dp(34))
        }
        root.addView(titleTv, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        countTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            gravity = Gravity.CENTER
        }
        root.addView(countTv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(40) })

        fun btn(t: String, g: Int, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { onClick() }
        }.also { root.addView(it, FrameLayout.LayoutParams(-2, -2, g).apply { topMargin = dp(32) }) }
        btn("✕", Gravity.TOP or Gravity.START) { finish() }
        btn("Hapus", Gravity.TOP or Gravity.END) { confirmDelete() }

        pauseTv = TextView(this).apply {
            text = "❚❚"; setTextColor(Color.WHITE); textSize = 56f; alpha = 0.85f
            setShadowLayer(10f, 0f, 0f, Color.BLACK)
            visibility = View.GONE
        }
        root.addView(pauseTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // HP dimiringin -> ukuran layar berubah -> pas ulang videonya
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) fit()
        }
        root.setOnTouchListener { _, e -> touch(e) }
        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildPlayer() {
        player = ExoPlayer.Builder(this).setHandleAudioBecomingNoisy(true).build()
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        player.setVideoSurfaceView(surface)
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) {
                vw = (v.width * v.pixelWidthHeightRatio).toInt()
                vh = v.height
                fit()
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // file rusak: lewati ke video berikutnya
                if (items.size > 1) go((idx + 1) % items.size, true)
            }
        })
    }

    // video 9:16 diisi penuh layar; kalau bentuknya jauh beda (mendatar) dipas biar gak kepotong
    private fun fit() {
        val w = root.width
        val h = root.height
        if (vw <= 0 || vh <= 0) return
        if (w <= 0 || h <= 0) { root.post { fit() }; return }
        val sFit = min(w.toFloat() / vw, h.toFloat() / vh)
        val sFill = max(w.toFloat() / vw, h.toFloat() / vh)
        val s = if (sFill / sFit <= 1.25f) sFill else sFit
        val nw = (vw * s).toInt()
        val nh = (vh * s).toInt()
        val lp = surface.layoutParams
        if (lp == null || lp.width != nw || lp.height != nh) {
            surface.layoutParams = FrameLayout.LayoutParams(nw, nh, Gravity.CENTER)
        }
    }

    private fun showInfo() {
        val v = items.getOrNull(idx) ?: return
        titleTv.text = v.title
        countTv.text = "${idx + 1} / ${items.size}" + if (tag.isNotEmpty()) "  •  $tag" else ""
    }

    // ---------------- gestur ----------------
    private fun touch(e: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (busy) return true
                downY = e.rawY; dragging = false
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (busy) return true
                vt?.addMovement(e)
                val dy = e.rawY - downY
                if (!dragging && abs(dy) > slop) dragging = true
                if (dragging) surface.translationY = dy * 0.9f
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (busy) return true
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle(); vt = null
                val dy = e.rawY - downY
                if (!dragging) {
                    if (e.actionMasked == MotionEvent.ACTION_UP) togglePause()
                    return true
                }
                val th = root.height * 0.16f
                when {
                    (dy < -th || vy < -1100f) && items.size > 1 -> go((idx + 1) % items.size, true)
                    (dy > th || vy > 1100f) && items.size > 1 -> go((idx - 1 + items.size) % items.size, false)
                    else -> surface.animate().translationY(0f).setDuration(160).start()
                }
            }
        }
        return true
    }

    private fun togglePause() {
        userPaused = !userPaused
        if (userPaused) { player.pause(); pauseTv.visibility = View.VISIBLE }
        else { player.play(); pauseTv.visibility = View.GONE }
    }

    // pindah video: geser keluar, ganti, lalu masuk dari sisi sebaliknya
    private fun go(to: Int, up: Boolean) {
        if (busy) return
        busy = true
        val h = root.height.toFloat()
        surface.animate().translationY(if (up) -h else h).setDuration(150).withEndAction {
            idx = to
            player.seekTo(idx, 0)
            if (!userPaused) player.play()
            showInfo()
            surface.translationY = if (up) h else -h
            surface.animate().translationY(0f).setDuration(190).withEndAction { busy = false }.start()
        }.start()
    }

    private fun confirmDelete() {
        val v = items.getOrNull(idx) ?: return
        player.pause()
        AlertDialog.Builder(this).setTitle(v.title.take(60))
            .setMessage("Hapus video ini dari HP?")
            .setPositiveButton("Hapus") { _, _ ->
                Store.removeSaved(this, v.src)
                items.removeAt(idx)
                player.removeMediaItem(idx)
                if (items.isEmpty()) { finish(); return@setPositiveButton }
                idx = min(idx, items.size - 1)
                player.seekTo(idx, 0)
                if (!userPaused) player.play()
                showInfo()
            }
            .setNegativeButton("Batal") { _, _ -> if (!userPaused) player.play() }
            .setOnCancelListener { if (!userPaused) player.play() }
            .show()
    }
}
