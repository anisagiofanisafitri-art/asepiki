package com.asep.ffmusic

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// Update langsung dari GitHub Releases: cek versi -> unduh -> cek tanda tangan -> pasang
object Updater {
    class Info(val version: String, val notes: String, val apkUrl: String, val size: Long)

    fun repo(c: Context): String {
        val r = (Store.str(c, "repo") ?: "").trim()
        return if (r.contains("/")) r else BuildConfig.UPDATE_REPO
    }

    // panggil dari thread background. null = sudah versi terbaru
    fun check(c: Context): Info? {
        val r = repo(c)
        if (r.isEmpty()) throw IllegalStateException("Repo GitHub belum diisi")
        val con = URL("https://api.github.com/repos/$r/releases/latest").openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 12000
        con.setRequestProperty("Accept", "application/vnd.github+json")
        con.setRequestProperty("User-Agent", "FFMusic-Updater")
        if (con.responseCode == 404) throw IllegalStateException("Belum ada release di GitHub")
        val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
        val tag = j.getString("tag_name").removePrefix("v")
        if (!newer(tag, c.appVersion())) return null
        val assets = j.optJSONArray("assets") ?: throw IllegalStateException("Release gak punya file APK")
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk", true)) {
                return Info(tag, j.optString("body"), a.getString("browser_download_url"), a.optLong("size"))
            }
        }
        throw IllegalStateException("Release gak punya file APK")
    }

    // 3.3.12 lebih baru dari 3.3.9 (dibandingkan per angka, bukan per huruf)
    fun newer(a: String, b: String): Boolean {
        fun parts(s: String) = s.trim().removePrefix("v").split('.', '-', '+')
            .map { it.takeWhile { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        val x = parts(a)
        val y = parts(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }
            val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    fun download(c: Context, info: Info, onProgress: (Int) -> Unit): File {
        val dir = File(c.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "FFMusic-${info.version}.apk")
        dir.listFiles()?.filter { it != out }?.forEach { it.delete() }
        // sudah pernah diunduh penuh (misal tadi baru izinin "pasang dari sumber ini") -> pakai lagi
        if (out.exists() && info.size > 0 && out.length() == info.size) return out
        val con = URL(info.apkUrl).openConnection() as HttpURLConnection
        con.connectTimeout = 10000
        con.readTimeout = 20000
        con.instanceFollowRedirects = true
        con.setRequestProperty("User-Agent", "FFMusic-Updater")
        val total = if (con.contentLengthLong > 0) con.contentLengthLong else info.size
        var done = 0L
        var last = -1
        con.inputStream.use { i ->
            out.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) { last = p; onProgress(p) }
                    }
                }
            }
        }
        if (total > 0 && done < total) { out.delete(); throw IllegalStateException("Unduhan terputus") }
        return out
    }

    @Suppress("DEPRECATION")
    private fun sigs(p: PackageInfo?): Set<String> {
        if (p == null) return emptySet()
        return if (Build.VERSION.SDK_INT >= 28) {
            p.signingInfo?.apkContentsSigners?.map { it.toCharsString() }?.toSet() ?: emptySet()
        } else {
            p.signatures?.map { it.toCharsString() }?.toSet() ?: emptySet()
        }
    }

    // true = tanda tangan sama (aman ditimpa). false = beda -> Android pasti nolak ("konflik")
    @Suppress("DEPRECATION")
    fun signatureOk(c: Context, apk: File): Boolean {
        return try {
            val pm = c.packageManager
            val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
            val inst = sigs(pm.getPackageInfo(c.packageName, flags))
            val arc = sigs(pm.getPackageArchiveInfo(apk.path, flags))
            inst.isEmpty() || arc.isEmpty() || inst == arc   // kalau gak bisa dicek, biar Android yang mutusin
        } catch (_: Exception) { true }
    }

    // false = user belum kasih izin "pasang app dari sumber ini" (halaman izinnya dibuka)
    fun install(a: Activity, f: File): Boolean {
        if (!a.packageManager.canRequestPackageInstalls()) {
            a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${a.packageName}")))
            return false
        }
        val uri = FileProvider.getUriForFile(a, "${a.packageName}.fileprovider", f)
        a.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
