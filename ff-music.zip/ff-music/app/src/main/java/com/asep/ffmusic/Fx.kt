package com.asep.ffmusic

import android.content.Context

// Preset & kurva equalizer 5 pita (-1..1 per pita), dipakai service & halaman Setelan
object Fx {
    val names = listOf("Normal", "Bass", "Vokal", "Treble", "Game", "Custom")
    val bandNames = listOf("60Hz", "230Hz", "910Hz", "3.6k", "14k")

    private val presets = arrayOf(
        floatArrayOf(0f, 0f, 0f, 0f, 0f),
        floatArrayOf(0.8f, 0.6f, 0.1f, 0f, 0f),
        floatArrayOf(-0.1f, 0.2f, 0.6f, 0.5f, 0f),
        floatArrayOf(-0.2f, 0f, 0.1f, 0.6f, 0.8f),
        floatArrayOf(-0.4f, -0.2f, 0.3f, 0.7f, 0.5f)   // Game: langkah kaki & tembakan lebih jelas
    )

    fun curve(c: Context, preset: Int): FloatArray =
        if (preset in presets.indices) presets[preset].copyOf()
        else FloatArray(5) { Store.int(c, "eqb$it", 0) / 100f }

    // gain Kenceng+ (mB); migrasi dari toggle lama
    fun loudGain(c: Context): Int {
        val v = Store.int(c, "loudg", -1)
        return if (v >= 0) v else if (Store.int(c, "loud", 0) == 1) 800 else 0
    }
}
