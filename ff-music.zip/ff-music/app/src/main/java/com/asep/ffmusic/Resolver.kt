package com.asep.ffmusic

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Cari lagu + ambil stream audio lewat Piped API (coba beberapa server sampai ada yg hidup)
object Resolver {
    class Hit(val title: String, val id: String, val by: String)

    // server buatan sendiri (Setelan) dicoba paling dulu
    @Volatile var custom: String? = null

    private val defaults = listOf(
        "https://pipedapi.kavin.rocks",
        "https://api.piped.private.coffee",
        "https://pipedapi.adminforge.de",
        "https://pipedapi.leptons.xyz",
        "https://pipedapi.reallyaweso.me",
        "https://pipedapi.drgns.space"
    )

    fun hosts(): List<String> =
        listOfNotNull(custom?.takeIf { it.startsWith("http") }) + defaults

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun streamOf(h: String, id: String): String? {
        val a = JSONObject(get("$h/streams/$id")).getJSONArray("audioStreams")
        var best: String? = null
        var br = -1
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val b = o.optInt("bitrate")
            val u = o.optString("url")
            if (b > br && u.startsWith("http")) { br = b; best = u }
        }
        return best
    }

    fun ytTitle(id: String): String? = try {
        JSONObject(get("https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$id&format=json")).getString("title")
    } catch (_: Exception) { null }

    fun byId(id: String): String? {
        // 1) penyedia yang sama dengan Videy Bot (savetube dkk, audio mp3)  2) Piped sebagai cadangan
        Providers.ytAudio(id)?.let { return it }
        for (h in hosts()) {
            try { streamOf(h, id)?.let { return it } } catch (_: Exception) {}
        }
        return null
    }

    fun bySearch(q: String): String? {
        for (hit in search(q).take(3)) {
            byId(hit.id)?.let { return it }
        }
        return null
    }

    // daftar hasil pencarian buat ditampilin di tab Tambah
    fun search(q: String): List<Hit> {
        // pencarian langsung ke YouTube dulu (cepat), Piped cuma cadangan
        try {
            val r = Providers.ytSearch(q)
            if (r.isNotEmpty()) return r.map { Hit(it.title, it.id, it.by) }
        } catch (_: Exception) {}
        for (h in hosts()) {
            try {
                val items = JSONObject(get("$h/search?q=${URLEncoder.encode(q, "UTF-8")}&filter=music_songs"))
                    .getJSONArray("items")
                val out = mutableListOf<Hit>()
                for (i in 0 until minOf(items.length(), 12)) {
                    val o = items.getJSONObject(i)
                    val u = o.optString("url")
                    if (u.contains("v=")) {
                        out.add(Hit(o.optString("title"), u.substringAfter("v=").substringBefore("&"), o.optString("uploaderName")))
                    }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {}
        }
        return emptyList()
    }
}
