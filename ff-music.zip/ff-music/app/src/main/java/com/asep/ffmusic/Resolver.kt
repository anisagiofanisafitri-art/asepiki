package com.asep.ffmusic

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Cari lagu + ambil stream audio lewat Piped API (coba beberapa instance sampai ada yg hidup)
object Resolver {
    private val hosts = listOf(
        "https://pipedapi.kavin.rocks",
        "https://api.piped.private.coffee",
        "https://pipedapi.adminforge.de",
        "https://pipedapi.leptons.xyz"
    )

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun streamOf(h: String, id: String): String? {
        val a = JSONObject(get("$h/streams/$id")).getJSONArray("audioStreams")
        var best: String? = null
        var br = -1
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val b = o.optInt("bitrate")
            val u = o.optString("url")
            if (b > br && u.startsWith("http")) { br = b; best = u }
        }
        return best
    }

    fun byId(id: String): String? {
        for (h in hosts) {
            try { streamOf(h, id)?.let { return it } } catch (_: Exception) {}
        }
        return null
    }

    fun bySearch(q: String): String? {
        for (h in hosts) {
            try {
                val items = JSONObject(get("$h/search?q=${URLEncoder.encode(q, "UTF-8")}&filter=music_songs"))
                    .getJSONArray("items")
                for (i in 0 until minOf(items.length(), 3)) {
                    val u = items.getJSONObject(i).optString("url")
                    if (u.contains("v=")) {
                        val s = streamOf(h, u.substringAfter("v=").substringBefore("&"))
                        if (s != null) return s
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }
}
