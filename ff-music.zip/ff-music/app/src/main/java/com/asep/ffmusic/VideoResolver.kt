package com.asep.ffmusic

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Ambil link stream video lewat API pihak ketiga:
//  - YouTube : Piped (banyak server, dicoba satu-satu), kualitas 144p sampai 4K
//  - TikTok  : TikWM
//  - Opsional: Cobalt (server sendiri, bisa YouTube/TikTok/Instagram/Twitter dll)
//  - Link video langsung (.mp4 .webm .m3u8 dll) diputar apa adanya
object VideoResolver {
    const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    // audioUrl != null -> video-only, harus digabung dengan audio saat diputar (kualitas 720p ke atas di YouTube)
    class Stream(
        val label: String, val height: Int, val fps: Int,
        val url: String, val audioUrl: String?, val source: String, val hls: Boolean = false
    )

    class Result(val title: String, val streams: List<Stream>, val kind: String)

    private fun http(u: String, post: String? = null, headers: Map<String, String> = emptyMap(), readMs: Int = 12000): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (post != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.outputStream.use { it.write(post.toByteArray()) }
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IllegalStateException("HTTP $code ${body.take(120)}")
        return body
    }

    fun firstUrl(text: String): String? =
        Regex("https?://[^\\s]+").find(text)?.value?.trimEnd(')', ']', '.', ',', '"', '\'')

    private val ytRe = Regex("(?:youtu\\.be/|youtube\\.com/(?:watch\\?(?:[^#\\s]*&)?v=|shorts/|embed/|live/|v/)|youtube-nocookie\\.com/embed/)([A-Za-z0-9_-]{11})")
    fun ytId(s: String): String? = ytRe.find(s)?.groupValues?.get(1)

    private fun isTikTok(u: String) = Regex("^https?://([a-z0-9-]+\\.)?tiktok\\.com/", RegexOption.IGNORE_CASE).containsMatchIn(u)

    private fun isDirect(u: String): Boolean {
        val p = (Uri.parse(u).path ?: "").lowercase()
        return listOf(".mp4", ".webm", ".mkv", ".mov", ".m4v", ".3gp", ".m3u8", ".mpd", ".ts").any { p.endsWith(it) }
    }

    // pilih stream: kualitas tertinggi yang <= keinginan, kalau gak ada ambil yang paling rendah
    fun pick(s: List<Stream>, want: Int): Int {
        if (s.size <= 1) return 0
        val i = s.indexOfFirst { it.height in 1..want }
        return if (i >= 0) i else s.size - 1
    }

    fun resolve(c: Context, input: String, wantHeight: Int): Result {
        val url = firstUrl(input) ?: throw IllegalArgumentException("Link gak valid")
        val problems = mutableListOf<String>()

        val yt = ytId(url)
        if (yt != null) {
            try { return youtube(yt) } catch (e: Exception) { problems.add("YouTube: ${e.message}") }
            cobalt(c, url, wantHeight)?.let { return it }
            throw IllegalStateException("Semua server YouTube gagal/mati. Coba lagi nanti atau isi server sendiri di Setelan.\n${problems.joinToString("\n")}")
        }
        if (isTikTok(url)) {
            try { return tiktok(url) } catch (e: Exception) { problems.add("TikTok: ${e.message}") }
            cobalt(c, url, wantHeight)?.let { return it }
            throw IllegalStateException("TikTok gagal: ${problems.joinToString(" ")}")
        }
        if (isDirect(url)) {
            val title = Uri.parse(url).lastPathSegment ?: "Video"
            return Result(title, listOf(Stream("Langsung", 0, 0, url, null, "direct", url.lowercase().contains(".m3u8"))), "direct")
        }
        cobalt(c, url, wantHeight)?.let { return it }
        throw IllegalArgumentException("Link ini belum didukung. Bisa: YouTube, TikTok, link video langsung. Situs lain butuh server Cobalt (Setelan).")
    }

    // ---------- YouTube via Piped ----------
    private fun youtube(id: String): Result {
        var last: Exception? = null
        for (h in Resolver.hosts()) {
            try {
                val j = JSONObject(http("$h/streams/$id"))
                val title = j.optString("title").ifBlank { "YouTube" }
                val audio = bestAudio(j.optJSONArray("audioStreams") ?: JSONArray())
                val list = buildYt(j.optJSONArray("videoStreams") ?: JSONArray(), audio)
                if (list.isNotEmpty()) return Result(title, list, "yt")
                val hls = j.optString("hls")
                if (hls.startsWith("http")) return Result(title, listOf(Stream("Auto", 0, 0, hls, null, "yt", true)), "yt")
                last = IllegalStateException("Server $h gak ngasih stream")
            } catch (e: Exception) { last = e }
        }
        throw last ?: IllegalStateException("Semua server Piped mati")
    }

    private fun bestAudio(a: JSONArray): String? {
        var best: String? = null
        var bestScore = -1
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val u = o.optString("url")
            if (!u.startsWith("http")) continue
            val t = o.optString("audioTrackType", "ORIGINAL")
            val original = t.isEmpty() || t == "null" || t.equals("ORIGINAL", true)   // hindari track dubbing
            val score = o.optInt("bitrate") + if (original) 10_000_000 else 0
            if (score > bestScore) { bestScore = score; best = u }
        }
        return best
    }

    private fun buildYt(vs: JSONArray, audio: String?): List<Stream> {
        class Cand(val stream: Stream, val rank: Int)
        val best = HashMap<String, Cand>()
        for (i in 0 until vs.length()) {
            val o = vs.getJSONObject(i)
            val u = o.optString("url")
            if (!u.startsWith("http")) continue
            val fmt = o.optString("format")
            if (fmt.contains("3GPP", true) || fmt.startsWith("v3")) continue
            val h = o.optInt("height").takeIf { it > 0 }
                ?: Regex("(\\d+)p").find(o.optString("quality"))?.groupValues?.get(1)?.toIntOrNull()
                ?: continue
            val fps = o.optInt("fps", 30)
            val vOnly = o.optBoolean("videoOnly", false)
            if (vOnly && audio == null) continue
            val codec = o.optString("codec").lowercase()
            // avc1 paling aman (hampir semua HP punya decoder hardware), lalu vp9, lalu av1.
            // 4K di YouTube cuma ada vp9/av1.
            val rank = (when {
                codec.startsWith("avc1") -> 30
                codec.startsWith("vp9") || codec.startsWith("vp09") -> 20
                codec.startsWith("av01") -> 10
                else -> 0
            }) + if (!vOnly) 5 else 0
            val key = "$h-${if (fps > 30) 60 else 30}"
            val tag = when {
                h >= 4320 -> " 8K"
                h >= 2160 -> " 4K"
                h >= 1440 -> " 2K"
                else -> ""
            }
            val label = "${h}p${if (fps > 30) "60" else ""}$tag"
            val cur = best[key]
            if (cur == null || rank > cur.rank) {
                best[key] = Cand(Stream(label, h, fps, u, if (vOnly) audio else null, "yt"), rank)
            }
        }
        return best.values.map { it.stream }
            .sortedWith(compareByDescending<Stream> { it.height }.thenByDescending { it.fps })
    }

    // ---------- TikTok via TikWM ----------
    private fun tiktok(url: String): Result {
        val j = JSONObject(http("https://www.tikwm.com/api/?hd=1&url=" + URLEncoder.encode(url, "UTF-8")))
        if (j.optInt("code", -1) != 0) throw IllegalStateException(j.optString("msg", "gagal ambil video"))
        val d = j.getJSONObject("data")
        fun abs(u: String) = when {
            u.startsWith("http") -> u
            u.startsWith("/") -> "https://www.tikwm.com$u"
            else -> ""
        }
        val title = d.optString("title").ifBlank { "TikTok" }
        val list = mutableListOf<Stream>()
        abs(d.optString("hdplay")).takeIf { it.isNotEmpty() }?.let { list.add(Stream("HD", 1080, 30, it, null, "tiktok")) }
        abs(d.optString("play")).takeIf { it.isNotEmpty() }?.let { list.add(Stream("SD", 720, 30, it, null, "tiktok")) }
        if (list.isEmpty()) throw IllegalStateException("postingan ini bukan video (foto) atau privat")
        return Result(title, list, "tiktok")
    }

    // ---------- Cobalt (opsional, server sendiri) ----------
    private fun cobalt(c: Context, url: String, want: Int): Result? {
        val base = (Store.str(c, "cobalt") ?: "").trim().trimEnd('/')
        if (!base.startsWith("http")) return null
        val key = (Store.str(c, "cobaltkey") ?: "").trim()
        val q = when {
            want >= 2160 -> 2160
            want >= 1440 -> 1440
            want >= 1080 -> 1080
            want >= 720 -> 720
            want >= 480 -> 480
            else -> 360
        }
        val body = JSONObject().put("url", url).put("videoQuality", q.toString())
            .put("filenameStyle", "basic").put("youtubeVideoCodec", if (q >= 1440) "vp9" else "h264")
        val hdr = mutableMapOf("Accept" to "application/json", "Content-Type" to "application/json")
        if (key.isNotEmpty()) hdr["Authorization"] = "Api-Key $key"
        val j = JSONObject(http("$base/", body.toString(), hdr, 30000))
        val title = j.optString("filename").substringBeforeLast('.').ifBlank { "Video" }
        return when (j.optString("status")) {
            "tunnel", "redirect" -> Result(title, listOf(Stream("Cobalt ${q}p", q, 30, j.getString("url"), null, "cobalt")), "cobalt")
            "picker" -> {
                val p = j.optJSONArray("picker") ?: JSONArray()
                var found: String? = null
                for (i in 0 until p.length()) {
                    val o = p.getJSONObject(i)
                    if (o.optString("type") == "video") { found = o.optString("url"); break }
                }
                if (found == null) throw IllegalStateException("Cobalt: gak ada video di postingan ini")
                Result(title, listOf(Stream("Cobalt", q, 30, found, null, "cobalt")), "cobalt")
            }
            else -> throw IllegalStateException("Cobalt: " + (j.optJSONObject("error")?.optString("code") ?: "ditolak"))
        }
    }
}
