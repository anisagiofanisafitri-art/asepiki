package com.asep.ffmusic

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var player: ExoPlayer
    private lateinit var cache: SimpleCache
    private var root: LinearLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var spin: ObjectAnimator
    private lateinit var titleTv: TextView
    private lateinit var playBtn: TextView
    private lateinit var repeatBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView

    private var tracks = listOf<Track>()
    private var idx = 0
    private var hidden = false
    private var seeking = false
    private var triedSaved = false
    private var errorStreak = 0
    private var token = 0
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 500) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cache = SimpleCache(File(cacheDir, "media"), LeastRecentlyUsedCacheEvictor(300L * 1024 * 1024), StandaloneDatabaseProvider(this))
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0").setAllowCrossProtocolRedirects(true)
        val cds = CacheDataSource.Factory().setCache(cache)
            .setUpstreamDataSourceFactory(DefaultDataSource.Factory(this, http))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(cds))
            .build().apply {
                // handleAudioFocus=false -> lagu jalan bareng suara game
                setAudioAttributes(
                    AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false
                )
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_ENDED) {
                            if (Store.int(this@OverlayService, "repeat", 0) == 1) { player.seekTo(0); player.play() } else next()
                        }
                    }
                    override fun onIsPlayingChanged(p: Boolean) {
                        playBtn.text = if (p) "❚❚" else "▶"
                        PlayerState.playing = p
                        if (p) { errorStreak = 0; if (!spin.isStarted) spin.start() else spin.resume() }
                        else if (spin.isStarted) spin.pause()
                    }
                    override fun onPlayerError(e: PlaybackException) {
                        val t = tracks.getOrNull(idx)
                        if (triedSaved && t != null) { triedSaved = false; resolveFresh(t, token) }
                        else fail("Gagal muter")
                    }
                })
            }
        buildOverlay()
        applySettings()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ffm", "Floating Player", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, 1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        PlayerState.running = true
        ui.post(ticker)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "START" -> {
                tracks = Store.load(this)
                if (tracks.isEmpty()) { toast("Playlist kosong"); stopSelf(); return START_NOT_STICKY }
                setHidden(false)
                applySettings()
                playIndex(i!!.getIntExtra("idx", 0).coerceIn(0, tracks.size - 1))
            }
            "TOGGLE" -> toggle()
            "NEXT" -> next()
            "PREV" -> prev()
            "HIDE" -> setHidden(!hidden)
            "APPLY" -> applySettings()
            "SEEK" -> {
                val d = player.duration
                if (d > 0) player.seekTo((d * i!!.getFloatExtra("f", 0f)).toLong())
            }
            "STOP" -> stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------- notifikasi ----------
    private fun act(a: String, label: String) = NotificationCompat.Action(
        0, label,
        PendingIntent.getService(
            this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    )

    private fun notif(): Notification =
        NotificationCompat.Builder(this, "ffm")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (PlayerState.title.isEmpty()) "FF Music" else PlayerState.title)
            .setContentText("Floating player aktif")
            .setOngoing(true)
            .addAction(act("TOGGLE", "Play/Pause"))
            .addAction(act("NEXT", "Next"))
            .addAction(act("HIDE", "Tampil/Sembunyi"))
            .addAction(act("STOP", "Stop"))
            .build()

    private fun announce(t: Track) {
        titleTv.text = t.title
        PlayerState.title = t.title
        PlayerState.idx = idx
        Store.putInt(this, "last", idx)
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    // ---------- player ----------
    private fun playIndex(n: Int) {
        if (tracks.isEmpty()) return
        idx = n
        val t = tracks[n]
        val my = ++token
        player.stop()
        announce(t)
        when (t.kind) {
            "file" -> goFile(t)
            "url" -> { triedSaved = false; goNet(t.src, t) }
            else -> {
                val saved = Store.str(this, "u:" + t.src)
                if (saved != null) { triedSaved = true; goNet(saved, t) }
                else { triedSaved = false; titleTv.text = "◌ ${t.title}"; resolveFresh(t, my) }
            }
        }
    }

    private fun resolveFresh(t: Track, my: Int) {
        io.execute {
            val u = if (t.kind == "yt") Resolver.byId(t.src) else Resolver.bySearch(t.src)
            ui.post {
                if (my != token) return@post
                if (u == null) fail("Gak ketemu: ${t.title}")
                else { Store.putStr(this, "u:" + t.src, u); goNet(u, t) }
            }
        }
    }

    private fun goNet(u: String, t: Track) {
        titleTv.text = t.title
        player.setMediaItem(MediaItem.Builder().setUri(u).setCustomCacheKey(t.src).build())
        player.prepare(); player.play()
    }

    private fun goFile(t: Track) {
        titleTv.text = t.title
        player.setMediaSource(
            ProgressiveMediaSource.Factory(DefaultDataSource.Factory(this)).createMediaSource(MediaItem.fromUri(t.src))
        )
        player.prepare(); player.play()
    }

    private fun fail(msg: String) {
        toast(msg)
        errorStreak++
        if (errorStreak < tracks.size) next()
    }

    private fun next() {
        if (tracks.isEmpty()) return
        val n = if (Store.int(this, "repeat", 0) == 2 && tracks.size > 1) {
            var r = idx
            while (r == idx) r = tracks.indices.random()
            r
        } else (idx + 1) % tracks.size
        playIndex(n)
    }

    private fun prev() {
        if (tracks.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        playIndex((idx - 1 + tracks.size) % tracks.size)
    }

    private fun toggle() { if (player.isPlaying) player.pause() else player.play() }

    private fun tick() {
        val d = player.duration
        PlayerState.pos = player.currentPosition
        PlayerState.dur = if (d == C.TIME_UNSET || d < 0) 0 else d
        if (panel.visibility == View.VISIBLE && !seeking) {
            seek.progress = if (PlayerState.dur > 0) (PlayerState.pos * 1000 / PlayerState.dur).toInt() else 0
            timeTv.text = "${fmt(PlayerState.pos)} / ${fmt(PlayerState.dur)}"
        }
    }

    // ---------- overlay ----------
    private fun repeatIcon() = when (Store.int(this, "repeat", 0)) { 1 -> "↻1"; 2 -> "⇄"; else -> "↻" }

    private fun applySettings() {
        val sz = when (Store.int(this, "size", 1)) { 0 -> 44; 2 -> 62; else -> 52 }
        bubble.layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz))
        root?.alpha = Store.int(this, "opacity", 100) / 100f
        repeatBtn.text = repeatIcon()
    }

    private fun setHidden(h: Boolean) {
        hidden = h
        root?.visibility = if (h) View.GONE else View.VISIBLE
    }

    private fun ctl(label: String, size: Float = 17f, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = rounded(Color.parseColor("#22FFFFFF"), 18)
        layoutParams = LinearLayout.LayoutParams(dp(37), dp(37)).apply { marginEnd = dp(4) }
        setOnClickListener { onClick() }
    }

    private fun drag(v: View, onTap: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; root?.let { wm.updateViewLayout(it, lp) } }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun buildOverlay() {
        bubble = TextView(this).apply {
            text = "♫"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = oval(CYAN, PINK)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        spin = ObjectAnimator.ofFloat(bubble, "rotation", 0f, 360f).apply {
            duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        }
        titleTv = TextView(this).apply {
            text = "FF Music"; setTextColor(Color.WHITE); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1; isSelected = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        playBtn = ctl("▶", 19f) { toggle() }.apply { background = oval(CYAN, PINK) }
        repeatBtn = ctl("↻") {
            val m = (Store.int(this, "repeat", 0) + 1) % 3
            Store.putInt(this, "repeat", m)
            repeatBtn.text = repeatIcon()
            toast(when (m) { 1 -> "Ulang 1 lagu"; 2 -> "Acak"; else -> "Ulang semua" })
        }
        timeTv = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(MUTED); textSize = 10f; gravity = Gravity.END }
        seek = SeekBar(this).apply {
            max = 1000; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u && PlayerState.dur > 0) player.seekTo(PlayerState.dur * p / 1000)
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) { seeking = false }
            })
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(titleTv)
            addView(TextView(context).apply {
                text = "✕"; setTextColor(MUTED); textSize = 16f; setPadding(dp(10), 0, 0, 0)
                setOnClickListener { stopSelf() }
            })
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
            addView(ctl("|◀") { prev() })
            addView(playBtn)
            addView(ctl("▶|") { next() })
            addView(repeatBtn)
            addView(ctl("—") { panel.visibility = View.GONE })
            addView(ctl("◎") { setHidden(true); toast("Disembunyiin. Buka lewat notifikasi → Tampil/Sembunyi") })
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#F00B0B14"), 22, CYAN)
            setPadding(dp(14), dp(12), dp(10), dp(8))
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) }
            addView(top); addView(seek); addView(timeTv); addView(row)
        }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bubble); addView(panel)
        }
        drag(bubble) { panel.visibility = if (panel.visibility == View.GONE) View.VISIBLE else View.GONE }
        drag(titleTv, null)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(140) }
        wm.addView(r, lp)
        root = r
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        token++
        ui.removeCallbacksAndMessages(null)
        PlayerState.running = false
        PlayerState.playing = false
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        spin.cancel()
        player.release()
        cache.release()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
}
