package com.asep.ffmusic

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var player: ExoPlayer
    private lateinit var cache: SimpleCache
    private var root: LinearLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var spin: ObjectAnimator
    private lateinit var titleTv: TextView
    private lateinit var playBtn: TextView
    private lateinit var repeatBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var hudTv: TextView
    private lateinit var volBar: SeekBar
    private lateinit var speedBtn: TextView
    private lateinit var eqBtn: TextView
    private lateinit var turboBtn: TextView
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var le: LoudnessEnhancer? = null
    private var vz: Virtualizer? = null
    private var session: MediaSession? = null
    private var fxSid = -1
    private var introView: GameIntroView? = null

    private var tracks = listOf<Track>()
    private var idx = 0
    private var hidden = false
    private var seeking = false
    private var triedSaved = false
    private var errorStreak = 0
    private var token = 0
    private var tickN = 0L
    private val sleepOpts = intArrayOf(0, 15, 30, 60, 90)
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f)
    private val speedLabels = listOf("0.75x", "1x", "1.25x", "1.5x")
    private var fadeUntil = 0L
    private var lastBoost = System.currentTimeMillis()
    private var boosting = false
    private var ping = -1
    private var pingBusy = false
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private val ticker = object : Runnable {
        override fun run() { tick(); ui.postDelayed(this, 250) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Resolver.custom = Store.str(this, "host")?.takeIf { it.isNotEmpty() }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cache = SimpleCache(File(cacheDir, "media"), LeastRecentlyUsedCacheEvictor(300L * 1024 * 1024), StandaloneDatabaseProvider(this))
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0").setAllowCrossProtocolRedirects(true)
        val cds = CacheDataSource.Factory().setCache(cache)
            .setUpstreamDataSourceFactory(DefaultDataSource.Factory(this, http))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(cds))
            .setHandleAudioBecomingNoisy(true)   // headset dicabut -> otomatis pause
            .setWakeMode(C.WAKE_MODE_NETWORK)    // CPU & wifi tetap nyala pas layar mati
            .build().apply {
                // handleAudioFocus=false -> lagu jalan bareng suara game
                setAudioAttributes(
                    AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false
                )
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_ENDED) {
                            if (Store.int(this@OverlayService, "repeat", 0) == 1) { player.seekTo(0); player.play() } else next()
                        }
                        if (state == Player.STATE_READY && player.audioSessionId != fxSid) initFx()
                    }
                    override fun onIsPlayingChanged(p: Boolean) {
                        playBtn.text = if (p) "❚❚" else "▶\uFE0E"
                        PlayerState.playing = p
                        updateSession()
                        if (p) { errorStreak = 0; if (!spin.isStarted) spin.start() else spin.resume() }
                        else if (spin.isStarted) spin.pause()
                    }
                    override fun onPlayerError(e: PlaybackException) {
                        val t = tracks.getOrNull(idx)
                        if (triedSaved && t != null) { triedSaved = false; resolveFresh(t, token) }
                        else fail("Gagal muter")
                    }
                })
            }
        buildOverlay()
        applySettings()
        armSleep()
        initSession()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ffm", "Floating Player", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, 1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        PlayerState.running = true
        ui.post(ticker)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "START" -> {
                tracks = Store.activeTracks(this)
                if (tracks.isEmpty()) { toast("Album kosong"); stopSelf(); return START_NOT_STICKY }
                setHidden(false)
                applySettings()
                armSleep()
                playIndex(i!!.getIntExtra("idx", 0).coerceIn(0, tracks.size - 1))
            }
            "ALBUM" -> {
                tracks = Store.activeTracks(this)
                if (tracks.isEmpty()) { toast("Album kosong"); return START_NOT_STICKY }
                playIndex(i!!.getIntExtra("idx", 0).coerceIn(0, tracks.size - 1))
            }
            "RELOAD" -> {
                // daftar lagu diubah dari app, lagu yang lagi jalan gak diputus
                val cur = tracks.getOrNull(idx)
                tracks = Store.activeTracks(this)
                val k = tracks.indexOfFirst { it.src == cur?.src }
                if (k >= 0) { idx = k; PlayerState.idx = k }
                PlayerState.album = Store.int(this, "album", 0)
            }
            "TOGGLE" -> toggle()
            "NEXT" -> next()
            "PREV" -> prev()
            "HIDE" -> setHidden(!hidden)
            "BOOST" -> doBoost(true)
            "APPLY" -> applySettings()
            "SLEEP" -> { armSleep(); applySettings() }
            "SEEK" -> {
                val d = player.duration
                if (d > 0) player.seekTo((d * i!!.getFloatExtra("f", 0f)).toLong())
            }
            "STOP" -> stopSelf()
        }
        // animasi Mode Game (dikirim dari app lewat START / INTRO)
        i?.takeIf { it.action == "START" || it.action == "INTRO" }
            ?.getStringArrayExtra("intro")?.let { showIntro(it.toList()) }
        if (i != null && i.action == "START" && i.getBooleanExtra("turbo", false)) setTurbo(true)
        if (i != null && i.action == "TURBO") setTurbo(i.getBooleanExtra("on", !PlayerState.turbo))
        return START_NOT_STICKY
    }

    // ---------- animasi Mode Game ----------
    private fun showIntro(lines: List<String>) {
        introView?.let { it.cancel(); try { wm.removeView(it) } catch (_: Exception) {} }
        introView = null
        val v = GameIntroView(this, lines)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, p)
            introView = v
            v.start {
                try { wm.removeView(v) } catch (_: Exception) {}
                if (introView === v) introView = null
            }
            buzz()
        } catch (_: Exception) {}
    }

    private fun buzz() {
        try {
            val vb = getSystemService(Vibrator::class.java)
            vb.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 35, 70, 35, 70, 140), -1))
        } catch (_: Throwable) {}
    }

    // ---------- notifikasi ----------
    private fun act(a: String, label: String) = NotificationCompat.Action(
        0, label,
        PendingIntent.getService(
            this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    )

    private fun notif(): Notification =
        NotificationCompat.Builder(this, "ffm")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (PlayerState.title.isEmpty()) "FF Music" else PlayerState.title)
            .setContentText("Floating player aktif")
            .setOngoing(true)
            .addAction(act("TOGGLE", "Play/Pause"))
            .addAction(act("NEXT", "Next"))
            .addAction(act("HIDE", "Tampil/Sembunyi"))
            .addAction(act("STOP", "Stop"))
            .build()

    private fun announce(t: Track) {
        titleTv.text = t.title
        PlayerState.title = t.title
        PlayerState.idx = idx
        PlayerState.album = Store.int(this, "album", 0)
        Store.putInt(this, "last", idx)
        updateSession()
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    // ---------- player ----------
    private fun playIndex(n: Int) {
        if (tracks.isEmpty()) return
        idx = n
        val t = tracks[n]
        val my = ++token
        player.stop()
        announce(t)
        Store.putInt(this, "pc:" + t.src, Store.int(this, "pc:" + t.src, 0) + 1)   // hitungan diputar
        if (Store.int(this, "fade", 1) == 1) { player.volume = 0f; fadeUntil = System.currentTimeMillis() + 2000 }
        else fadeUntil = 0L
        when (t.kind) {
            "file" -> goFile(t)
            "url" -> { triedSaved = false; goNet(t.src, t) }
            else -> {
                val saved = Store.str(this, "u:" + t.src)
                if (saved != null) { triedSaved = true; goNet(saved, t) }
                else { triedSaved = false; titleTv.text = "◌ ${t.title}"; resolveFresh(t, my) }
            }
        }
    }

    private fun resolveFresh(t: Track, my: Int) {
        io.execute {
            val u = if (t.kind == "yt") Resolver.byId(t.src) else Resolver.bySearch(t.src)
            ui.post {
                if (my != token) return@post
                if (u == null) fail("Gak ketemu: ${t.title}")
                else { Store.putStr(this, "u:" + t.src, u); goNet(u, t) }
            }
        }
    }

    private fun goNet(u: String, t: Track) {
        titleTv.text = t.title
        player.setMediaItem(MediaItem.Builder().setUri(u).setCustomCacheKey(t.src).build())
        player.prepare(); player.play()
    }

    private fun goFile(t: Track) {
        titleTv.text = t.title
        player.setMediaSource(
            ProgressiveMediaSource.Factory(DefaultDataSource.Factory(this)).createMediaSource(MediaItem.fromUri(t.src))
        )
        player.prepare(); player.play()
    }

    private fun fail(msg: String) {
        toast(msg)
        errorStreak++
        if (errorStreak < tracks.size) next()
    }

    private fun next() {
        if (tracks.isEmpty()) return
        val n = if (Store.int(this, "repeat", 0) == 2 && tracks.size > 1) {
            var r = idx
            while (r == idx) r = tracks.indices.random()
            r
        } else (idx + 1) % tracks.size
        playIndex(n)
    }

    private fun prev() {
        if (tracks.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        playIndex((idx - 1 + tracks.size) % tracks.size)
    }

    private fun toggle() { if (player.isPlaying) player.pause() else player.play() }

    private fun baseVol() = Store.int(this, "vol", 100) / 100f

    private fun armSleep() {
        val m = sleepOpts[Store.int(this, "sleepsel", 0).coerceIn(0, sleepOpts.size - 1)]
        PlayerState.sleepAt = if (m > 0) System.currentTimeMillis() + m * 60_000L else 0L
    }

    private fun updateHud() {
        if (Store.int(this, "hud", 1) != 1) return
        val b = Booster.battery(this)
        val hot = b.temp >= 42f
        val t = "%.1f".format(b.temp)
        val p = if (ping >= 0) "  •  PING ${ping}ms" else ""
        hudTv.text = "BAT ${b.pct}%  •  $t°C${if (hot) " PANAS" else ""}  •  RAM ${Booster.availMb(this)} MB$p"
        hudTv.setTextColor(if (hot) PINK else Color.parseColor("#CCFFFFFF"))
    }

    private fun tick() {
        tickN++
        val now = System.currentTimeMillis()
        val d = player.duration
        PlayerState.pos = player.currentPosition
        PlayerState.dur = if (d == C.TIME_UNSET || d < 0) 0 else d
        if (panel.visibility == View.VISIBLE && !seeking) {
            seek.progress = if (PlayerState.dur > 0) (PlayerState.pos * 1000 / PlayerState.dur).toInt() else 0
            timeTv.text = "${fmt(PlayerState.pos)} / ${fmt(PlayerState.dur)}"
        }
        // fade-in lagu baru (2 detik)
        if (fadeUntil != 0L) {
            if (fadeUntil > now) player.volume = baseVol() * (1f - (fadeUntil - now) / 2000f)
            else { fadeUntil = 0L; player.volume = baseVol() }
        }
        // sleep timer: volume turun pelan 8 detik terakhir lalu mati
        val sa = PlayerState.sleepAt
        if (sa > 0) {
            val left = sa - now
            if (left <= 0) { PlayerState.sleepAt = 0; stopSelf(); return }
            if (left < 8000) player.volume = baseVol() * left / 8000f
        }
        // HUD (baterai/suhu/RAM) + ping jaringan
        if (panel.visibility == View.VISIBLE && Store.int(this, "hud", 1) == 1) {
            if (tickN % 8 == 0L) updateHud()
            if (tickN % 24 == 0L && !pingBusy) {
                pingBusy = true
                io.execute {
                    val p = Booster.ping()
                    ui.post { ping = p; pingBusy = false }
                }
            }
        }
        // auto-boost berkala
        if (Store.int(this, "autoboost", 0) == 1) {
            val gap = intArrayOf(1, 3, 5, 10)[Store.int(this, "autoint", 2).coerceIn(0, 3)] * 60_000L
            if (now - lastBoost > gap && !boosting) { lastBoost = now; doBoost(false) }
        }
    }

    // ---------- equalizer / bass / virtualizer ----------
    private fun releaseFx() {
        try { eq?.release() } catch (_: Throwable) {}
        try { bb?.release() } catch (_: Throwable) {}
        try { le?.release() } catch (_: Throwable) {}
        try { vz?.release() } catch (_: Throwable) {}
        eq = null; bb = null; le = null; vz = null
    }

    private fun initFx() {
        releaseFx()
        val sid = player.audioSessionId
        if (sid == C.AUDIO_SESSION_ID_UNSET) return
        fxSid = sid
        try { eq = Equalizer(0, sid).also { it.setEnabled(true) } } catch (_: Throwable) {}
        try { bb = BassBoost(0, sid).also { it.setEnabled(true) } } catch (_: Throwable) {}
        try { le = LoudnessEnhancer(sid).also { it.setEnabled(true) } } catch (_: Throwable) {}
        try { vz = Virtualizer(0, sid).also { it.setEnabled(true) } } catch (_: Throwable) {}
        applyFx()
    }

    private fun applyFx() {
        val preset = Store.int(this, "eq", 0)
        val curve = Fx.curve(this, preset)
        try {
            val e = eq
            if (e != null) {
                val n = e.numberOfBands.toInt()
                val lo = e.bandLevelRange[0].toInt()
                val hi = e.bandLevelRange[1].toInt()
                for (b in 0 until n) {
                    // 5 slider dipetakan ke jumlah pita perangkat (biasanya 5)
                    val pos = if (n > 1) b.toFloat() / (n - 1) * 4f else 2f
                    val i0 = pos.toInt().coerceIn(0, 4)
                    val i1 = (i0 + 1).coerceAtMost(4)
                    val g = curve[i0] * (1f - (pos - i0)) + curve[i1] * (pos - i0)
                    val lvl = if (g >= 0f) g * hi else g * -lo
                    e.setBandLevel(b.toShort(), lvl.toInt().coerceIn(lo, hi).toShort())
                }
            }
        } catch (_: Throwable) {}
        val bass = maxOf(Store.int(this, "bass", 0), if (preset == 1) 600 else 0)
        try { bb?.setStrength(bass.coerceIn(0, 1000).toShort()) } catch (_: Throwable) {}
        try { vz?.setStrength(Store.int(this, "virt", 0).coerceIn(0, 1000).toShort()) } catch (_: Throwable) {}
        try { le?.setTargetGain(Fx.loudGain(this)) } catch (_: Throwable) {}
        if (::eqBtn.isInitialized) eqBtn.text = "EQ ${Fx.names.getOrElse(preset) { "?" }}"
    }

    // ---------- overlay ----------
    private fun speedIdx() = Store.int(this, "speed", 1).coerceIn(0, speeds.size - 1)

    private fun repeatIcon() = when (Store.int(this, "repeat", 0)) { 1 -> "↻1"; 2 -> "⇄"; else -> "↻" }

    private fun applySettings() {
        val sz = when (Store.int(this, "size", 1)) { 0 -> 44; 2 -> 62; else -> 52 }
        bubble.layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz))
        root?.alpha = Store.int(this, "opacity", 100) / 100f
        repeatBtn.text = repeatIcon()
        hudTv.visibility = if (Store.int(this, "hud", 1) == 1) View.VISIBLE else View.GONE
        updateHud()
        if (::player.isInitialized) {
            player.volume = baseVol()
            player.setPlaybackSpeed(speeds[speedIdx()])
        }
        if (::speedBtn.isInitialized) speedBtn.text = speedLabels[speedIdx()]
        val vol = Store.int(this, "vol", 100)
        if (volBar.progress != vol) volBar.progress = vol
        val keep = Store.int(this, "awake", 1) == 1
        lp.flags = if (keep) lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        else lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
        applyFx()
    }

    private fun setHidden(h: Boolean) {
        hidden = h
        root?.visibility = if (h) View.GONE else View.VISIBLE
    }

    private fun ctl(label: String, size: Float = 16f, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = rounded(Color.parseColor("#22FFFFFF"), 17)
        layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(3) }
        setOnClickListener { onClick() }
    }

    private fun drag(v: View, onTap: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; root?.let { wm.updateViewLayout(it, lp) } }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    else { Store.putInt(this, "px", lp.x); Store.putInt(this, "py", lp.y); snapToEdge() }   // posisi bubble diingat
                }
            }
            true
        }
    }

    private fun buildOverlay() {
        bubble = TextView(this).apply {
            text = "♫"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = oval(CYAN, PINK)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        spin = ObjectAnimator.ofFloat(bubble, "rotation", 0f, 360f).apply {
            duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        }
        titleTv = TextView(this).apply {
            text = "FF Music"; setTextColor(Color.WHITE); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1; isSelected = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        playBtn = ctl("▶\uFE0E", 18f) { toggle() }.apply { background = oval(CYAN, PINK) }
        repeatBtn = ctl("↻") {
            val m = (Store.int(this, "repeat", 0) + 1) % 3
            Store.putInt(this, "repeat", m)
            repeatBtn.text = repeatIcon()
            toast(when (m) { 1 -> "Ulang 1 lagu"; 2 -> "Acak"; else -> "Ulang semua" })
        }
        hudTv = TextView(this).apply { setTextColor(Color.parseColor("#CCFFFFFF")); textSize = 10.5f; setPadding(0, dp(2), 0, dp(4)) }
        timeTv = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(MUTED); textSize = 10f; gravity = Gravity.END }
        seek = SeekBar(this).apply {
            max = 1000; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u && PlayerState.dur > 0) player.seekTo(PlayerState.dur * p / 1000)
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) { seeking = false }
            })
        }
        // volume musik sendiri (biar suara game tetap kedengeran)
        volBar = SeekBar(this).apply {
            max = 100; progress = Store.int(this@OverlayService, "vol", 100); tint()
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@OverlayService, "vol", p); player.volume = p / 100f }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val volRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply { text = "♪"; textSize = 13f; setPadding(0, 0, dp(4), 0) })
            addView(volBar)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(titleTv)
            addView(TextView(context).apply {
                text = "✕"; setTextColor(MUTED); textSize = 16f; setPadding(dp(10), 0, 0, 0)
                setOnClickListener { stopSelf() }
            })
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
            addView(ctl("|◀\uFE0E") { prev() })
            addView(playBtn)
            addView(ctl("▶\uFE0E|") { next() })
            addView(repeatBtn)
            addView(ctl("☾") {
                val s = (Store.int(this@OverlayService, "sleepsel", 0) + 1) % sleepOpts.size
                Store.putInt(this@OverlayService, "sleepsel", s)
                armSleep(); player.volume = baseVol()
                toast(if (s == 0) "Timer tidur mati" else "Berhenti otomatis ${sleepOpts[s]} menit lagi")
            })
            addView(ctl("—") { togglePanel() })
            addView(ctl("◎") { setHidden(true); toast("Disembunyiin. Buka lewat notifikasi → Tampil/Sembunyi") })
        }
        speedBtn = chipBtn("1x") {
            Store.putInt(this, "speed", (speedIdx() + 1) % speeds.size)
            applySettings()
            toast("Kecepatan ${speedLabels[speedIdx()]}")
        }
        eqBtn = chipBtn("EQ") {
            val n = (Store.int(this, "eq", 0) + 1) % Fx.names.size
            Store.putInt(this, "eq", n)
            applyFx()
            toast("Equalizer: ${Fx.names[n]}")
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(6), dp(4), dp(2))
            addView(chipBtn("↯ Boost") { doBoost(true) })
            addView(speedBtn)
            addView(eqBtn)
            addView(chipBtn("♥\uFE0E") {
                val t = tracks.getOrNull(idx)
                if (t != null) toast(if (Store.addFavorite(this@OverlayService, t)) "♥\uFE0E Masuk album Favorit" else "Sudah ada di Favorit")
            })
        }
        turboBtn = chipBtn("TURBO MAKSIMAL: MATI") {
            setTurbo(!PlayerState.turbo)
            toast(if (PlayerState.turbo) "Turbo aktif" else "Turbo mati")
        }
        val turboRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), dp(4), dp(2))
            addView(turboBtn)
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#F00B0B14"), 22, CYAN)
            setPadding(dp(14), dp(12), dp(10), dp(8))
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(300), LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) }
            addView(top); addView(hudTv); addView(seek); addView(timeTv); addView(volRow); addView(row); addView(row2); addView(turboRow)
        }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bubble); addView(panel)
        }
        drag(bubble) { togglePanel() }
        drag(titleTv, null)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Store.int(this@OverlayService, "px", dp(12))
            y = Store.int(this@OverlayService, "py", dp(140))
        }
        wm.addView(r, lp)
        root = r
    }

    private fun chipBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
        background = rounded(Color.parseColor("#22FFFFFF"), 14)
        setPadding(dp(4), dp(8), dp(4), dp(8))
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) }
        setOnClickListener { onClick() }
    }

    // buka/tutup panel; geser otomatis biar panel gak keluar layar
    private fun togglePanel() {
        if (panel.visibility == View.GONE) {
            panel.visibility = View.VISIBLE
            val w = resources.displayMetrics.widthPixels
            val need = bubble.layoutParams.width + dp(8) + dp(300)
            if (lp.x + need > w) {
                lp.x = maxOf(0, w - need)
                root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
            }
        } else {
            panel.visibility = View.GONE
            snapToEdge()
        }
    }

    // bubble nempel ke tepi layar terdekat
    private fun snapToEdge() {
        if (Store.int(this, "snap", 1) != 1 || panel.visibility == View.VISIBLE) return
        val w = resources.displayMetrics.widthPixels
        val size = dp(when (Store.int(this, "size", 1)) { 0 -> 44; 2 -> 62; else -> 52 })
        val target = if (lp.x + size / 2 < w / 2) dp(4) else w - size - dp(4)
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 180
            addUpdateListener {
                lp.x = it.animatedValue as Int
                root?.let { r -> try { wm.updateViewLayout(r, lp) } catch (_: Exception) {} }
            }
        }.start()
        Store.putInt(this, "px", target)
    }

    // TURBO: refresh rate layar tertinggi, wifi low-latency, CPU tetap nyala, animasi sistem off (kalau diizinkan)
    private fun setTurbo(on: Boolean) {
        PlayerState.turbo = on
        try {
            if (on) {
                if (wake == null) {
                    val pm = getSystemService(PowerManager::class.java)
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ffm:turbo").apply {
                        setReferenceCounted(false); acquire(4 * 60 * 60 * 1000L)
                    }
                }
                if (wifi == null) {
                    val w = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                    else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                    wifi = w.createWifiLock(mode, "ffm:turbo").apply { setReferenceCounted(false); acquire() }
                }
            } else {
                try { wake?.release() } catch (_: Throwable) {}
                try { wifi?.release() } catch (_: Throwable) {}
                wake = null; wifi = null
            }
        } catch (_: Throwable) {}
        // minta layar jalan di refresh rate tertinggi selama overlay tampil
        val m = Booster.bestMode(this)
        if (on && m != null) { lp.preferredDisplayModeId = m.modeId; lp.preferredRefreshRate = m.refreshRate }
        else { lp.preferredDisplayModeId = 0; lp.preferredRefreshRate = 0f }
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
        if (on) Booster.animOff(this) else Booster.animRestore(this)
        if (::turboBtn.isInitialized) {
            turboBtn.text = if (on) "TURBO MAKSIMAL: AKTIF" else "TURBO MAKSIMAL: MATI"
            turboBtn.background = if (on) rounded(PINK, 14) else rounded(Color.parseColor("#22FFFFFF"), 14)
        }
    }

    // Booster dari floating (manual) atau otomatis berkala
    private fun doBoost(manual: Boolean) {
        if (boosting) return
        boosting = true
        if (manual) toast("Membersihkan RAM…")
        io.execute {
            val r = try {
                if (Store.int(this, "turbo", 1) == 1) Booster.cleanMax(this, emptySet()) else Booster.clean(this, emptySet())
            } catch (_: Throwable) { null }
            ui.post {
                boosting = false
                lastBoost = System.currentTimeMillis()
                if (r != null && manual) toast("↯ +${r.freed} MB RAM lega • ${r.killed} app ditutup")
                updateHud()
            }
        }
    }

    // tombol headset / bluetooth & layar kunci
    private fun initSession() {
        try {
            session = MediaSession(this, "FFMusic").apply {
                setCallback(object : MediaSession.Callback() {
                    override fun onPlay() { player.play() }
                    override fun onPause() { player.pause() }
                    override fun onSkipToNext() { next() }
                    override fun onSkipToPrevious() { prev() }
                    override fun onStop() { stopSelf() }
                })
                isActive = true
            }
            updateSession()
        } catch (_: Throwable) {}
    }

    private fun updateSession() {
        val s = session ?: return
        try {
            s.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, PlayerState.title.ifEmpty { "FF Music" })
                    .build()
            )
            val st = if (player.isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP
                    )
                    .setState(st, player.currentPosition, 1f).build()
            )
        } catch (_: Throwable) {}
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        token++
        ui.removeCallbacksAndMessages(null)
        PlayerState.running = false
        PlayerState.playing = false
        PlayerState.sleepAt = 0L
        introView?.let { it.cancel(); try { wm.removeView(it) } catch (_: Exception) {} }
        Booster.dndOff(this)
        Booster.gameEqOff(this)
        setTurbo(false)
        try { session?.isActive = false; session?.release() } catch (_: Throwable) {}
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        spin.cancel()
        releaseFx()
        player.release()
        cache.release()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
}
