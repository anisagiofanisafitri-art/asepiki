package com.asep.ffmusic

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

// GANTI sesuai link GitHub kamu (dipakai tombol "Bagikan app")
const val APP_URL = "https://github.com/GANTI_USERNAME/ff-music/releases/latest"

// versi asli yang terpasang (bukan angka manual, jadi gak mungkin salah)
fun Context.appVersion(): String = try {
    packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
} catch (_: Exception) { "?" }

fun fmtSize(b: Long): String =
    if (b >= 1L shl 30) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576)

// link download: otomatis dari repo GitHub tempat APK ini di-build
fun appUrl(): String =
    if (BuildConfig.UPDATE_REPO.isNotEmpty()) "https://github.com/${BuildConfig.UPDATE_REPO}/releases/latest" else APP_URL

val BG = Color.parseColor("#0B0B14")
val CARD = Color.parseColor("#16162B")
val CYAN = Color.parseColor("#00E5FF")
val PINK = Color.parseColor("#FF2E93")
val PURPLE = Color.parseColor("#7A2CFF")
val MUTED = Color.parseColor("#8A8AA8")

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(fill: Int, radius: Int, stroke: Int = 0, fill2: Int = fill): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(fill, fill2)).apply {
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

fun oval(c1: Int, c2: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
        shape = GradientDrawable.OVAL
    }

fun Context.pill(label: String, c1: Int, c2: Int, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(c1, 24, 0, c2)
        setPadding(dp(16), dp(13), dp(16), dp(13))
        setOnClickListener { onClick() }
    }

fun android.widget.SeekBar.tint() {
    progressTintList = android.content.res.ColorStateList.valueOf(CYAN)
    thumbTintList = android.content.res.ColorStateList.valueOf(PINK)
}
