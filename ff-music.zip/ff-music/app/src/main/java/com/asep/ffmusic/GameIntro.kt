package com.asep.ffmusic

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.max

// Animasi "MODE GAME" layar penuh: cincin neon, tebasan miring, judul glitch, baris status.
// Digambar di atas game (overlay, gak bisa disentuh jadi gak ganggu).
class GameIntroView(ctx: Context, private val lines: List<String>) : View(ctx) {
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3600
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun start(done: () -> Unit) {
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(a: Animator) { done() }
        })
        anim.start()
    }

    fun cancel() {
        anim.removeAllListeners()
        anim.cancel()
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun seg(a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun ease(x: Float): Float { val k = 1f - x; return 1f - k * k * k }
    private fun col(c: Int, a: Float) =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun slash(c: Canvas, y: Float, hh: Float, u: Float, color: Int, ltr: Boolean, w: Float, master: Float) {
        if (u <= 0f || u >= 1f) return
        val len = w * 0.55f
        val skew = hh * 1.2f
        val x0 = if (ltr) -len + u * (w + len) else w - u * (w + len)
        path.reset()
        path.moveTo(x0 + skew, y); path.lineTo(x0 + len + skew, y)
        path.lineTo(x0 + len, y + hh); path.lineTo(x0, y + hh); path.close()
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            x0, y, x0 + len, y,
            intArrayOf(col(color, 0f), col(color, 0.9f * master), col(color, 0f)), null, Shader.TileMode.CLAMP
        )
        c.drawPath(path, paint)
        paint.shader = null
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val master = seg(0f, 0.1f) * (1f - seg(0.84f, 1f))
        if (master <= 0f) return
        paint.shader = null
        paint.clearShadowLayer()
        paint.letterSpacing = 0f

        // latar gelap
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((225 * master).toInt(), 5, 5, 14)
        c.drawRect(0f, 0f, w, h, paint)

        // cincin neon melebar
        paint.style = Paint.Style.STROKE
        for (k in 0 until 3) {
            val p = seg(0.04f + k * 0.08f, 0.62f + k * 0.08f)
            if (p <= 0f || p >= 1f) continue
            paint.strokeWidth = dp(4f) * (1f - p) + 1f
            paint.color = col(if (k % 2 == 0) CYAN else PINK, (1f - p) * master)
            c.drawCircle(cx, cy, ease(p) * max(w, h) * 0.8f, paint)
        }

        // tebasan miring
        slash(c, h * 0.30f, dp(26f), seg(0.08f, 0.55f), CYAN, true, w, master)
        slash(c, h * 0.66f, dp(26f), seg(0.14f, 0.60f), PINK, false, w, master)

        // siku sudut layar
        val bl = dp(38f) * ease(seg(0.12f, 0.40f))
        val ins = dp(22f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3f)
        paint.color = col(CYAN, master)
        c.drawLine(ins, ins, ins + bl, ins, paint); c.drawLine(ins, ins, ins, ins + bl, paint)
        c.drawLine(w - ins, ins, w - ins - bl, ins, paint); c.drawLine(w - ins, ins, w - ins, ins + bl, paint)
        c.drawLine(ins, h - ins, ins + bl, h - ins, paint); c.drawLine(ins, h - ins, ins, h - ins - bl, paint)
        c.drawLine(w - ins, h - ins, w - ins - bl, h - ins, paint); c.drawLine(w - ins, h - ins, w - ins, h - ins - bl, paint)

        // judul: masuk dari besar, efek glitch cyan/pink makin menyatu
        val ts = seg(0.10f, 0.40f)
        if (ts > 0f) {
            val sc = 1f + 1.5f * (1f - ease(ts))
            val off = dp(7f) * (1f - seg(0.10f, 0.55f))
            val ty = cy - dp(12f)
            paint.style = Paint.Style.FILL
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = dp(40f)
            paint.letterSpacing = 0.14f
            c.save()
            c.scale(sc, sc, cx, ty)
            paint.color = col(CYAN, 0.8f * ts * master); c.drawText("MODE GAME", cx - off, ty, paint)
            paint.color = col(PINK, 0.8f * ts * master); c.drawText("MODE GAME", cx + off, ty, paint)
            paint.color = col(Color.WHITE, ts * master)
            paint.setShadowLayer(dp(16f), 0f, 0f, col(CYAN, master))
            c.drawText("MODE GAME", cx, ty, paint)
            paint.clearShadowLayer()
            c.restore()
        }

        // garis gradasi di bawah judul
        val lw = ease(seg(0.30f, 0.50f)) * w * 0.62f
        if (lw > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(3f)
            paint.shader = LinearGradient(cx - lw / 2f, 0f, cx + lw / 2f, 0f, col(CYAN, master), col(PINK, master), Shader.TileMode.CLAMP)
            c.drawLine(cx - lw / 2f, cy + dp(14f), cx + lw / 2f, cy + dp(14f), paint)
            paint.shader = null
        }

        // baris status muncul satu-satu
        paint.style = Paint.Style.FILL
        paint.textSize = dp(14f)
        paint.letterSpacing = 0.1f
        paint.textAlign = Paint.Align.CENTER
        lines.forEachIndexed { i, s ->
            val st = 0.42f + i * 0.09f
            val p = seg(st, st + 0.07f)
            if (p > 0f) {
                paint.color = col(Color.WHITE, 0.9f * p * master)
                c.drawText("›  $s", cx, cy + dp(48f) + i * dp(26f) + (1f - ease(p)) * dp(14f), paint)
            }
        }
    }
}
