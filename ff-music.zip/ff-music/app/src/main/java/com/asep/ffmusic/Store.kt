package com.asep.ffmusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// kind: "query" (cari by judul), "url" (link audio langsung), "yt" (id YouTube), "file" (upload lokal)
data class Track(val title: String, val src: String, val kind: String)

object Store {
    private const val KEY = "playlist"

    fun load(c: Context): MutableList<Track> {
        val sp = c.getSharedPreferences("ffmusic", Context.MODE_PRIVATE)
        val raw = sp.getString(KEY, null)
        if (raw == null) {
            val d = defaults().toMutableList()
            save(c, d)
            return d
        }
        val a = JSONArray(raw)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Track(o.getString("t"), o.getString("s"), o.getString("k"))
        }
    }

    fun save(c: Context, l: List<Track>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.title).put("s", it.src).put("k", it.kind)) }
        c.getSharedPreferences("ffmusic", Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    private fun sp(c: Context) = c.getSharedPreferences("ffmusic", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String): String? = sp(c).getString(k, null)
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    private fun defaults() = listOf(
        "December - Neck Deep",
        "Ada Titik Titik di Ujung Doa - Sal Priadi",
        "Masa Ini, Nanti, dan Masa Indah - Nuca",
        "Wish You Were Here - Neck Deep"
    ).map { Track(it, it, "query") }
}
