package com.asep.ffmusic

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

// kind: "query" (cari by judul), "url" (link audio langsung), "yt" (id YouTube), "file" (upload lokal)
data class Track(val title: String, val src: String, val kind: String)

class Album(var name: String, var emoji: String, val tracks: MutableList<Track> = mutableListOf())

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("ffmusic", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String): String? = sp(c).getString(k, null)
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    // ---------- album ----------
    fun albums(c: Context): MutableList<Album> {
        val raw = sp(c).getString("albums", null)
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                val out = MutableList(a.length()) { parseAlbum(a.getJSONObject(it), true) }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {}
        }
        // migrasi dari v2 (satu playlist) -> album "Santai"
        val santai = Album("Santai", "☾")
        val old = sp(c).getString("playlist", null)
        if (old != null) {
            try {
                val a = JSONArray(old)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    santai.tracks.add(Track(o.getString("t"), o.getString("s"), o.getString("k")))
                }
            } catch (_: Exception) {}
        }
        if (santai.tracks.isEmpty()) santai.tracks.addAll(
            listOf(
                "December - Neck Deep",
                "Ada Titik Titik di Ujung Doa - Sal Priadi",
                "Masa Ini, Nanti, dan Masa Indah - Nuca",
                "Wish You Were Here - Neck Deep"
            ).map { Track(it, it, "query") }
        )
        val bantai = Album("Bantai", "✹")
        bantai.tracks.addAll(
            listOf(
                "Till I Collapse - Eminem",
                "Warriors - Imagine Dragons",
                "Believer - Imagine Dragons",
                "Centuries - Fall Out Boy"
            ).map { Track(it, it, "query") }
        )
        val out = mutableListOf(santai, bantai)
        saveAlbums(c, out)
        return out
    }

    fun saveAlbums(c: Context, l: List<Album>) {
        val a = JSONArray()
        l.forEach { a.put(toJson(it, true)) }
        sp(c).edit().putString("albums", a.toString()).apply()
    }

    fun activeTracks(c: Context): MutableList<Track> {
        val l = albums(c)
        val a = l.getOrNull(int(c, "album", 0)) ?: l.first()
        return a.tracks.toMutableList()
    }

    private fun toJson(a: Album, withFiles: Boolean): JSONObject {
        val t = JSONArray()
        a.tracks.filter { withFiles || it.kind != "file" }.forEach {
            t.put(JSONObject().put("t", it.title).put("s", it.src).put("k", it.kind))
        }
        return JSONObject().put("n", a.name).put("e", a.emoji).put("t", t)
    }

    private fun parseAlbum(o: JSONObject, allowFile: Boolean): Album {
        val em = o.optString("e", "♫")
        // emoji warna-warni dari kode orang lain diganti simbol polos
        val a = Album(o.optString("n", "Album").take(30), if (em.isEmpty() || em.any { Character.isSurrogate(it) }) "♫" else em)
        val t = o.optJSONArray("t") ?: JSONArray()
        for (i in 0 until t.length()) {
            val x = t.getJSONObject(i)
            val k = x.optString("k"); val s = x.optString("s"); val ti = x.optString("t")
            if (s.isEmpty() || ti.isEmpty()) continue
            val ok = when (k) {
                "query" -> true
                "url" -> s.startsWith("http")
                "yt" -> Regex("[A-Za-z0-9_-]{11}").matches(s)
                "file" -> allowFile
                else -> false
            }
            if (ok) a.tracks.add(Track(ti, s, k))
        }
        return a
    }

    // ---------- bagi album ke teman (kode teks) ----------
    fun export(a: Album): String =
        "ffm1:" + Base64.encodeToString(
            toJson(a, false).toString().toByteArray(),
            Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
        )

    // file lokal TIDAK ikut diimpor (aman: kode dari orang lain gak bisa nunjuk ke file HP kamu)
    fun importCode(text: String): Album? {
        val m = Regex("ffm1:([A-Za-z0-9_-]+)").find(text) ?: return null
        return try {
            val json = String(Base64.decode(m.groupValues[1], Base64.URL_SAFE or Base64.NO_WRAP))
            val a = parseAlbum(JSONObject(json), false)
            if (a.tracks.isEmpty()) null else a
        } catch (_: Exception) { null }
    }
}
