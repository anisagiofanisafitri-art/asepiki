package com.asep.ffmusic

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.NotificationManager.Policy
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import android.os.Build

// Booster jujur: nutup app yang jalan di background (bukan sistem) biar RAM lega,
// + mode Jangan Ganggu biar notif gak nutupin layar pas main.
object Booster {
    class Result(val freed: Long, val killed: Int)
    class Batt(val pct: Int, val temp: Float)

    private val known = setOf(
        "com.dts.freefireth", "com.dts.freefiremax", "com.mobile.legends", "com.tencent.ig",
        "com.activision.callofduty.shooter", "com.miHoYo.GenshinImpact", "com.roblox.client",
        "com.supercell.clashofclans", "com.supercell.brawlstars", "com.garena.game.df"
    )

    private fun am(c: Context) = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun availMb(c: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        am(c).getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    fun totalMb(c: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        am(c).getMemoryInfo(mi)
        return mi.totalMem / 1048576
    }

    fun battery(c: Context): Batt {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return Batt(if (lv >= 0 && sc > 0) lv * 100 / sc else 0, t)
    }

    private fun userApps(c: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return c.packageManager.queryIntentActivities(i, 0)
            .filter { (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { it.activityInfo.packageName }
            .toSet()
    }

    // Panggil dari thread background (ada jeda ~0.7 detik buat ngukur RAM)
    fun clean(c: Context, keep: Set<String>): Result {
        val before = availMb(c)
        var n = 0
        for (p in userApps(c)) {
            if (p == c.packageName || p in keep) continue
            try { am(c).killBackgroundProcesses(p); n++ } catch (_: Exception) {}
        }
        try { Thread.sleep(700) } catch (_: Exception) {}
        return Result(maxOf(0L, availMb(c) - before), n)
    }

    // daftar (nama, package) app yang bisa dibuka — game terkenal di atas
    fun launchables(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter {
                it.activityInfo.packageName != c.packageName &&
                    ((it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        it.activityInfo.packageName in known)
            }
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }
            .sortedWith(compareBy<Pair<String, String>>({ it.second !in known }, { it.first.lowercase() }))
    }

    // ---------- Jangan Ganggu ----------
    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun dndGranted(c: Context) = nm(c).isNotificationPolicyAccessGranted

    // matiin pop-up (heads-up), layar nyala sendiri, full-screen call, lampu, ambient
    @Suppress("DEPRECATION")
    private fun effects(): Int {
        var e = Policy.SUPPRESSED_EFFECT_PEEK or Policy.SUPPRESSED_EFFECT_SCREEN_ON
        if (Build.VERSION.SDK_INT >= 28) {
            e = e or Policy.SUPPRESSED_EFFECT_FULL_SCREEN_INTENT or Policy.SUPPRESSED_EFFECT_AMBIENT or
                Policy.SUPPRESSED_EFFECT_LIGHTS
        }
        return e
    }

    // Level 0 (Total): semua telepon, chat & notifikasi dibungkam — cuma musik/game & alarm lolos.
    // Level 1: sama, tapi telepon (dan penelepon berulang) tetap boleh masuk.
    fun dndOn(c: Context) {
        val n = nm(c)
        if (!n.isNotificationPolicyAccessGranted) return
        if (Store.int(c, "dnd_set", 0) == 0) {
            val old = n.notificationPolicy
            Store.putInt(c, "dnd_prev", n.currentInterruptionFilter)
            Store.putInt(c, "dnd_pc", old.priorityCategories)
            Store.putInt(c, "dnd_cs", old.priorityCallSenders)
            Store.putInt(c, "dnd_ms", old.priorityMessageSenders)
            Store.putInt(c, "dnd_fx", old.suppressedVisualEffects)
            Store.putInt(c, "dnd_set", 1)
        }
        var cats = Policy.PRIORITY_CATEGORY_MEDIA or Policy.PRIORITY_CATEGORY_ALARMS
        if (Store.int(c, "dndlvl", 0) == 1) {
            cats = cats or Policy.PRIORITY_CATEGORY_CALLS or Policy.PRIORITY_CATEGORY_REPEAT_CALLERS
        }
        n.notificationPolicy = Policy(cats, Policy.PRIORITY_SENDERS_ANY, Policy.PRIORITY_SENDERS_ANY, effects())
        n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
    }

    fun dndOff(c: Context) {
        if (Store.int(c, "dnd_set", 0) != 1) return
        val n = nm(c)
        if (n.isNotificationPolicyAccessGranted) {
            n.notificationPolicy = Policy(
                Store.int(c, "dnd_pc", 0), Store.int(c, "dnd_cs", 0),
                Store.int(c, "dnd_ms", 0), Store.int(c, "dnd_fx", 0)
            )
            val prev = Store.int(c, "dnd_prev", NotificationManager.INTERRUPTION_FILTER_ALL)
            n.setInterruptionFilter(if (prev < 1) NotificationManager.INTERRUPTION_FILTER_ALL else prev)
        }
        Store.putInt(c, "dnd_set", 0)
    }
}
