package com.asep.ffmusic

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Collections

class MainActivity : Activity() {
    private var list = mutableListOf<Track>()
    private var filter = ""
    private var seeking = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var tabs: List<TextView>
    private lateinit var pages: List<View>
    private lateinit var listBox: LinearLayout
    private lateinit var countTv: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var cacheTv: TextView
    private lateinit var hTitle: TextView
    private lateinit var hSub: TextView
    private lateinit var hTime: TextView
    private lateinit var hSeek: SeekBar
    private lateinit var hPlay: TextView
    private lateinit var hPower: TextView
    private lateinit var hWarn: TextView

    private val poll = object : Runnable {
        override fun run() { updateHome(); ui.postDelayed(this, 500) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        list = Store.load(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(28), 0, 0)
        }
        val content = FrameLayout(this)
        pages = listOf(pageHome(), pagePlaylist(), pageAdd(), pageSettings())
        pages.forEach { content.addView(it) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(navBar())
        setContentView(root)
        show(0)
    }

    override fun onResume() {
        super.onResume()
        refresh(); buildPerms(); updateCache()
        ui.post(poll)
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    // ---------- util ----------
    private fun cmd(a: String, f: (Intent) -> Unit = {}) {
        if (!PlayerState.running) return
        startService(Intent(this, OverlayService::class.java).setAction(a).also(f))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun scroll(vararg v: View): ScrollView = ScrollView(this).apply {
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12))
            v.forEach { addView(it) }
        })
    }

    private fun label(s: String, size: Float = 14f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun field(hint: String, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 14f
        background = rounded(CARD, 14, Color.parseColor("#3300E5FF"))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (lines > 1) { minLines = lines; gravity = Gravity.TOP }
    }

    private fun gap(h: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(h)) }

    private fun circle(label: String, size: Int, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER
        textSize = if (primary) 26f else 20f
        setTextColor(if (primary) BG else Color.WHITE)
        background = oval(if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"), if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener { onClick() }
    }

    // ---------- navbar ----------
    private fun navBar(): LinearLayout {
        val items = listOf("🏠\nHome", "🎵\nPlaylist", "➕\nTambah", "⚙️\nSetelan")
        tabs = items.mapIndexed { i, s ->
            TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(8))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                setOnClickListener { show(i) }
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD, 28, Color.parseColor("#2200E5FF"))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(6), dp(14), dp(14)) }
            tabs.forEach { addView(it) }
        }
    }

    private fun show(n: Int) {
        pages.forEachIndexed { i, p -> p.visibility = if (i == n) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, t ->
            if (i == n) { t.setTextColor(Color.WHITE); t.background = rounded(CYAN, 22, 0, PINK) }
            else { t.setTextColor(MUTED); t.background = null }
        }
    }

    // ---------- HOME ----------
    private fun pageHome(): View {
        hTitle = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(14), 0, dp(2))
        }
        hSub = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.CENTER }
        hTime = TextView(this).apply { textSize = 11f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.END }
        hSeek = SeekBar(this).apply {
            max = 1000; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    val f = (s?.progress ?: 0) / 1000f
                    cmd("SEEK") { it.putExtra("f", f) }
                }
            })
        }
        hPlay = circle("▶", 72, true) {
            if (PlayerState.running) cmd("TOGGLE") else startFloating(Store.int(this, "last", 0))
        }
        val art = TextView(this).apply {
            text = "🎧"; textSize = 52f; gravity = Gravity.CENTER
            background = oval(Color.parseColor("#33FFFFFF"), Color.parseColor("#22FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            addView(circle("⏮", 52, false) { cmd("PREV") })
            addView(hPlay)
            addView(circle("⏭", 52, false) { cmd("NEXT") })
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#00B8D4"), Color.parseColor("#7A2CFF"), Color.parseColor("#FF2E93"))
            ).apply { cornerRadius = dp(30).toFloat() }
            setPadding(dp(20), dp(26), dp(20), dp(20))
            addView(art); addView(hTitle); addView(hSub); addView(gap(8)); addView(hSeek); addView(hTime); addView(controls)
        }
        hPower = pill("🚀  Nyalakan Floating Player", CYAN, PINK) {
            if (PlayerState.running) cmd("STOP") else startFloating(Store.int(this, "last", 0))
        }
        hWarn = label("⚠️ Izin \"Tampil di atas aplikasi lain\" belum aktif. Tap tombol di atas buat ngatur.", 12f, PINK)
        return scroll(
            label("FF Music 🔥", 26f, Color.WHITE, true),
            label("Lagu latar buat push rank", 13f, MUTED),
            gap(), card, gap(14), hPower, hWarn,
            label("Tips: tap bubble ♫ di game buat buka kontrol, geser buat pindahin, 👁 buat sembunyiin total.", 12f, MUTED)
        )
    }

    private fun updateHome() {
        val run = PlayerState.running
        hTitle.text = if (run && PlayerState.title.isNotEmpty()) PlayerState.title else "Belum ada lagu diputar"
        hSub.text = if (run) "${if (PlayerState.playing) "Sedang diputar" else "Dijeda"} • lagu ${PlayerState.idx + 1}/${list.size}"
        else "Nyalakan player buat mulai"
        hPlay.text = if (PlayerState.playing) "⏸" else "▶"
        hPower.text = if (run) "⏹  Matikan Floating Player" else "🚀  Nyalakan Floating Player"
        hWarn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        if (!seeking) {
            hSeek.progress = if (PlayerState.dur > 0) (PlayerState.pos * 1000 / PlayerState.dur).toInt() else 0
            hTime.text = if (run) "${fmt(PlayerState.pos)} / ${fmt(PlayerState.dur)}" else "0:00 / 0:00"
        }
    }

    private fun startFloating(i: Int) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan 'Tampil di atas aplikasi lain' dulu, lalu balik & tekan lagi")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        if (list.isEmpty()) { toast("Playlist kosong"); return }
        startForegroundService(Intent(this, OverlayService::class.java).setAction("START").putExtra("idx", i))
        toast("Nyala! Buka Free Fire 🔥")
    }

    // ---------- PLAYLIST ----------
    private fun pagePlaylist(): View {
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        countTv = label("", 12f, MUTED)
        val search = field("🔍  Cari di playlist")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filter = s?.toString()?.trim() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return scroll(
            label("Playlist 🎵", 26f, Color.WHITE, true), search, countTv, gap(4),
            pill("▶  Putar dari awal", CYAN, PINK) { startFloating(0) }, gap(), listBox
        )
    }

    private fun kindLabel(k: String) = when (k) {
        "query" -> "Cari otomatis • cache offline"
        "yt" -> "Link YouTube • cache offline"
        "file" -> "File di dalam app"
        else -> "Link audio • cache offline"
    }

    private fun refresh() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val shown = list.withIndex().filter { filter.isEmpty() || it.value.title.contains(filter, true) }
        countTv.text = "${list.size} lagu" + (if (filter.isNotEmpty()) " • ${shown.size} cocok" else "") + " • tap lagu buat muter"
        if (shown.isEmpty()) listBox.addView(label("Kosong. Tambah dulu di tab ➕", 13f, MUTED))
        shown.forEach { (i, t) ->
            val playing = PlayerState.running && PlayerState.idx == i
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, 18, if (playing) CYAN else 0)
                setPadding(dp(12), dp(10), dp(4), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                setOnClickListener { startFloating(i) }
            }
            row.addView(TextView(this).apply {
                text = if (playing) "♫" else "${i + 1}"; gravity = Gravity.CENTER; textSize = 13f
                setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                background = oval(CYAN, PINK)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(12) }
            })
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(TextView(context).apply { text = t.title; setTextColor(Color.WHITE); textSize = 14f; maxLines = 2 })
                addView(TextView(context).apply { text = kindLabel(t.kind); setTextColor(MUTED); textSize = 10.5f })
            })
            row.addView(TextView(this).apply {
                text = "▲"; setTextColor(MUTED); textSize = 15f; setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    if (i > 0) { Collections.swap(list, i, i - 1); Store.save(this@MainActivity, list); refresh() }
                }
            })
            row.addView(TextView(this).apply {
                text = "✕"; setTextColor(PINK); textSize = 17f; setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    if (t.kind == "file") try { File(Uri.parse(t.src).path ?: "").delete() } catch (_: Exception) {}
                    list.removeAt(i); Store.save(this@MainActivity, list); refresh()
                }
            })
            listBox.addView(row)
        }
    }

    // ---------- TAMBAH ----------
    private fun pageAdd(): View {
        val one = field("Judul lagu atau link (mp3 / YouTube)")
        val bulk = field("Tulis daftar judul, 1 baris 1 lagu.\nContoh:\nDecember - Neck Deep\nWish You Were Here - Neck Deep", 6)
        return scroll(
            label("Tambah Lagu ➕", 26f, Color.WHITE, true),
            label("Tulis judul → app cari sendiri. Atau tempel link. Atau upload file, nanti disalin ke dalam app.", 12f, MUTED),
            one, gap(),
            pill("➕  Tambah", CYAN, PINK) {
                parse(one.text.toString())?.let { list.add(it); save(); one.setText("") }
            }, gap(),
            pill("📁  Upload audio dari HP", PINK, Color.parseColor("#7A2CFF")) { pick() },
            gap(), label("Tambah banyak sekaligus", 15f, Color.WHITE, true), bulk, gap(),
            pill("📝  Tambah semua", Color.parseColor("#7A2CFF"), CYAN) {
                list.addAll(bulk.text.toString().lines().mapNotNull { parse(it) })
                save(); bulk.setText("")
            }
        )
    }

    private fun parse(s: String): Track? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val yt = Regex("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").find(t)
        return when {
            t.startsWith("http") && yt != null -> Track("YouTube ${yt.groupValues[1]}", yt.groupValues[1], "yt")
            t.startsWith("http") -> Track(Uri.parse(t).lastPathSegment ?: t, t, "url")
            else -> Track(t, t, "query")
        }
    }

    private fun save() { Store.save(this, list); refresh(); toast("Tersimpan") }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req != 1 || res != RESULT_OK || d == null) return
        val uris = mutableListOf<Uri>()
        d.data?.let { uris.add(it) }
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        toast("Nyalin ${uris.size} file ke dalam app…")
        Thread {
            val dir = File(filesDir, "songs").apply { mkdirs() }
            val added = mutableListOf<Track>()
            uris.forEach { u ->
                try {
                    var name = u.lastPathSegment ?: "Audio"
                    contentResolver.query(u, null, null, null, null)?.use { c ->
                        val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (k >= 0 && c.moveToFirst()) name = c.getString(k)
                    }
                    val out = File(dir, "${System.currentTimeMillis()}_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(u)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    added.add(Track(name.substringBeforeLast('.'), Uri.fromFile(out).toString(), "file"))
                } catch (_: Exception) {}
            }
            runOnUiThread { list.addAll(added); save() }
        }.start()
    }

    // ---------- SETELAN ----------
    private fun chips(opts: List<String>, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        fun paint() {
            views.forEachIndexed { i, v ->
                if (i == get()) { v.setTextColor(Color.WHITE); v.background = rounded(CYAN, 16, 0, PINK) }
                else { v.setTextColor(MUTED); v.background = rounded(CARD, 16) }
            }
        }
        opts.forEachIndexed { i, s ->
            val v = TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 13f; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
                setOnClickListener { set(i); paint() }
            }
            views.add(v); row.addView(v)
        }
        paint()
        return row
    }

    private fun pageSettings(): View {
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cacheTv = label("", 13f, Color.WHITE)
        val opacity = SeekBar(this).apply {
            max = 70; progress = Store.int(this@MainActivity, "opacity", 100) - 30; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@MainActivity, "opacity", p + 30); cmd("APPLY") }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        return scroll(
            label("Setelan ⚙️", 26f, Color.WHITE, true),
            label("Mode putar", 15f, Color.WHITE, true),
            chips(listOf("🔁 Semua", "🔂 Satu", "🔀 Acak"), { Store.int(this, "repeat", 0) }) {
                Store.putInt(this, "repeat", it); cmd("APPLY")
            },
            gap(), label("Ukuran bubble", 15f, Color.WHITE, true),
            chips(listOf("Kecil", "Sedang", "Besar"), { Store.int(this, "size", 1) }) {
                Store.putInt(this, "size", it); cmd("APPLY")
            },
            gap(), label("Transparansi floating", 15f, Color.WHITE, true), opacity,
            gap(), label("Izin & status", 15f, Color.WHITE, true), permBox,
            gap(), label("Cache lagu", 15f, Color.WHITE, true), cacheTv,
            label("Lagu yang pernah diputar disimpan di HP, jadi putar ulang bisa tanpa kuota.", 11f, MUTED),
            pill("🗑  Hapus cache", Color.parseColor("#33334D"), Color.parseColor("#33334D")) {
                if (PlayerState.running) toast("Matikan floating player dulu")
                else { File(cacheDir, "media").deleteRecursively(); updateCache(); toast("Cache dihapus") }
            },
            gap(16), label("FF Music v2.0", 11f, MUTED)
        )
    }

    private fun permRow(text: String, ok: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = (if (ok) "✅  " else "❌  ") + text
        setTextColor(if (ok) Color.WHITE else PINK); textSize = 13f
        background = rounded(CARD, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun buildPerms() {
        if (!::permBox.isInitialized) return
        permBox.removeAllViews()
        permBox.addView(permRow("Tampil di atas aplikasi lain", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        permBox.addView(permRow("Notifikasi", notifOk) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        })
        val pm = getSystemService(PowerManager::class.java)
        permBox.addView(permRow("Baterai tanpa batasan (biar gak dimatiin sistem)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
    }

    private fun updateCache() {
        if (!::cacheTv.isInitialized) return
        val mb = File(cacheDir, "media").walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1048576.0
        cacheTv.text = "%.1f MB terpakai (maks 300 MB)".format(mb)
    }
}
