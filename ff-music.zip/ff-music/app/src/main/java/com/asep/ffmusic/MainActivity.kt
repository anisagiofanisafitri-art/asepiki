package com.asep.ffmusic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections

class MainActivity : Activity() {
    private var albums = mutableListOf<Album>()
    private var view = 0              // album yang lagi dilihat/diedit di tab Album & Tambah
    private var filter = ""
    private var seeking = false
    private var page = 0
    private var pickTi = 0
    private val ui = Handler(Looper.getMainLooper())
    private val chipRows = mutableListOf<Pair<LinearLayout, Boolean>>()
    private val emojis = listOf("♫", "✹", "☾", "✦", "◈", "❖", "♪", "✧")

    private lateinit var tabs: List<TextView>
    private lateinit var pages: List<View>
    private lateinit var listBox: LinearLayout
    private lateinit var resBox: LinearLayout
    private lateinit var countTv: TextView
    private lateinit var albumTitle: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var dndBox: LinearLayout
    private lateinit var cacheTv: TextView
    private lateinit var sleepTv: TextView
    private lateinit var hTitle: TextView
    private lateinit var hSub: TextView
    private lateinit var hTime: TextView
    private lateinit var hSeek: SeekBar
    private lateinit var hPlay: TextView
    private lateinit var hPower: TextView
    private lateinit var hWarn: TextView
    private lateinit var gStats: TextView
    private lateinit var gGame: TextView
    private lateinit var gResult: TextView
    private lateinit var gTotal: TextView
    private var eqRepaint: () -> Unit = {}
    private var speedRepaint: () -> Unit = {}
    private val eqBars = mutableListOf<SeekBar>()
    private lateinit var vList: LinearLayout
    private lateinit var vInput: EditText
    private lateinit var updStatus: TextView
    private lateinit var vProg: TextView
    private lateinit var vSaved: LinearLayout
    private var lastDl = -1

    private val poll = object : Runnable {
        override fun run() {
            updateHome()
            if (page == 3) {
                vProg.text = Downloads.summary()
                if (Downloads.version != lastDl) { lastDl = Downloads.version; refreshVideos() }
            }
            if (page == 4) updateGame()
            if (page == 5) updateSettings()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Resolver.custom = Store.str(this, "host")?.takeIf { it.isNotEmpty() }
        albums = Store.albums(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(28), 0, 0)
        }
        val content = FrameLayout(this)
        pages = listOf(pageHome(), pageAlbum(), pageAdd(), pageVideo(), pageGame(), pageSettings())
        pages.forEach { content.addView(it) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(navBar())
        setContentView(root)
        show(0)
        if (Store.int(this, "autoupd", 1) == 1) autoCheckUpdate()
        // sisa unduhan yang gagal/terputus (file .part) dibersihin biar memori gak kebuang
        if (Downloads.active().isEmpty()) {
            File(filesDir, "videos").listFiles()?.filter { it.name.endsWith(".part") }?.forEach { it.delete() }
        }
    }

    override fun onResume() {
        super.onResume()
        albums = Store.albums(this)
        if (view >= albums.size) view = 0
        rebuildChips(); refresh(); buildPerms(); updateCache(); updateGame(); syncEq(); refreshVideos()
        if (!PlayerState.running) Booster.animRestore(this)
        ui.post(poll)
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    // ---------- util ----------
    private fun cmd(a: String, f: (Intent) -> Unit = {}) {
        if (!PlayerState.running) return
        startService(Intent(this, OverlayService::class.java).setAction(a).also(f))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun active() = Store.int(this, "album", 0).coerceIn(0, maxOf(0, albums.size - 1))

    private fun scroll(vararg v: View): ScrollView = ScrollView(this).apply {
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12))
            v.forEach { addView(it) }
        })
    }

    private fun label(s: String, size: Float = 14f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun field(hint: String, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 14f
        background = rounded(CARD, 14, Color.parseColor("#3300E5FF"))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (lines > 1) { minLines = lines; gravity = Gravity.TOP }
    }

    private fun gap(h: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(h)) }

    private fun circle(label: String, size: Int, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER
        textSize = if (primary) 26f else 20f
        setTextColor(if (primary) BG else Color.WHITE)
        background = oval(if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"), if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener { onClick() }
    }

    private fun mini(s: String, onClick: () -> Unit) = TextView(this).apply {
        text = s; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
        background = rounded(CARD, 14, Color.parseColor("#3300E5FF"))
        setPadding(0, dp(11), 0, dp(11))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun askText(title: String, init: String, ok: (String) -> Unit) {
        val e = field("Nama album").apply { setText(init); isSingleLine = true }
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("OK") { _, _ -> val s = e.text.toString().trim(); if (s.isNotEmpty()) ok(s) }
            .setNegativeButton("Batal", null).show()
    }

    private fun deleteFile(t: Track) {
        if (t.kind == "file") try { File(Uri.parse(t.src).path ?: "").delete() } catch (_: Exception) {}
    }

    // simpan perubahan album + kasih tau player kalau album itu lagi dipakai
    private fun persist(ai: Int = view) {
        Store.saveAlbums(this, albums)
        refresh(); rebuildChips()
        if (ai == active()) cmd("RELOAD")
    }

    // ---------- chip album ----------
    private fun chipBar(home: Boolean): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        chipRows.add(Pair(row, home))
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun rebuildChips() {
        chipRows.forEach { (row, home) ->
            row.removeAllViews()
            val sel = if (home) active() else view
            albums.forEachIndexed { i, a ->
                row.addView(TextView(this).apply {
                    text = "${a.emoji} ${a.name}"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9))
                    if (i == sel) { setTextColor(Color.WHITE); background = rounded(CYAN, 18, 0, PINK) }
                    else { setTextColor(MUTED); background = rounded(CARD, 18) }
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
                    setOnClickListener {
                        if (home) selectAlbum(i) else { view = i; filter = ""; rebuildChips(); refresh() }
                    }
                })
            }
        }
    }

    // pilih album yang dimainkan (Home)
    private fun selectAlbum(i: Int) {
        Store.putInt(this, "album", i); Store.putInt(this, "last", 0)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", 0) }
        else toast("Album ${albums[i].name} dipilih")
    }

    private fun playAlbum(i: Int) {
        Store.putInt(this, "album", i); Store.putInt(this, "last", 0)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", 0) } else startFloating(0)
    }

    private fun playTrack(ai: Int, i: Int) {
        Store.putInt(this, "album", ai); Store.putInt(this, "last", i)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", i) } else startFloating(i)
    }

    // ---------- navbar ----------
    private fun navBar(): LinearLayout {
        val items = listOf("⌂\nHome", "♫\nAlbum", "+\nTambah", "▶\uFE0E\nVideo", "◈\nGame", "⚙\uFE0E\nSetelan")
        tabs = items.mapIndexed { i, s ->
            TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(8))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { show(i) }
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD, 28, Color.parseColor("#2200E5FF"))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(6), dp(12), dp(14)) }
            tabs.forEach { addView(it) }
        }
    }

    private fun show(n: Int) {
        page = n
        pages.forEachIndexed { i, p -> p.visibility = if (i == n) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, t ->
            if (i == n) { t.setTextColor(Color.WHITE); t.background = rounded(CYAN, 22, 0, PINK) }
            else { t.setTextColor(MUTED); t.background = null }
        }
    }

    // ================= HOME =================
    private fun pageHome(): View {
        hTitle = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(14), 0, dp(2))
        }
        hSub = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.CENTER }
        hTime = TextView(this).apply { textSize = 11f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.END }
        hSeek = SeekBar(this).apply {
            max = 1000; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    val f = (s?.progress ?: 0) / 1000f
                    cmd("SEEK") { it.putExtra("f", f) }
                }
            })
        }
        hPlay = circle("▶\uFE0E", 72, true) {
            if (PlayerState.running) cmd("TOGGLE") else startFloating(Store.int(this, "last", 0))
        }
        val art = TextView(this).apply {
            text = "♫"; textSize = 52f; gravity = Gravity.CENTER
            background = oval(Color.parseColor("#33FFFFFF"), Color.parseColor("#22FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            addView(circle("|◀\uFE0E", 52, false) { cmd("PREV") })
            addView(hPlay)
            addView(circle("▶\uFE0E|", 52, false) { cmd("NEXT") })
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#00B8D4"), PURPLE, PINK)
            ).apply { cornerRadius = dp(30).toFloat() }
            setPadding(dp(20), dp(26), dp(20), dp(20))
            addView(art); addView(hTitle); addView(hSub); addView(gap(8)); addView(hSeek); addView(hTime); addView(controls)
        }
        hPower = pill("▶\uFE0E  Nyalakan Floating Player", CYAN, PINK) {
            if (PlayerState.running) cmd("STOP") else startFloating(Store.int(this, "last", 0))
        }
        hWarn = label("[!] Izin \"Tampil di atas aplikasi lain\" belum aktif. Tap tombol di atas buat ngatur.", 12f, PINK)
        return scroll(
            label("FF Music", 26f, Color.WHITE, true),
            label("Pilih suasana, lalu gas main", 13f, MUTED),
            chipBar(true),
            gap(), card, gap(14), hPower,
            gap(8), pill("◈  MODE GAME — boost + musik + buka game", PINK, PURPLE) { gameMode() },
            hWarn,
            label("Tips: tap bubble ♫ di game buat buka kontrol, geser buat pindahin, ◎ buat sembunyiin total.", 12f, MUTED)
        )
    }

    private fun updateHome() {
        if (!::hTitle.isInitialized) return
        val run = PlayerState.running
        val a = albums.getOrNull(active())
        val n = a?.tracks?.size ?: 0
        val an = if (a != null) "${a.emoji} ${a.name}" else ""
        hTitle.text = if (run && PlayerState.title.isNotEmpty()) PlayerState.title else "Belum ada lagu diputar"
        hSub.text = if (run) "${if (PlayerState.playing) "Sedang diputar" else "Dijeda"} • $an • lagu ${PlayerState.idx + 1}/$n"
        else "Album $an • $n lagu"
        hPlay.text = if (PlayerState.playing) "❚❚" else "▶\uFE0E"
        hPower.text = if (run) "■  Matikan Floating Player" else "▶\uFE0E  Nyalakan Floating Player"
        hWarn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        if (!seeking) {
            hSeek.progress = if (PlayerState.dur > 0) (PlayerState.pos * 1000 / PlayerState.dur).toInt() else 0
            hTime.text = if (run) "${fmt(PlayerState.pos)} / ${fmt(PlayerState.dur)}" else "0:00 / 0:00"
        }
    }

    private fun startFloating(i: Int, intro: Array<String>? = null, turbo: Boolean = false) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan 'Tampil di atas aplikasi lain' dulu, lalu balik & tekan lagi")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        if (Store.activeTracks(this).isEmpty()) { toast("Album kosong, tambah lagu dulu"); return }
        startForegroundService(Intent(this, OverlayService::class.java).setAction("START").putExtra("idx", i)
            .also { if (intro != null) it.putExtra("intro", intro); if (turbo) it.putExtra("turbo", true) })
        toast("Nyala! Buka game kamu")
    }

    // ================= ALBUM =================
    private fun pageAlbum(): View {
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        countTv = label("", 12f, MUTED)
        albumTitle = label("", 20f, Color.WHITE, true)
        val search = field("Cari di album ini")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filter = s?.toString()?.trim() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(mini("＋ Baru") { newAlbum() })
            addView(mini("✎ Nama") { renameAlbum() })
            addView(mini("⇪ Bagikan") { shareAlbum() })
            addView(mini("✕ Hapus") { deleteAlbum() })
        }
        val actions2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(mini("A–Z") { sortAlbum(0) })
            addView(mini("⇄ Acak") { sortAlbum(1) })
            addView(mini("↕\uFE0E Balik") { sortAlbum(2) })
            addView(mini("⧉ Duplikat") { dedupe() })
        }
        return scroll(
            label("Album ♫", 26f, Color.WHITE, true),
            label("Kelompokin lagu sesuai suasana: santai, bantai, dll.", 12f, MUTED),
            chipBar(false), gap(4), actions, gap(6), actions2, gap(6),
            albumTitle, search, countTv, gap(4),
            pill("▶\uFE0E  Putar album ini", CYAN, PINK) { playAlbum(view) }, gap(), listBox
        )
    }

    private fun kindLabel(k: String) = when (k) {
        "query" -> "Cari otomatis • cache offline"
        "yt" -> "YouTube • cache offline"
        "file" -> "File di dalam app"
        else -> "Link audio • cache offline"
    }

    private fun refresh() {
        if (!::listBox.isInitialized) return
        val a = albums.getOrNull(view) ?: return
        listBox.removeAllViews()
        albumTitle.text = "${a.emoji} ${a.name}"
        val shown = a.tracks.withIndex().filter { filter.isEmpty() || it.value.title.contains(filter, true) }
        countTv.text = "${a.tracks.size} lagu" + (if (filter.isNotEmpty()) " • ${shown.size} cocok" else "") + " • tap lagu buat muter"
        if (shown.isEmpty()) listBox.addView(label("Kosong. Tambah lagu di tab +", 13f, MUTED))
        shown.forEach { (i, t) ->
            val playing = PlayerState.running && PlayerState.album == view && PlayerState.idx == i
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, 18, if (playing) CYAN else 0)
                setPadding(dp(12), dp(10), dp(4), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                setOnClickListener { playTrack(view, i) }
            }
            row.addView(TextView(this).apply {
                text = if (playing) "♫" else "${i + 1}"; gravity = Gravity.CENTER; textSize = 13f
                setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                background = oval(CYAN, PINK)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(12) }
            })
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(TextView(context).apply { text = t.title; setTextColor(Color.WHITE); textSize = 14f; maxLines = 2 })
                addView(TextView(context).apply { text = kindLabel(t.kind) + playsOf(t); setTextColor(MUTED); textSize = 10.5f })
            })
            row.addView(TextView(this).apply {
                text = "⋮"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(4), dp(14), dp(4))
                setOnClickListener { trackMenu(i) }
            })
            listBox.addView(row)
        }
    }

    private fun playsOf(t: Track): String {
        val n = Store.int(this, "pc:" + t.src, 0)
        return if (n > 0) " • ▶\uFE0E ${n}×" else ""
    }

    private fun sortAlbum(mode: Int) {
        val a = albums.getOrNull(view) ?: return
        when (mode) {
            0 -> a.tracks.sortBy { it.title.lowercase() }
            1 -> a.tracks.shuffle()
            else -> Collections.reverse(a.tracks)
        }
        persist()
        toast(when (mode) { 0 -> "Diurutkan A–Z"; 1 -> "Urutan diacak"; else -> "Urutan dibalik" })
    }

    private fun dedupe() {
        val a = albums.getOrNull(view) ?: return
        val seen = HashSet<String>()
        val before = a.tracks.size
        val it2 = a.tracks.iterator()
        while (it2.hasNext()) { if (!seen.add(it2.next().title.lowercase())) it2.remove() }
        persist()
        val n = before - a.tracks.size
        toast(if (n == 0) "Gak ada lagu dobel" else "$n lagu dobel dihapus")
    }

    private fun trackMenu(i: Int) {
        val a = albums.getOrNull(view) ?: return
        val t = a.tracks.getOrNull(i) ?: return
        val items = arrayOf("▶\uFE0E  Putar", "♥\uFE0E  Tambah ke Favorit", "⇄  Pindah ke album lain", "▲  Naik", "▼  Turun", "✕  Hapus")
        AlertDialog.Builder(this).setTitle(t.title).setItems(items) { _, w ->
            when (w) {
                0 -> playTrack(view, i)
                1 -> {
                    val ok = Store.addFavorite(this, t)
                    albums = Store.albums(this)
                    rebuildChips(); refresh()
                    if (ok) cmd("RELOAD")
                    toast(if (ok) "♥\uFE0E Masuk album Favorit" else "Sudah ada di Favorit")
                }
                2 -> moveDialog(i)
                3 -> if (i > 0) { Collections.swap(a.tracks, i, i - 1); persist() }
                4 -> if (i < a.tracks.size - 1) { Collections.swap(a.tracks, i, i + 1); persist() }
                5 -> { deleteFile(t); a.tracks.removeAt(i); persist() }
            }
        }.show()
    }

    private fun moveDialog(i: Int) {
        val names = albums.map { "${it.emoji} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pindah ke album…").setItems(names) { _, k ->
            if (k != view) {
                val from = view
                val t = albums[from].tracks.removeAt(i)
                albums[k].tracks.add(t)
                Store.saveAlbums(this, albums)
                refresh()
                cmd("RELOAD")
                toast("Dipindah ke ${albums[k].name}")
            }
        }.show()
    }

    private fun newAlbum() {
        askText("Album baru", "") { name ->
            albums.add(Album(name.take(30), emojis[albums.size % emojis.size]))
            view = albums.size - 1; filter = ""
            persist()
        }
    }

    private fun renameAlbum() {
        val a = albums.getOrNull(view) ?: return
        askText("Ganti nama album", a.name) { name -> a.name = name.take(30); persist() }
    }

    private fun deleteAlbum() {
        if (albums.size <= 1) { toast("Minimal harus ada 1 album"); return }
        val a = albums.getOrNull(view) ?: return
        AlertDialog.Builder(this).setTitle("Hapus album ${a.name}?")
            .setMessage("${a.tracks.size} lagu di dalamnya ikut terhapus.")
            .setPositiveButton("Hapus") { _, _ ->
                a.tracks.forEach { deleteFile(it) }
                val idx = view
                val act = active()
                albums.removeAt(idx)
                val na = if (idx == act) 0 else if (idx < act) act - 1 else act
                Store.putInt(this, "album", na)
                Store.saveAlbums(this, albums)
                view = 0
                if (PlayerState.running) {
                    if (idx == act) cmd("ALBUM") { it.putExtra("idx", 0) } else cmd("RELOAD")
                }
                rebuildChips(); refresh()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun shareAlbum() {
        val a = albums.getOrNull(view) ?: return
        val n = a.tracks.count { it.kind != "file" }
        if (n == 0) { toast("Gak ada lagu yang bisa dibagikan (file upload gak ikut)"); return }
        val msg = "Album \"${a.name}\" dari FF Music ($n lagu)\n" +
            "Buka FF Music → tab Tambah → Impor album, lalu tempel kode ini:\n\n${Store.export(a)}\n\n" +
            "Download app: ${appUrl()}"
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Bagikan album"
        ))
        if (n < a.tracks.size) toast("File upload gak ikut dibagikan")
    }

    private fun importDialog() {
        val e = field("Tempel kode album di sini (ffm1:…)", 4)
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this).setTitle("Impor album dari teman").setView(box)
            .setPositiveButton("Impor") { _, _ ->
                val a = Store.importCode(e.text.toString())
                if (a == null) toast("Kode gak valid")
                else {
                    albums.add(a); view = albums.size - 1; filter = ""
                    persist()
                    toast("Album ${a.name} masuk • ${a.tracks.size} lagu")
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    // ================= TAMBAH =================
    private fun pageAdd(): View {
        resBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val q = field("Cari lagu / artis")
        val one = field("Judul lagu atau link (mp3 / YouTube)")
        val bulk = field("Tulis daftar judul, 1 baris 1 lagu.\nContoh:\nDecember - Neck Deep\nWish You Were Here - Neck Deep", 6)
        return scroll(
            label("Tambah Lagu +", 26f, Color.WHITE, true),
            label("Masuk ke album:", 12f, MUTED), chipBar(false), gap(4),
            label("Cari lagu", 15f, Color.WHITE, true), q, gap(6),
            pill("Cari", CYAN, PINK) { doSearch(q.text.toString()) }, resBox, gap(),
            label("Tulis judul / tempel link", 15f, Color.WHITE, true), one, gap(6),
            pill("+  Tambah", CYAN, PINK) {
                parse(one.text.toString())?.let { addTracks(listOf(it)); one.setText("") }
            }, gap(),
            pill("↑  Upload audio dari HP", PINK, PURPLE) { pick() },
            gap(), label("Tambah banyak sekaligus", 15f, Color.WHITE, true), bulk, gap(6),
            pill("≡  Tambah semua", PURPLE, CYAN) {
                addTracks(bulk.text.toString().lines().mapNotNull { parse(it) })
                bulk.setText("")
            },
            gap(), pill("⇩  Impor album dari teman", PINK, PURPLE) { importDialog() }
        )
    }

    private fun doSearch(q: String) {
        val s = q.trim()
        if (s.isEmpty()) return
        resBox.removeAllViews()
        resBox.addView(label("Mencari…", 12f, MUTED))
        Thread {
            val hits = Resolver.search(s)
            runOnUiThread { showHits(hits) }
        }.start()
    }

    private fun showHits(hits: List<Resolver.Hit>) {
        resBox.removeAllViews()
        if (hits.isEmpty()) {
            resBox.addView(label("Gak ada hasil / server lagi down. Coba lagi, atau isi server sendiri di Setelan.", 12f, PINK))
            return
        }
        val ti = view
        hits.forEach { h ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, 16)
                setPadding(dp(14), dp(8), dp(6), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            }
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(TextView(context).apply { text = h.title; setTextColor(Color.WHITE); textSize = 13f; maxLines = 2 })
                addView(TextView(context).apply { text = h.by; setTextColor(MUTED); textSize = 11f })
            })
            val add = TextView(this)
            add.text = "＋"; add.setTextColor(CYAN); add.textSize = 22f; add.gravity = Gravity.CENTER
            add.setPadding(dp(14), dp(4), dp(14), dp(4))
            add.setOnClickListener {
                val a = albums.getOrNull(ti)
                if (a != null) {
                    if (a.tracks.any { it.src == h.id }) toast("Sudah ada di ${a.name}")
                    else {
                        a.tracks.add(Track(h.title, h.id, "yt"))
                        persist(ti)
                        add.text = "✓"
                        toast("Masuk ke ${a.emoji} ${a.name}")
                    }
                }
            }
            row.addView(add)
            resBox.addView(row)
        }
    }

    private fun parse(s: String): Track? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val yt = Regex("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").find(t)
        return when {
            t.startsWith("http") && yt != null -> Track("YouTube ${yt.groupValues[1]}", yt.groupValues[1], "yt")
            t.startsWith("http") -> Track(Uri.parse(t).lastPathSegment ?: t, t, "url")
            else -> Track(t, t, "query")
        }
    }

    private fun addTracks(new: List<Track>) {
        val ti = view
        val a = albums.getOrNull(ti) ?: return
        val fresh = new.filter { n -> a.tracks.none { it.src == n.src } }
        if (fresh.isEmpty()) { toast("Kosong / sudah ada di album ini"); return }
        val slow = fresh.filter { it.kind == "url" || it.kind == "yt" }
        a.tracks.addAll(fresh.filter { it !in slow })
        persist(ti)
        if (slow.isEmpty()) { toast("Tersimpan di ${a.name}"); return }
        toast("Proses ${slow.size} link…")
        Thread {
            val done = slow.map {
                if (it.kind == "url") download(it) else Track(Resolver.ytTitle(it.src) ?: it.title, it.src, "yt")
            }
            runOnUiThread {
                albums.getOrNull(ti)?.tracks?.addAll(done)
                persist(ti)
                val bad = done.count { it.kind == "url" }
                if (bad > 0) toast("$bad link bukan file audio langsung, disimpan sebagai link") else toast("Tersimpan")
            }
        }.start()
    }

    // link audio langsung (mp3/m4a/dll) -> diunduh & disimpan di dalam app
    private fun download(t: Track): Track {
        try {
            val c = URL(t.src).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val ct = c.contentType ?: ""
            if (!ct.startsWith("audio") && !ct.contains("octet-stream")) return t
            val dir = File(filesDir, "songs").apply { mkdirs() }
            val base = (Uri.parse(t.src).lastPathSegment ?: "audio").replace(Regex("[^A-Za-z0-9._-]"), "_")
            val out = File(dir, "${System.currentTimeMillis()}_$base")
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            return Track(t.title.substringBeforeLast('.'), Uri.fromFile(out).toString(), "file")
        } catch (_: Exception) {
            return t
        }
    }

    private fun pick() {
        pickTi = view
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req == 11) { handleVideoPick(res, d); return }
        if (req != 1 || res != RESULT_OK || d == null) return
        val ti = pickTi
        val uris = LinkedHashSet<Uri>()   // dobel (data + clipData) otomatis dibuang
        d.data?.let { uris.add(it) }
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        toast("Nyalin ${uris.size} file ke dalam app…")
        Thread {
            val dir = File(filesDir, "songs").apply { mkdirs() }
            val added = mutableListOf<Track>()
            var bad = 0
            uris.forEachIndexed { n, u ->
                var out: File? = null
                try {
                    var name = u.lastPathSegment ?: "Audio"
                    contentResolver.query(u, null, null, null, null)?.use { c ->
                        val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (k >= 0 && c.moveToFirst()) name = c.getString(k)
                    }
                    // nama unik per file (timestamp + nomor urut), biar gak saling timpa
                    val f = File(dir, "${System.currentTimeMillis()}_${n}_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    out = f
                    contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    if (!f.exists() || f.length() <= 0L) throw IllegalStateException("kosong")
                    added.add(Track(name.substringBeforeLast('.').ifBlank { "Audio ${n + 1}" }, Uri.fromFile(f).toString(), "file"))
                } catch (_: Exception) {
                    bad++
                    try { out?.delete() } catch (_: Exception) {}
                }
            }
            runOnUiThread {
                albums.getOrNull(ti)?.tracks?.addAll(added)
                persist(ti)
                toast(if (bad == 0) "${added.size} lagu tersimpan" else "${added.size} tersimpan, $bad gagal disalin")
            }
        }.start()
    }

    // ================= VIDEO =================
    private fun pageVideo(): View {
        vInput = field("Tempel link YouTube / TikTok / link video…")
        vInput.isSingleLine = true
        vList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        vSaved = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        vProg = label("", 11f, CYAN)
        return scroll(
            label("Video ▶\uFE0E", 26f, Color.WHITE, true),
            label("Nonton dari link YouTube, TikTok, atau link video langsung, atau upload dari HP. Sampai 4K kalau sumbernya ada dan HP kuat.", 12f, MUTED),
            gap(), vInput, gap(6),
            pill("▶\uFE0E  Putar link", PURPLE, CYAN) { playLink() },
            gap(6), pill("⇩  Simpan link ke offline", Color.parseColor("#33334D"), Color.parseColor("#33334D")) { downloadLink() },
            gap(6), pill("＋  Upload video dari HP", Color.parseColor("#33334D"), Color.parseColor("#33334D")) { pickVideo() },
            gap(6), toggleRow("Video upload juga disalin ke dalam app (offline, makan memori HP)", "vcopy", true),
            gap(), label("Kualitas utama", 15f, Color.WHITE, true),
            chipsScroll(listOf("360p", "720p", "1080p", "2K", "4K"), { Store.int(this, "vq", 2) }, {
                Store.putInt(this, "vq", it)
            }) {},
            label("Kalau kualitas yang dipilih gak ada, otomatis turun ke yang paling dekat. Bisa diganti pas lagi nonton. 4K butuh HP yang bisa decode VP9.", 11f, MUTED),
            gap(), label("Offline (tersimpan di app, tanpa internet)", 15f, Color.WHITE, true), vProg, vSaved,
            gap(), label("Terakhir diputar", 15f, Color.WHITE, true), vList,
            gap(), label("Tips: dari YouTube / TikTok tekan Bagikan lalu pilih FF Music Video, langsung kebuka di sini.", 11f, MUTED),
            label("YouTube lewat Piped dan TikTok lewat TikWM (API pihak ketiga gratis, kadang mati atau dibatasi). Server sendiri / Cobalt bisa diisi di Setelan.", 11f, MUTED)
        )
    }

    private fun videoTag(v: VideoItem) = when {
        v.kind == "local" -> "Video di HP"
        v.src.contains("tiktok.com", true) -> "TikTok"
        v.src.contains("youtu", true) -> "YouTube"
        else -> "Link"
    }

    private fun refreshVideos() {
        if (!::vList.isInitialized) return
        // ----- offline -----
        vSaved.removeAllViews()
        val sv = Store.saved(this)
        if (sv.isEmpty()) {
            vSaved.addView(label("Belum ada. Tekan SIMPAN pas nonton, atau Simpan link ke offline.", 12f, MUTED))
        } else {
            val total = sv.sumOf { Store.savedBytes(it) }
            vSaved.addView(label("${sv.size} video • ${fmtSize(total)} terpakai di HP", 11f, MUTED))
            sv.forEach { v ->
                vSaved.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(CARD, 16, Color.parseColor("#3300E5FF"))
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
                    addView(TextView(context).apply {
                        text = v.title; setTextColor(Color.WHITE); textSize = 14f
                        maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                    addView(TextView(context).apply {
                        text = "Offline • ${fmtSize(Store.savedBytes(v))}"; setTextColor(CYAN); textSize = 10.5f
                    })
                    setOnClickListener { openVideo(listOf(v), 0) }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity).setTitle(v.title)
                            .setMessage("Hapus video offline ini? File-nya ikut dihapus dari HP.")
                            .setPositiveButton("Hapus") { _, _ -> Store.removeSaved(this@MainActivity, v.src); refreshVideos() }
                            .setNegativeButton("Batal", null).show()
                        true
                    }
                })
            }
            vSaved.addView(gap(8))
            vSaved.addView(pill("Hapus semua video offline", Color.parseColor("#33334D"), Color.parseColor("#33334D")) {
                AlertDialog.Builder(this).setTitle("Hapus semua video offline?")
                    .setMessage("${sv.size} video (${fmtSize(total)}) akan dihapus dari HP.")
                    .setPositiveButton("Hapus semua") { _, _ -> Store.saved(this).forEach { Store.removeSaved(this, it.src) }; refreshVideos() }
                    .setNegativeButton("Batal", null).show()
            })
        }
        // ----- terakhir diputar -----
        vList.removeAllViews()
        val l = Store.videos(this)
        if (l.isEmpty()) {
            vList.addView(label("Belum ada. Tempel link atau upload video di atas.", 12f, MUTED))
            return
        }
        l.forEach { v ->
            vList.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(CARD, 16)
                setPadding(dp(14), dp(11), dp(14), dp(11))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                addView(TextView(context).apply {
                    text = v.title; setTextColor(Color.WHITE); textSize = 14f
                    maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                })
                addView(TextView(context).apply { text = videoTag(v); setTextColor(MUTED); textSize = 10.5f })
                setOnClickListener { openVideo(listOf(v), 0) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle(v.title)
                        .setMessage("Hapus dari daftar? (file video di HP tetap aman)")
                        .setPositiveButton("Hapus") { _, _ -> Store.removeVideo(this@MainActivity, v.src); refreshVideos() }
                        .setNegativeButton("Batal", null).show()
                    true
                }
            })
        }
    }

    // unduh link (YouTube/TikTok/dll) ke penyimpanan app, tanpa harus nonton dulu
    private fun downloadLink() {
        val u = VideoResolver.firstUrl(vInput.text.toString())
        if (u == null) { toast("Tempel link yang valid dulu"); return }
        val h = intArrayOf(360, 720, 1080, 1440, 2160)[Store.int(this, "vq", 2).coerceIn(0, 4)]
        Downloads.enqueue(this, Downloads.Job(u, "link", u, h))
        vInput.setText("")
        toast("Mulai unduh, bisa ditinggal. Progress ada di notifikasi")
    }

    private fun openVideo(items: List<VideoItem>, start: Int) {
        startActivity(
            Intent(this, VideoActivity::class.java)
                .putExtra("srcs", items.map { it.src }.toTypedArray())
                .putExtra("titles", items.map { it.title }.toTypedArray())
                .putExtra("kinds", items.map { it.kind }.toTypedArray())
                .putExtra("start", start)
        )
    }

    private fun playLink() {
        val u = VideoResolver.firstUrl(vInput.text.toString())
        if (u == null) { toast("Tempel link yang valid dulu"); return }
        val v = VideoItem(u, u, "link")
        Store.addVideo(this, v)
        vInput.setText("")
        openVideo(listOf(v), 0)
    }

    private fun pickVideo() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, 11)
    }

    // video dari HP gak disalin (hemat memori & instan), cukup diingat aksesnya
    private fun handleVideoPick(res: Int, d: Intent?) {
        if (res != RESULT_OK || d == null) return
        val uris = LinkedHashSet<Uri>()
        d.data?.let { uris.add(it) }
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        val items = mutableListOf<VideoItem>()
        uris.forEach { u ->
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            var name = u.lastPathSegment ?: "Video"
            try {
                contentResolver.query(u, null, null, null, null)?.use { c ->
                    val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (k >= 0 && c.moveToFirst()) name = c.getString(k)
                }
            } catch (_: Exception) {}
            items.add(VideoItem(name.substringBeforeLast('.').ifBlank { "Video" }, u.toString(), "local"))
        }
        if (items.isEmpty()) return
        if (Store.int(this, "vcopy", 1) == 1) {
            // disalin ke dalam app di latar belakang (jadi offline & aman walau file aslinya dihapus)
            items.forEach { Downloads.enqueue(this, Downloads.Job(it.title, "copy", it.src, 0)) }
            toast("Disalin ke dalam app di latar belakang")
        } else {
            items.reversed().forEach { Store.addVideo(this, it) }
        }
        refreshVideos()
        openVideo(items, 0)
    }

    // ================= UPDATE APLIKASI =================
    private fun autoCheckUpdate() {
        val last = Store.str(this, "upd_ts")?.toLongOrNull() ?: 0L
        if (System.currentTimeMillis() - last < 6 * 3600_000L) return
        Store.putStr(this, "upd_ts", System.currentTimeMillis().toString())
        Thread {
            try {
                val info = Updater.check(this)
                if (info != null && Store.str(this, "upd_skip") != info.version) {
                    runOnUiThread { if (!isFinishing) showUpdateDialog(info) }
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun checkUpdate(manual: Boolean) {
        if (manual) updStatus.text = "Ngecek update…"
        Thread {
            try {
                val info = Updater.check(this)
                runOnUiThread {
                    if (info == null) { if (manual) updStatus.text = "Udah versi terbaru (v${appVersion()})" }
                    else { updStatus.text = "Update tersedia: v${info.version}"; showUpdateDialog(info) }
                }
            } catch (e: Exception) {
                runOnUiThread { if (manual) updStatus.text = "Gagal cek update: ${e.message ?: "cek koneksi"}" }
            }
        }.start()
    }

    private fun showUpdateDialog(info: Updater.Info) {
        val notes = info.notes.trim().take(500).ifEmpty { "Perbaikan & fitur baru." }
        val mb = if (info.size > 0) " (${info.size / 1024 / 1024} MB)" else ""
        AlertDialog.Builder(this)
            .setTitle("Update tersedia: v${info.version}")
            .setMessage("Kamu pakai v${appVersion()}$mb\n\n$notes")
            .setPositiveButton("Update sekarang") { _, _ -> startUpdate(info) }
            .setNegativeButton("Nanti") { _, _ -> Store.putStr(this, "upd_skip", info.version) }
            .show()
    }

    private fun startUpdate(info: Updater.Info) {
        val pb = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val box = LinearLayout(this).apply { setPadding(dp(24), dp(16), dp(24), dp(8)); addView(pb, LinearLayout.LayoutParams(-1, -2)) }
        val dlg = AlertDialog.Builder(this).setTitle("Mengunduh v${info.version}…").setView(box).setCancelable(false).show()
        Thread {
            try {
                val f = Updater.download(this, info) { p -> runOnUiThread { pb.progress = p } }
                runOnUiThread {
                    dlg.dismiss()
                    if (!Updater.signatureOk(this, f)) { signatureDialog(); return@runOnUiThread }
                    if (!Updater.install(this, f)) toast("Aktifkan izin 'Pasang app dari sumber ini', lalu tekan Update lagi")
                }
            } catch (e: Exception) {
                runOnUiThread { dlg.dismiss(); toast("Gagal unduh: ${e.message ?: "cek koneksi"}") }
            }
        }.start()
    }

    // tanda tangan APK baru beda -> Android PASTI nolak. Jelasin & kasih jalan keluar, bukan error misterius.
    private fun signatureDialog() {
        AlertDialog.Builder(this).setTitle("Tanda tangan app beda")
            .setMessage("APK baru ditandatangani kunci yang berbeda dari app yang terpasang (biasanya karena versi lama di-build dengan kunci acak), jadi Android menolak menimpanya.\n\nSekali ini aja: backup album pakai tombol Bagikan di tab Album, hapus FF Music, lalu pasang APK terbaru dari halaman download. Setelah itu update berikutnya langsung nimpa tanpa masalah.")
            .setPositiveButton("Buka halaman download") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(appUrl())))
            }
            .setNeutralButton("Hapus app ini") { _, _ ->
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Tutup", null).show()
    }

    // ================= GAME / BOOSTER =================
    private fun toggleRow(text: String, key: String, def: Boolean, after: () -> Unit = {}): TextView {
        val v = TextView(this)
        fun on() = Store.int(this, key, if (def) 1 else 0) == 1
        fun paint() {
            v.text = (if (on()) "●  " else "○  ") + text
            v.setTextColor(if (on()) Color.WHITE else MUTED)
            v.background = rounded(CARD, 14, if (on()) CYAN else 0)
        }
        v.textSize = 13f
        v.setPadding(dp(14), dp(12), dp(14), dp(12))
        v.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        v.setOnClickListener {
            Store.putInt(this, key, if (on()) 0 else 1)
            paint(); after()
        }
        paint()
        return v
    }

    private fun pageGame(): View {
        gGame = label("", 14f, Color.WHITE, true)
        gStats = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE)
            background = rounded(CARD, 18, Color.parseColor("#3300E5FF"))
            setPadding(dp(16), dp(14), dp(16), dp(14)); setLineSpacing(0f, 1.2f)
        }
        gResult = label("", 12f, MUTED)
        gTotal = label("", 11f, CYAN)
        dndBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        return scroll(
            label("Game ◈", 26f, Color.WHITE, true),
            label("Satu tombol: boost HP, nyalain musik, langsung buka game.", 12f, MUTED),
            gap(), pill("◈  MODE GAME — Mulai Main", PINK, PURPLE) { gameMode() },
            gap(14), label("Game yang dibuka", 15f, Color.WHITE, true), gGame,
            pill("Pilih game", CYAN, PINK) { pickGame() },
            gap(14), label("Status HP", 15f, Color.WHITE, true), gStats, gap(6),
            pill("➤  Boost HP sekarang", PURPLE, CYAN) { boostNow() }, gResult, gTotal,
            gap(4), pill("☰  Aplikasi yang jangan ditutup", Color.parseColor("#33334D"), Color.parseColor("#33334D")) { keepDialog() },
            gap(6), pill("◎  Tes ping jaringan", PURPLE, CYAN) { testPing() },
            label("Boost = nutup app yang masih jalan di background biar RAM lega. Gak bisa naikin spek HP, tapi game jadi lebih lega & minim lag.", 11f, MUTED),
            gap(10), label("Opsi Mode Game", 15f, Color.WHITE, true),
            toggleRow("Boost otomatis pas Mode Game", "boost", true),
            toggleRow("Jangan Ganggu otomatis (bungkam telepon, chat & notif)", "dnd", true),
            label("Level Jangan Ganggu", 13f, MUTED),
            chips(listOf("Total (telepon juga)", "Telepon boleh"), { Store.int(this, "dndlvl", 0) }) {
                Store.putInt(this, "dndlvl", it)
            },
            gap(6),
            toggleRow("Animasi MODE GAME pas aktif", "intro", true),
            toggleRow("Equalizer Game otomatis (langkah & tembakan lebih jelas)", "gameeq", true) { cmd("APPLY") },
            toggleRow("TURBO MAKSIMAL pas Mode Game (layar refresh rate tertinggi, wifi low-latency, CPU tetap nyala, boost 2 putaran)", "turbo", true),
            label("Turbo gak bisa overclock CPU/GPU (itu butuh root), tapi ini batas maksimal yang diizinkan Android. Kecepatan sentuhan (touch sampling) diatur HP & setelan game, bukan app.", 11f, MUTED),
            toggleRow("Auto-boost berkala pas floating aktif", "autoboost", false),
            chips(listOf("1 mnt", "3 mnt", "5 mnt", "10 mnt"), { Store.int(this, "autoint", 2) }) {
                Store.putInt(this, "autoint", it)
            },
            gap(6),
            dndBox,
            toggleRow("Layar tetap nyala pas floating aktif", "awake", true) { cmd("APPLY") },
            toggleRow("Info baterai, suhu & RAM di floating", "hud", true) { cmd("APPLY") },
            gap(10), label("Biar makin ngebut", 15f, Color.WHITE, true),
            label("• Matikan Hemat Baterai & nyalain Mode Performa / Game Turbo bawaan HP\n• Bersihin layar, tangan kering, lepas screen protector tebal biar tombol tembak lebih licin\n• Di setelan game, naikin Sensitivitas & pilih FPS tertinggi yang stabil\n• Matikan gesture tepi / proteksi sentuhan tak sengaja kalau tombol sering nyangkut\n• Tutup app berat, colok charger kalau HP panas, pakai wifi stabil", 12f, MUTED)
        )
    }

    private fun updateGame() {
        if (!::gStats.isInitialized) return
        val b = Booster.battery(this)
        var extra = ""
        if (Booster.powerSave(this)) extra += "\n[!] Hemat Baterai AKTIF, matikan biar game ngebut"
        if (b.temp >= 42f) extra += "\n[!] HP panas, istirahat bentar & lepas casing"
        gStats.text = "RAM bebas     ${Booster.availMb(this)} MB / ${Booster.totalMb(this)} MB\n" +
            "Baterai         ${b.pct}%\nSuhu              ${"%.1f".format(b.temp)}°C\nLayar              ${Booster.maxHz(this)} Hz maks" + extra
        gGame.text = Store.str(this, "gamename") ?: "Belum dipilih"
        gTotal.text = "Total: ${Store.int(this, "freed_total", 0)} MB dilegakan • ${Store.int(this, "boost_count", 0)}× boost"
    }

    private fun keepDialog() {
        val apps = Booster.launchables(this)
        if (apps.isEmpty()) { toast("Gak ada app yang bisa dipilih"); return }
        val cur = (Store.str(this, "keep") ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].second in cur }
        AlertDialog.Builder(this).setTitle("Jangan ditutup pas boost")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, w, on ->
                if (on) cur.add(apps[w].second) else cur.remove(apps[w].second)
            }
            .setPositiveButton("Simpan") { _, _ ->
                Store.putStr(this, "keep", cur.joinToString(","))
                toast("${cur.size} app dilindungi")
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun testPing() {
        gResult.text = "Ngetes ping…"
        Thread {
            val ok = listOf(Booster.ping(), Booster.ping(), Booster.ping()).filter { it >= 0 }
            runOnUiThread {
                gResult.text = if (ok.isEmpty()) "Ping gagal, cek koneksi" else {
                    val ms = ok.average().toInt()
                    "Ping ≈ $ms ms • " + when {
                        ms < 50 -> "mantap"
                        ms < 100 -> "oke"
                        ms < 180 -> "agak delay"
                        else -> "lag, coba pindah wifi/sinyal"
                    }
                }
            }
        }.start()
    }

    private fun pickGame() {
        val apps = Booster.launchables(this)
        if (apps.isEmpty()) { toast("Gak ada app yang bisa dipilih"); return }
        AlertDialog.Builder(this).setTitle("Pilih game").setItems(apps.map { it.first }.toTypedArray()) { _, w ->
            Store.putStr(this, "game", apps[w].second)
            Store.putStr(this, "gamename", apps[w].first)
            updateGame()
        }.show()
    }

    private fun boostNow() {
        gResult.text = "Membersihkan…"
        val keep = setOfNotNull(Store.str(this, "game"))
        Thread {
            val r = if (Store.int(this, "turbo", 1) == 1) Booster.cleanMax(this, keep) else Booster.clean(this, keep)
            runOnUiThread {
                gResult.text = "✓ +${r.freed} MB RAM lega • ${r.killed} app di background dibersihkan"
                updateGame()
            }
        }.start()
    }

    private fun gameMode() {
        if (!Settings.canDrawOverlays(this)) { startFloating(0); return }
        val pkg = Store.str(this, "game")
        if (pkg == null) { toast("Pilih game dulu"); show(4); pickGame(); return }
        if (Store.activeTracks(this).isEmpty()) { toast("Album kosong, tambah lagu dulu"); return }
        val wantDnd = Store.int(this, "dnd", 1) == 1
        if (wantDnd && !Booster.dndGranted(this)) {
            toast("Izinkan akses Jangan Ganggu dulu, lalu tekan Mode Game lagi")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        toast("Menyiapkan Mode Game…")
        val doBoost = Store.int(this, "boost", 1) == 1
        val turbo = Store.int(this, "turbo", 1) == 1
        Thread {
            val r = if (doBoost) (if (turbo) Booster.cleanMax(this, setOf(pkg)) else Booster.clean(this, setOf(pkg))) else null
            runOnUiThread {
                val dndOn = wantDnd && Booster.dndGranted(this)
                if (dndOn) Booster.dndOn(this)
                val eqOn = Store.int(this, "gameeq", 1) == 1
                if (eqOn) { Booster.gameEqOn(this); if (PlayerState.running) cmd("APPLY") }
                val lines = ArrayList<String>()
                if (r != null) lines.add("BOOST RAM +${r.freed} MB")
                if (dndOn) lines.add(
                    if (Store.int(this, "dndlvl", 0) == 0) "SEMUA TELEPON & CHAT DIBUNGKAM"
                    else "CHAT & NOTIF DIBUNGKAM, TELEPON BOLEH"
                )
                if (turbo) lines.add("TURBO: REFRESH RATE + JARINGAN MAKS")
                if (eqOn) lines.add("EQUALIZER GAME AKTIF")
                lines.add("MUSIK: ${albums.getOrNull(active())?.name ?: ""}")
                val intro: Array<String>? = if (Store.int(this, "intro", 1) == 1) lines.toTypedArray() else null
                if (PlayerState.running) {
                    if (intro != null) cmd("INTRO") { it.putExtra("intro", intro) }
                    if (turbo) cmd("TURBO") { it.putExtra("on", true) }
                } else startFloating(Store.int(this, "last", 0), intro, turbo)
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else toast("Game gak ketemu, pilih ulang di tab Game")
            }
        }.start()
    }

    // ================= SETELAN =================
    private fun chips(opts: List<String>, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        fun paint() {
            views.forEachIndexed { i, v ->
                if (i == get()) { v.setTextColor(Color.WHITE); v.background = rounded(CYAN, 16, 0, PINK) }
                else { v.setTextColor(MUTED); v.background = rounded(CARD, 16) }
            }
        }
        opts.forEachIndexed { i, s ->
            val v = TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 13f; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
                setOnClickListener { set(i); paint() }
            }
            views.add(v); row.addView(v)
        }
        paint()
        return row
    }

    private fun sbar(max: Int, init: Int, onUser: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = init; tint()
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onUser(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    // chip yang bisa digeser ke samping (buat opsi banyak)
    private fun chipsScroll(opts: List<String>, get: () -> Int, set: (Int) -> Unit, reg: (() -> Unit) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        fun paint() {
            views.forEachIndexed { i, v ->
                if (i == get()) { v.setTextColor(Color.WHITE); v.background = rounded(CYAN, 16, 0, PINK) }
                else { v.setTextColor(MUTED); v.background = rounded(CARD, 16) }
            }
        }
        opts.forEachIndexed { i, s ->
            val v = TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 13f; setPadding(dp(16), dp(11), dp(16), dp(11))
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) }
                setOnClickListener { set(i); paint() }
            }
            views.add(v); row.addView(v)
        }
        paint()
        reg { paint() }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    // geser 1 pita -> otomatis pindah ke preset Custom (mulai dari kurva preset yang tadi aktif)
    private fun setBand(i: Int, pct: Int) {
        if (Store.int(this, "eq", 0) != 5) {
            val cur = Fx.curve(this, Store.int(this, "eq", 0))
            for (k in 0 until 5) Store.putInt(this, "eqb$k", (cur[k] * 100).toInt())
            Store.putInt(this, "eq", 5)
            eqRepaint()
        }
        Store.putInt(this, "eqb$i", pct)
        cmd("APPLY")
    }

    private fun syncEq() {
        val cur = Fx.curve(this, Store.int(this, "eq", 0))
        eqBars.forEachIndexed { i, b -> b.progress = 100 + (cur[i] * 100).toInt() }
        eqRepaint()
        speedRepaint()
    }

    private fun resetAudio(vararg bars: SeekBar) {
        listOf("eq", "bass", "virt", "loudg", "loud").forEach { Store.putInt(this, it, 0) }
        Store.putInt(this, "speed", 1)
        bars.forEach { it.progress = 0 }
        syncEq(); cmd("APPLY")
        toast("Audio dikembalikan normal")
    }

    private fun pageSettings(): View {
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cacheTv = label("", 13f, Color.WHITE)
        sleepTv = label("", 12f, CYAN)
        val opacity = SeekBar(this).apply {
            max = 70; progress = Store.int(this@MainActivity, "opacity", 100) - 30; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@MainActivity, "opacity", p + 30); cmd("APPLY") }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val vol = SeekBar(this).apply {
            max = 100; progress = Store.int(this@MainActivity, "vol", 100); tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@MainActivity, "vol", p); cmd("APPLY") }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val eqBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 18, Color.parseColor("#3300E5FF"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val cur0 = Fx.curve(this, Store.int(this, "eq", 0))
        Fx.bandNames.forEachIndexed { i, nm ->
            val bar = sbar(200, 100 + (cur0[i] * 100).toInt()) { p -> setBand(i, p - 100) }
            eqBars.add(bar)
            eqBox.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(TextView(context).apply {
                    text = nm; setTextColor(MUTED); textSize = 11f
                    layoutParams = LinearLayout.LayoutParams(dp(52), -2)
                })
                addView(bar, LinearLayout.LayoutParams(0, -2, 1f))
            })
        }
        val bassBar = sbar(1000, Store.int(this, "bass", 0)) { Store.putInt(this, "bass", it); cmd("APPLY") }
        val virtBar = sbar(1000, Store.int(this, "virt", 0)) { Store.putInt(this, "virt", it); cmd("APPLY") }
        val loudBar = sbar(1500, Fx.loudGain(this)) { Store.putInt(this, "loudg", it); cmd("APPLY") }
        val cob = field("https://alamat-cobalt-kamu (opsional)")
        cob.setText(Store.str(this, "cobalt") ?: ""); cob.isSingleLine = true
        val cobKey = field("API key Cobalt (kalau server-nya minta)")
        cobKey.setText(Store.str(this, "cobaltkey") ?: ""); cobKey.isSingleLine = true
        val repoF = field("user/repo GitHub (otomatis kalau APK di-build di GitHub)")
        repoF.setText(Store.str(this, "repo") ?: ""); repoF.isSingleLine = true
        updStatus = label("Versi terpasang: v${appVersion()}", 12f, MUTED)
        val host = field("https://pipedapi.contoh.com (opsional)")
        host.setText(Store.str(this, "host") ?: "")
        host.isSingleLine = true
        return scroll(
            label("Setelan ⚙\uFE0E", 26f, Color.WHITE, true),
            label("Mode putar", 15f, Color.WHITE, true),
            chips(listOf("↻ Semua", "↻1 Satu", "⇄ Acak"), { Store.int(this, "repeat", 0) }) {
                Store.putInt(this, "repeat", it); cmd("APPLY")
            },
            gap(), label("Volume musik (biar suara game tetap kedengeran)", 15f, Color.WHITE, true), vol,
            gap(), label("Equalizer", 15f, Color.WHITE, true),
            chipsScroll(Fx.names, { Store.int(this, "eq", 0) }, {
                Store.putInt(this, "eq", it); syncEq(); cmd("APPLY")
            }) { eqRepaint = it },
            gap(6), eqBox,
            gap(), label("Bass booster", 15f, Color.WHITE, true), bassBar,
            label("Virtualizer 3D (suara lebih luas, enak pakai headset)", 15f, Color.WHITE, true), virtBar,
            label("Kenceng+ (gain volume)", 15f, Color.WHITE, true), loudBar,
            gap(), label("Kecepatan putar", 15f, Color.WHITE, true),
            chipsScroll(listOf("0.75x", "1x", "1.25x", "1.5x"), { Store.int(this, "speed", 1) }, {
                Store.putInt(this, "speed", it); cmd("APPLY")
            }) { speedRepaint = it },
            gap(6), toggleRow("Fade-in tiap lagu baru", "fade", true),
            pill("↺  Reset audio ke normal", Color.parseColor("#33334D"), Color.parseColor("#33334D")) {
                resetAudio(bassBar, virtBar, loudBar)
            },
            gap(), label("Timer tidur (berhenti otomatis)", 15f, Color.WHITE, true),
            chips(listOf("Mati", "15 mnt", "30 mnt", "60 mnt", "90 mnt"), { Store.int(this, "sleepsel", 0) }) {
                Store.putInt(this, "sleepsel", it); cmd("SLEEP")
            },
            sleepTv,
            gap(), label("Ukuran bubble", 15f, Color.WHITE, true),
            chips(listOf("Kecil", "Sedang", "Besar"), { Store.int(this, "size", 1) }) {
                Store.putInt(this, "size", it); cmd("APPLY")
            },
            gap(6), toggleRow("Bubble nempel ke tepi layar", "snap", true),
            gap(), label("Transparansi floating", 15f, Color.WHITE, true), opacity,
            gap(), label("Izin & status", 15f, Color.WHITE, true), permBox,
            gap(), label("Cache lagu", 15f, Color.WHITE, true), cacheTv,
            label("Lagu yang pernah diputar disimpan di HP, jadi putar ulang bisa tanpa kuota.", 11f, MUTED),
            pill("Hapus cache", Color.parseColor("#33334D"), Color.parseColor("#33334D")) {
                if (PlayerState.running) toast("Matikan floating player dulu")
                else { File(cacheDir, "media").deleteRecursively(); updateCache(); toast("Cache dihapus") }
            },
            gap(), label("Server pencari lagu (opsional)", 15f, Color.WHITE, true),
            label("Kalau lagu sering gak ketemu, tempel alamat server Piped yang masih hidup.", 11f, MUTED),
            host, gap(6),
            pill("Simpan server", PURPLE, CYAN) {
                val h = host.text.toString().trim().trimEnd('/')
                Store.putStr(this, "host", h)
                Resolver.custom = h.ifEmpty { null }
                toast(if (h.isEmpty()) "Pakai server bawaan" else "Server disimpan")
            },
            gap(), label("Server video (opsional)", 15f, Color.WHITE, true),
            label("YouTube lewat Piped (server di atas ikut dipakai), TikTok lewat TikWM. Kalau mau YouTube/TikTok/Instagram/Twitter lebih stabil sampai 4K, tempel alamat server Cobalt kamu.", 11f, MUTED),
            cob, gap(6), cobKey, gap(6),
            pill("Simpan server video", PURPLE, CYAN) {
                Store.putStr(this, "cobalt", cob.text.toString().trim().trimEnd('/'))
                Store.putStr(this, "cobaltkey", cobKey.text.toString().trim())
                toast("Server video disimpan")
            },
            gap(), label("Update aplikasi", 15f, Color.WHITE, true), updStatus,
            gap(6), toggleRow("Cek update otomatis pas buka app", "autoupd", true),
            repoF, gap(6),
            pill("Cek update sekarang", PURPLE, CYAN) {
                Store.putStr(this, "repo", repoF.text.toString().trim())
                checkUpdate(true)
            },
            label("Update diunduh dari GitHub Releases dan dipasang langsung nimpa app lama. Tanda tangan app dijaga tetap sama, jadi gak bentrok.", 11f, MUTED),
            gap(), pill("⇪  Bagikan app ke teman", CYAN, PINK) {
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "FF Music — player musik floating buat main game\nDownload: ${appUrl()}"),
                    "Bagikan app"
                ))
            },
            gap(16), label("FF Music v${appVersion()} • by Asep", 11f, MUTED)
        )
    }

    private fun updateSettings() {
        if (!::sleepTv.isInitialized) return
        val left = PlayerState.sleepAt - System.currentTimeMillis()
        sleepTv.text = if (PlayerState.running && PlayerState.sleepAt > 0 && left > 0) "Berhenti sekitar ${left / 60000 + 1} menit lagi" else ""
    }

    private fun permRow(text: String, ok: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = (if (ok) "✓  " else "✕  ") + text
        setTextColor(if (ok) Color.WHITE else PINK); textSize = 13f
        background = rounded(CARD, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun buildPerms() {
        if (!::permBox.isInitialized) return
        permBox.removeAllViews()
        permBox.addView(permRow("Tampil di atas aplikasi lain", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        permBox.addView(permRow("Notifikasi", notifOk) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        })
        val pm = getSystemService(PowerManager::class.java)
        permBox.addView(permRow("Baterai tanpa batasan (biar gak dimatiin sistem)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        val dnd = Booster.dndGranted(this)
        permBox.addView(permRow("Akses Jangan Ganggu (buat Mode Game)", dnd) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        permBox.addView(permRow("Matikan animasi sistem pas Turbo (opsional, butuh ADB, tap)", Booster.secureGranted(this)) { adbDialog() })
        if (::dndBox.isInitialized) {
            dndBox.removeAllViews()
            if (!dnd) dndBox.addView(permRow("Izinkan akses Jangan Ganggu dulu (tap di sini)", false) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            })
        }
    }

    private fun adbDialog() {
        val line = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this).setTitle("Animasi sistem off pas Turbo")
            .setMessage("Biar layar terasa lebih licin, animasi sistem bisa dimatiin otomatis pas Turbo dan dibalikin pas selesai. Android cuma ngizinin ini lewat ADB (sekali aja, dari laptop):\n\n$line")
            .setPositiveButton("Salin perintah") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("adb", line))
                toast("Perintah disalin")
            }
            .setNegativeButton("Tutup", null).show()
    }

    private fun updateCache() {
        if (!::cacheTv.isInitialized) return
        val mb = File(cacheDir, "media").walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1048576.0
        cacheTv.text = "%.1f MB terpakai (maks 300 MB)".format(mb)
    }
}
