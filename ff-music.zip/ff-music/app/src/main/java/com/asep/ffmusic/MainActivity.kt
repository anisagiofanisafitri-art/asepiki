package com.asep.ffmusic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections

class MainActivity : Activity() {
    private var albums = mutableListOf<Album>()
    private var view = 0              // album yang lagi dilihat/diedit di tab Album & Tambah
    private var filter = ""
    private var seeking = false
    private var page = 0
    private var pickTi = 0
    private val ui = Handler(Looper.getMainLooper())
    private val chipRows = mutableListOf<Pair<LinearLayout, Boolean>>()
    private val emojis = listOf("♫", "✹", "☾", "✦", "◈", "❖", "♪", "✧")

    private lateinit var tabs: List<TextView>
    private lateinit var pages: List<View>
    private lateinit var listBox: LinearLayout
    private lateinit var resBox: LinearLayout
    private lateinit var countTv: TextView
    private lateinit var albumTitle: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var dndBox: LinearLayout
    private lateinit var cacheTv: TextView
    private lateinit var sleepTv: TextView
    private lateinit var hTitle: TextView
    private lateinit var hSub: TextView
    private lateinit var hTime: TextView
    private lateinit var hSeek: SeekBar
    private lateinit var hPlay: TextView
    private lateinit var hPower: TextView
    private lateinit var hWarn: TextView
    private lateinit var gStats: TextView
    private lateinit var gGame: TextView
    private lateinit var gResult: TextView

    private val poll = object : Runnable {
        override fun run() {
            updateHome()
            if (page == 3) updateGame()
            if (page == 4) updateSettings()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Resolver.custom = Store.str(this, "host")?.takeIf { it.isNotEmpty() }
        albums = Store.albums(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(28), 0, 0)
        }
        val content = FrameLayout(this)
        pages = listOf(pageHome(), pageAlbum(), pageAdd(), pageGame(), pageSettings())
        pages.forEach { content.addView(it) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(navBar())
        setContentView(root)
        show(0)
    }

    override fun onResume() {
        super.onResume()
        albums = Store.albums(this)
        if (view >= albums.size) view = 0
        rebuildChips(); refresh(); buildPerms(); updateCache(); updateGame()
        ui.post(poll)
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    // ---------- util ----------
    private fun cmd(a: String, f: (Intent) -> Unit = {}) {
        if (!PlayerState.running) return
        startService(Intent(this, OverlayService::class.java).setAction(a).also(f))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun active() = Store.int(this, "album", 0).coerceIn(0, maxOf(0, albums.size - 1))

    private fun scroll(vararg v: View): ScrollView = ScrollView(this).apply {
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12))
            v.forEach { addView(it) }
        })
    }

    private fun label(s: String, size: Float = 14f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun field(hint: String, lines: Int = 1) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 14f
        background = rounded(CARD, 14, Color.parseColor("#3300E5FF"))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (lines > 1) { minLines = lines; gravity = Gravity.TOP }
    }

    private fun gap(h: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(h)) }

    private fun circle(label: String, size: Int, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER
        textSize = if (primary) 26f else 20f
        setTextColor(if (primary) BG else Color.WHITE)
        background = oval(if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"), if (primary) Color.WHITE else Color.parseColor("#33FFFFFF"))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener { onClick() }
    }

    private fun mini(s: String, onClick: () -> Unit) = TextView(this).apply {
        text = s; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
        background = rounded(CARD, 14, Color.parseColor("#3300E5FF"))
        setPadding(0, dp(11), 0, dp(11))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun askText(title: String, init: String, ok: (String) -> Unit) {
        val e = field("Nama album").apply { setText(init); isSingleLine = true }
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("OK") { _, _ -> val s = e.text.toString().trim(); if (s.isNotEmpty()) ok(s) }
            .setNegativeButton("Batal", null).show()
    }

    private fun deleteFile(t: Track) {
        if (t.kind == "file") try { File(Uri.parse(t.src).path ?: "").delete() } catch (_: Exception) {}
    }

    // simpan perubahan album + kasih tau player kalau album itu lagi dipakai
    private fun persist(ai: Int = view) {
        Store.saveAlbums(this, albums)
        refresh(); rebuildChips()
        if (ai == active()) cmd("RELOAD")
    }

    // ---------- chip album ----------
    private fun chipBar(home: Boolean): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        chipRows.add(Pair(row, home))
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun rebuildChips() {
        chipRows.forEach { (row, home) ->
            row.removeAllViews()
            val sel = if (home) active() else view
            albums.forEachIndexed { i, a ->
                row.addView(TextView(this).apply {
                    text = "${a.emoji} ${a.name}"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9))
                    if (i == sel) { setTextColor(Color.WHITE); background = rounded(CYAN, 18, 0, PINK) }
                    else { setTextColor(MUTED); background = rounded(CARD, 18) }
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
                    setOnClickListener {
                        if (home) selectAlbum(i) else { view = i; filter = ""; rebuildChips(); refresh() }
                    }
                })
            }
        }
    }

    // pilih album yang dimainkan (Home)
    private fun selectAlbum(i: Int) {
        Store.putInt(this, "album", i); Store.putInt(this, "last", 0)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", 0) }
        else toast("Album ${albums[i].name} dipilih")
    }

    private fun playAlbum(i: Int) {
        Store.putInt(this, "album", i); Store.putInt(this, "last", 0)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", 0) } else startFloating(0)
    }

    private fun playTrack(ai: Int, i: Int) {
        Store.putInt(this, "album", ai); Store.putInt(this, "last", i)
        rebuildChips()
        if (PlayerState.running) cmd("ALBUM") { it.putExtra("idx", i) } else startFloating(i)
    }

    // ---------- navbar ----------
    private fun navBar(): LinearLayout {
        val items = listOf("⌂\nHome", "♫\nAlbum", "+\nTambah", "◈\nGame", "⚙\uFE0E\nSetelan")
        tabs = items.mapIndexed { i, s ->
            TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(8))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { show(i) }
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD, 28, Color.parseColor("#2200E5FF"))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(6), dp(12), dp(14)) }
            tabs.forEach { addView(it) }
        }
    }

    private fun show(n: Int) {
        page = n
        pages.forEachIndexed { i, p -> p.visibility = if (i == n) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, t ->
            if (i == n) { t.setTextColor(Color.WHITE); t.background = rounded(CYAN, 22, 0, PINK) }
            else { t.setTextColor(MUTED); t.background = null }
        }
    }

    // ================= HOME =================
    private fun pageHome(): View {
        hTitle = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(14), 0, dp(2))
        }
        hSub = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.CENTER }
        hTime = TextView(this).apply { textSize = 11f; setTextColor(Color.parseColor("#DDFFFFFF")); gravity = Gravity.END }
        hSeek = SeekBar(this).apply {
            max = 1000; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    val f = (s?.progress ?: 0) / 1000f
                    cmd("SEEK") { it.putExtra("f", f) }
                }
            })
        }
        hPlay = circle("▶\uFE0E", 72, true) {
            if (PlayerState.running) cmd("TOGGLE") else startFloating(Store.int(this, "last", 0))
        }
        val art = TextView(this).apply {
            text = "♫"; textSize = 52f; gravity = Gravity.CENTER
            background = oval(Color.parseColor("#33FFFFFF"), Color.parseColor("#22FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            addView(circle("|◀", 52, false) { cmd("PREV") })
            addView(hPlay)
            addView(circle("▶\uFE0E|", 52, false) { cmd("NEXT") })
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#00B8D4"), PURPLE, PINK)
            ).apply { cornerRadius = dp(30).toFloat() }
            setPadding(dp(20), dp(26), dp(20), dp(20))
            addView(art); addView(hTitle); addView(hSub); addView(gap(8)); addView(hSeek); addView(hTime); addView(controls)
        }
        hPower = pill("▶\uFE0E  Nyalakan Floating Player", CYAN, PINK) {
            if (PlayerState.running) cmd("STOP") else startFloating(Store.int(this, "last", 0))
        }
        hWarn = label("[!] Izin \"Tampil di atas aplikasi lain\" belum aktif. Tap tombol di atas buat ngatur.", 12f, PINK)
        return scroll(
            label("FF Music", 26f, Color.WHITE, true),
            label("Pilih suasana, lalu gas main", 13f, MUTED),
            chipBar(true),
            gap(), card, gap(14), hPower,
            gap(8), pill("◈  MODE GAME — boost + musik + buka game", PINK, PURPLE) { gameMode() },
            hWarn,
            label("Tips: tap bubble ♫ di game buat buka kontrol, geser buat pindahin, ◎ buat sembunyiin total.", 12f, MUTED)
        )
    }

    private fun updateHome() {
        if (!::hTitle.isInitialized) return
        val run = PlayerState.running
        val a = albums.getOrNull(active())
        val n = a?.tracks?.size ?: 0
        val an = if (a != null) "${a.emoji} ${a.name}" else ""
        hTitle.text = if (run && PlayerState.title.isNotEmpty()) PlayerState.title else "Belum ada lagu diputar"
        hSub.text = if (run) "${if (PlayerState.playing) "Sedang diputar" else "Dijeda"} • $an • lagu ${PlayerState.idx + 1}/$n"
        else "Album $an • $n lagu"
        hPlay.text = if (PlayerState.playing) "❚❚" else "▶\uFE0E"
        hPower.text = if (run) "■  Matikan Floating Player" else "▶\uFE0E  Nyalakan Floating Player"
        hWarn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        if (!seeking) {
            hSeek.progress = if (PlayerState.dur > 0) (PlayerState.pos * 1000 / PlayerState.dur).toInt() else 0
            hTime.text = if (run) "${fmt(PlayerState.pos)} / ${fmt(PlayerState.dur)}" else "0:00 / 0:00"
        }
    }

    private fun startFloating(i: Int, intro: Array<String>? = null) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan 'Tampil di atas aplikasi lain' dulu, lalu balik & tekan lagi")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        if (Store.activeTracks(this).isEmpty()) { toast("Album kosong, tambah lagu dulu"); return }
        startForegroundService(Intent(this, OverlayService::class.java).setAction("START").putExtra("idx", i)
            .also { if (intro != null) it.putExtra("intro", intro) })
        toast("Nyala! Buka game kamu")
    }

    // ================= ALBUM =================
    private fun pageAlbum(): View {
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        countTv = label("", 12f, MUTED)
        albumTitle = label("", 20f, Color.WHITE, true)
        val search = field("Cari di album ini")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filter = s?.toString()?.trim() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(mini("＋ Baru") { newAlbum() })
            addView(mini("✎ Nama") { renameAlbum() })
            addView(mini("⇪ Bagikan") { shareAlbum() })
            addView(mini("✕ Hapus") { deleteAlbum() })
        }
        return scroll(
            label("Album ♫", 26f, Color.WHITE, true),
            label("Kelompokin lagu sesuai suasana: santai, bantai, dll.", 12f, MUTED),
            chipBar(false), gap(4), actions, gap(6),
            albumTitle, search, countTv, gap(4),
            pill("▶\uFE0E  Putar album ini", CYAN, PINK) { playAlbum(view) }, gap(), listBox
        )
    }

    private fun kindLabel(k: String) = when (k) {
        "query" -> "Cari otomatis • cache offline"
        "yt" -> "YouTube • cache offline"
        "file" -> "File di dalam app"
        else -> "Link audio • cache offline"
    }

    private fun refresh() {
        if (!::listBox.isInitialized) return
        val a = albums.getOrNull(view) ?: return
        listBox.removeAllViews()
        albumTitle.text = "${a.emoji} ${a.name}"
        val shown = a.tracks.withIndex().filter { filter.isEmpty() || it.value.title.contains(filter, true) }
        countTv.text = "${a.tracks.size} lagu" + (if (filter.isNotEmpty()) " • ${shown.size} cocok" else "") + " • tap lagu buat muter"
        if (shown.isEmpty()) listBox.addView(label("Kosong. Tambah lagu di tab +", 13f, MUTED))
        shown.forEach { (i, t) ->
            val playing = PlayerState.running && PlayerState.album == view && PlayerState.idx == i
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, 18, if (playing) CYAN else 0)
                setPadding(dp(12), dp(10), dp(4), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                setOnClickListener { playTrack(view, i) }
            }
            row.addView(TextView(this).apply {
                text = if (playing) "♫" else "${i + 1}"; gravity = Gravity.CENTER; textSize = 13f
                setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                background = oval(CYAN, PINK)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(12) }
            })
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(TextView(context).apply { text = t.title; setTextColor(Color.WHITE); textSize = 14f; maxLines = 2 })
                addView(TextView(context).apply { text = kindLabel(t.kind); setTextColor(MUTED); textSize = 10.5f })
            })
            row.addView(TextView(this).apply {
                text = "⋮"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(4), dp(14), dp(4))
                setOnClickListener { trackMenu(i) }
            })
            listBox.addView(row)
        }
    }

    private fun trackMenu(i: Int) {
        val a = albums.getOrNull(view) ?: return
        val t = a.tracks.getOrNull(i) ?: return
        val items = arrayOf("▶\uFE0E  Putar", "⇄  Pindah ke album lain", "▲  Naik", "▼  Turun", "✕  Hapus")
        AlertDialog.Builder(this).setTitle(t.title).setItems(items) { _, w ->
            when (w) {
                0 -> playTrack(view, i)
                1 -> moveDialog(i)
                2 -> if (i > 0) { Collections.swap(a.tracks, i, i - 1); persist() }
                3 -> if (i < a.tracks.size - 1) { Collections.swap(a.tracks, i, i + 1); persist() }
                4 -> { deleteFile(t); a.tracks.removeAt(i); persist() }
            }
        }.show()
    }

    private fun moveDialog(i: Int) {
        val names = albums.map { "${it.emoji} ${it.name}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pindah ke album…").setItems(names) { _, k ->
            if (k != view) {
                val from = view
                val t = albums[from].tracks.removeAt(i)
                albums[k].tracks.add(t)
                Store.saveAlbums(this, albums)
                refresh()
                cmd("RELOAD")
                toast("Dipindah ke ${albums[k].name}")
            }
        }.show()
    }

    private fun newAlbum() {
        askText("Album baru", "") { name ->
            albums.add(Album(name.take(30), emojis[albums.size % emojis.size]))
            view = albums.size - 1; filter = ""
            persist()
        }
    }

    private fun renameAlbum() {
        val a = albums.getOrNull(view) ?: return
        askText("Ganti nama album", a.name) { name -> a.name = name.take(30); persist() }
    }

    private fun deleteAlbum() {
        if (albums.size <= 1) { toast("Minimal harus ada 1 album"); return }
        val a = albums.getOrNull(view) ?: return
        AlertDialog.Builder(this).setTitle("Hapus album ${a.name}?")
            .setMessage("${a.tracks.size} lagu di dalamnya ikut terhapus.")
            .setPositiveButton("Hapus") { _, _ ->
                a.tracks.forEach { deleteFile(it) }
                val idx = view
                val act = active()
                albums.removeAt(idx)
                val na = if (idx == act) 0 else if (idx < act) act - 1 else act
                Store.putInt(this, "album", na)
                Store.saveAlbums(this, albums)
                view = 0
                if (PlayerState.running) {
                    if (idx == act) cmd("ALBUM") { it.putExtra("idx", 0) } else cmd("RELOAD")
                }
                rebuildChips(); refresh()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun shareAlbum() {
        val a = albums.getOrNull(view) ?: return
        val n = a.tracks.count { it.kind != "file" }
        if (n == 0) { toast("Gak ada lagu yang bisa dibagikan (file upload gak ikut)"); return }
        val msg = "Album \"${a.name}\" dari FF Music ($n lagu)\n" +
            "Buka FF Music → tab Tambah → Impor album, lalu tempel kode ini:\n\n${Store.export(a)}\n\n" +
            "Download app: $APP_URL"
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Bagikan album"
        ))
        if (n < a.tracks.size) toast("File upload gak ikut dibagikan")
    }

    private fun importDialog() {
        val e = field("Tempel kode album di sini (ffm1:…)", 4)
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this).setTitle("Impor album dari teman").setView(box)
            .setPositiveButton("Impor") { _, _ ->
                val a = Store.importCode(e.text.toString())
                if (a == null) toast("Kode gak valid")
                else {
                    albums.add(a); view = albums.size - 1; filter = ""
                    persist()
                    toast("Album ${a.name} masuk • ${a.tracks.size} lagu")
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    // ================= TAMBAH =================
    private fun pageAdd(): View {
        resBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val q = field("Cari lagu / artis")
        val one = field("Judul lagu atau link (mp3 / YouTube)")
        val bulk = field("Tulis daftar judul, 1 baris 1 lagu.\nContoh:\nDecember - Neck Deep\nWish You Were Here - Neck Deep", 6)
        return scroll(
            label("Tambah Lagu +", 26f, Color.WHITE, true),
            label("Masuk ke album:", 12f, MUTED), chipBar(false), gap(4),
            label("Cari lagu", 15f, Color.WHITE, true), q, gap(6),
            pill("Cari", CYAN, PINK) { doSearch(q.text.toString()) }, resBox, gap(),
            label("Tulis judul / tempel link", 15f, Color.WHITE, true), one, gap(6),
            pill("+  Tambah", CYAN, PINK) {
                parse(one.text.toString())?.let { addTracks(listOf(it)); one.setText("") }
            }, gap(),
            pill("↑  Upload audio dari HP", PINK, PURPLE) { pick() },
            gap(), label("Tambah banyak sekaligus", 15f, Color.WHITE, true), bulk, gap(6),
            pill("≡  Tambah semua", PURPLE, CYAN) {
                addTracks(bulk.text.toString().lines().mapNotNull { parse(it) })
                bulk.setText("")
            },
            gap(), pill("⇩  Impor album dari teman", PINK, PURPLE) { importDialog() }
        )
    }

    private fun doSearch(q: String) {
        val s = q.trim()
        if (s.isEmpty()) return
        resBox.removeAllViews()
        resBox.addView(label("Mencari…", 12f, MUTED))
        Thread {
            val hits = Resolver.search(s)
            runOnUiThread { showHits(hits) }
        }.start()
    }

    private fun showHits(hits: List<Resolver.Hit>) {
        resBox.removeAllViews()
        if (hits.isEmpty()) {
            resBox.addView(label("Gak ada hasil / server lagi down. Coba lagi, atau isi server sendiri di Setelan.", 12f, PINK))
            return
        }
        val ti = view
        hits.forEach { h ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, 16)
                setPadding(dp(14), dp(8), dp(6), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            }
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(TextView(context).apply { text = h.title; setTextColor(Color.WHITE); textSize = 13f; maxLines = 2 })
                addView(TextView(context).apply { text = h.by; setTextColor(MUTED); textSize = 11f })
            })
            val add = TextView(this)
            add.text = "＋"; add.setTextColor(CYAN); add.textSize = 22f; add.gravity = Gravity.CENTER
            add.setPadding(dp(14), dp(4), dp(14), dp(4))
            add.setOnClickListener {
                val a = albums.getOrNull(ti)
                if (a != null) {
                    if (a.tracks.any { it.src == h.id }) toast("Sudah ada di ${a.name}")
                    else {
                        a.tracks.add(Track(h.title, h.id, "yt"))
                        persist(ti)
                        add.text = "✓"
                        toast("Masuk ke ${a.emoji} ${a.name}")
                    }
                }
            }
            row.addView(add)
            resBox.addView(row)
        }
    }

    private fun parse(s: String): Track? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val yt = Regex("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").find(t)
        return when {
            t.startsWith("http") && yt != null -> Track("YouTube ${yt.groupValues[1]}", yt.groupValues[1], "yt")
            t.startsWith("http") -> Track(Uri.parse(t).lastPathSegment ?: t, t, "url")
            else -> Track(t, t, "query")
        }
    }

    private fun addTracks(new: List<Track>) {
        val ti = view
        val a = albums.getOrNull(ti) ?: return
        val fresh = new.filter { n -> a.tracks.none { it.src == n.src } }
        if (fresh.isEmpty()) { toast("Kosong / sudah ada di album ini"); return }
        val slow = fresh.filter { it.kind == "url" || it.kind == "yt" }
        a.tracks.addAll(fresh.filter { it !in slow })
        persist(ti)
        if (slow.isEmpty()) { toast("Tersimpan di ${a.name}"); return }
        toast("Proses ${slow.size} link…")
        Thread {
            val done = slow.map {
                if (it.kind == "url") download(it) else Track(Resolver.ytTitle(it.src) ?: it.title, it.src, "yt")
            }
            runOnUiThread {
                albums.getOrNull(ti)?.tracks?.addAll(done)
                persist(ti)
                val bad = done.count { it.kind == "url" }
                if (bad > 0) toast("$bad link bukan file audio langsung, disimpan sebagai link") else toast("Tersimpan")
            }
        }.start()
    }

    // link audio langsung (mp3/m4a/dll) -> diunduh & disimpan di dalam app
    private fun download(t: Track): Track {
        try {
            val c = URL(t.src).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val ct = c.contentType ?: ""
            if (!ct.startsWith("audio") && !ct.contains("octet-stream")) return t
            val dir = File(filesDir, "songs").apply { mkdirs() }
            val base = (Uri.parse(t.src).lastPathSegment ?: "audio").replace(Regex("[^A-Za-z0-9._-]"), "_")
            val out = File(dir, "${System.currentTimeMillis()}_$base")
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            return Track(t.title.substringBeforeLast('.'), Uri.fromFile(out).toString(), "file")
        } catch (_: Exception) {
            return t
        }
    }

    private fun pick() {
        pickTi = view
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req != 1 || res != RESULT_OK || d == null) return
        val ti = pickTi
        val uris = mutableListOf<Uri>()
        d.data?.let { uris.add(it) }
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        toast("Nyalin ${uris.size} file ke dalam app…")
        Thread {
            val dir = File(filesDir, "songs").apply { mkdirs() }
            val added = mutableListOf<Track>()
            uris.forEach { u ->
                try {
                    var name = u.lastPathSegment ?: "Audio"
                    contentResolver.query(u, null, null, null, null)?.use { c ->
                        val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (k >= 0 && c.moveToFirst()) name = c.getString(k)
                    }
                    val out = File(dir, "${System.currentTimeMillis()}_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(u)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    added.add(Track(name.substringBeforeLast('.'), Uri.fromFile(out).toString(), "file"))
                } catch (_: Exception) {}
            }
            runOnUiThread {
                albums.getOrNull(ti)?.tracks?.addAll(added)
                persist(ti)
                toast("Tersimpan")
            }
        }.start()
    }

    // ================= GAME / BOOSTER =================
    private fun toggleRow(text: String, key: String, def: Boolean, after: () -> Unit = {}): TextView {
        val v = TextView(this)
        fun on() = Store.int(this, key, if (def) 1 else 0) == 1
        fun paint() {
            v.text = (if (on()) "●  " else "○  ") + text
            v.setTextColor(if (on()) Color.WHITE else MUTED)
            v.background = rounded(CARD, 14, if (on()) CYAN else 0)
        }
        v.textSize = 13f
        v.setPadding(dp(14), dp(12), dp(14), dp(12))
        v.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        v.setOnClickListener {
            Store.putInt(this, key, if (on()) 0 else 1)
            paint(); after()
        }
        paint()
        return v
    }

    private fun pageGame(): View {
        gGame = label("", 14f, Color.WHITE, true)
        gStats = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE)
            background = rounded(CARD, 18, Color.parseColor("#3300E5FF"))
            setPadding(dp(16), dp(14), dp(16), dp(14)); setLineSpacing(0f, 1.2f)
        }
        gResult = label("", 12f, MUTED)
        dndBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        return scroll(
            label("Game ◈", 26f, Color.WHITE, true),
            label("Satu tombol: boost HP, nyalain musik, langsung buka game.", 12f, MUTED),
            gap(), pill("◈  MODE GAME — Mulai Main", PINK, PURPLE) { gameMode() },
            gap(14), label("Game yang dibuka", 15f, Color.WHITE, true), gGame,
            pill("Pilih game", CYAN, PINK) { pickGame() },
            gap(14), label("Status HP", 15f, Color.WHITE, true), gStats, gap(6),
            pill("➤  Boost HP sekarang", PURPLE, CYAN) { boostNow() }, gResult,
            label("Boost = nutup app yang masih jalan di background biar RAM lega. Gak bisa naikin spek HP, tapi game jadi lebih lega & minim lag.", 11f, MUTED),
            gap(10), label("Opsi Mode Game", 15f, Color.WHITE, true),
            toggleRow("Boost otomatis pas Mode Game", "boost", true),
            toggleRow("Jangan Ganggu otomatis (bungkam telepon, chat & notif)", "dnd", true),
            label("Level Jangan Ganggu", 13f, MUTED),
            chips(listOf("Total (telepon juga)", "Telepon boleh"), { Store.int(this, "dndlvl", 0) }) {
                Store.putInt(this, "dndlvl", it)
            },
            gap(6),
            toggleRow("Animasi MODE GAME pas aktif", "intro", true),
            dndBox,
            toggleRow("Layar tetap nyala pas floating aktif", "awake", true) { cmd("APPLY") },
            toggleRow("Info baterai, suhu & RAM di floating", "hud", true) { cmd("APPLY") },
            gap(10), label("Biar makin ngebut", 15f, Color.WHITE, true),
            label("• Matikan Hemat Baterai & aktifkan Mode Performa di setelan HP\n• Tutup app berat (browser, sosmed) sebelum main\n• Colok charger kalau HP mulai panas, lepas casing\n• Pakai wifi/data yang stabil, cegah delay ping", 12f, MUTED)
        )
    }

    private fun updateGame() {
        if (!::gStats.isInitialized) return
        val b = Booster.battery(this)
        gStats.text = "RAM bebas     ${Booster.availMb(this)} MB / ${Booster.totalMb(this)} MB\n" +
            "Baterai         ${b.pct}%\nSuhu              ${"%.1f".format(b.temp)}°C"
        gGame.text = Store.str(this, "gamename") ?: "Belum dipilih"
    }

    private fun pickGame() {
        val apps = Booster.launchables(this)
        if (apps.isEmpty()) { toast("Gak ada app yang bisa dipilih"); return }
        AlertDialog.Builder(this).setTitle("Pilih game").setItems(apps.map { it.first }.toTypedArray()) { _, w ->
            Store.putStr(this, "game", apps[w].second)
            Store.putStr(this, "gamename", apps[w].first)
            updateGame()
        }.show()
    }

    private fun boostNow() {
        gResult.text = "Membersihkan…"
        val keep = setOfNotNull(Store.str(this, "game"))
        Thread {
            val r = Booster.clean(this, keep)
            runOnUiThread {
                gResult.text = "✓ +${r.freed} MB RAM lega • ${r.killed} app di background dibersihkan"
                updateGame()
            }
        }.start()
    }

    private fun gameMode() {
        if (!Settings.canDrawOverlays(this)) { startFloating(0); return }
        val pkg = Store.str(this, "game")
        if (pkg == null) { toast("Pilih game dulu"); show(3); pickGame(); return }
        if (Store.activeTracks(this).isEmpty()) { toast("Album kosong, tambah lagu dulu"); return }
        val wantDnd = Store.int(this, "dnd", 1) == 1
        if (wantDnd && !Booster.dndGranted(this)) {
            toast("Izinkan akses Jangan Ganggu dulu, lalu tekan Mode Game lagi")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        toast("Menyiapkan Mode Game…")
        val doBoost = Store.int(this, "boost", 1) == 1
        Thread {
            val r = if (doBoost) Booster.clean(this, setOf(pkg)) else null
            runOnUiThread {
                val dndOn = wantDnd && Booster.dndGranted(this)
                if (dndOn) Booster.dndOn(this)
                val lines = ArrayList<String>()
                if (r != null) lines.add("BOOST RAM +${r.freed} MB")
                if (dndOn) lines.add(
                    if (Store.int(this, "dndlvl", 0) == 0) "SEMUA TELEPON & CHAT DIBUNGKAM"
                    else "CHAT & NOTIF DIBUNGKAM, TELEPON BOLEH"
                )
                lines.add("MUSIK: ${albums.getOrNull(active())?.name ?: ""}")
                val intro: Array<String>? = if (Store.int(this, "intro", 1) == 1) lines.toTypedArray() else null
                if (PlayerState.running) {
                    if (intro != null) cmd("INTRO") { it.putExtra("intro", intro) }
                } else startFloating(Store.int(this, "last", 0), intro)
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else toast("Game gak ketemu, pilih ulang di tab Game")
            }
        }.start()
    }

    // ================= SETELAN =================
    private fun chips(opts: List<String>, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        fun paint() {
            views.forEachIndexed { i, v ->
                if (i == get()) { v.setTextColor(Color.WHITE); v.background = rounded(CYAN, 16, 0, PINK) }
                else { v.setTextColor(MUTED); v.background = rounded(CARD, 16) }
            }
        }
        opts.forEachIndexed { i, s ->
            val v = TextView(this).apply {
                text = s; gravity = Gravity.CENTER; textSize = 13f; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
                setOnClickListener { set(i); paint() }
            }
            views.add(v); row.addView(v)
        }
        paint()
        return row
    }

    private fun pageSettings(): View {
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cacheTv = label("", 13f, Color.WHITE)
        sleepTv = label("", 12f, CYAN)
        val opacity = SeekBar(this).apply {
            max = 70; progress = Store.int(this@MainActivity, "opacity", 100) - 30; tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@MainActivity, "opacity", p + 30); cmd("APPLY") }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val vol = SeekBar(this).apply {
            max = 100; progress = Store.int(this@MainActivity, "vol", 100); tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { Store.putInt(this@MainActivity, "vol", p); cmd("APPLY") }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val host = field("https://pipedapi.contoh.com (opsional)")
        host.setText(Store.str(this, "host") ?: "")
        host.isSingleLine = true
        return scroll(
            label("Setelan ⚙\uFE0E", 26f, Color.WHITE, true),
            label("Mode putar", 15f, Color.WHITE, true),
            chips(listOf("↻ Semua", "↻1 Satu", "⇄ Acak"), { Store.int(this, "repeat", 0) }) {
                Store.putInt(this, "repeat", it); cmd("APPLY")
            },
            gap(), label("Volume musik (biar suara game tetap kedengeran)", 15f, Color.WHITE, true), vol,
            gap(), label("Equalizer", 15f, Color.WHITE, true),
            chips(listOf("Normal", "Bass", "Vokal", "Treble"), { Store.int(this, "eq", 0) }) {
                Store.putInt(this, "eq", it); cmd("APPLY")
            },
            gap(6), label("Suara", 13f, MUTED),
            chips(listOf("Normal", "Kenceng+"), { Store.int(this, "loud", 0) }) {
                Store.putInt(this, "loud", it); cmd("APPLY")
            },
            gap(), label("Timer tidur (berhenti otomatis)", 15f, Color.WHITE, true),
            chips(listOf("Mati", "15 mnt", "30 mnt", "60 mnt"), { Store.int(this, "sleepsel", 0) }) {
                Store.putInt(this, "sleepsel", it); cmd("SLEEP")
            },
            sleepTv,
            gap(), label("Ukuran bubble", 15f, Color.WHITE, true),
            chips(listOf("Kecil", "Sedang", "Besar"), { Store.int(this, "size", 1) }) {
                Store.putInt(this, "size", it); cmd("APPLY")
            },
            gap(), label("Transparansi floating", 15f, Color.WHITE, true), opacity,
            gap(), label("Izin & status", 15f, Color.WHITE, true), permBox,
            gap(), label("Cache lagu", 15f, Color.WHITE, true), cacheTv,
            label("Lagu yang pernah diputar disimpan di HP, jadi putar ulang bisa tanpa kuota.", 11f, MUTED),
            pill("Hapus cache", Color.parseColor("#33334D"), Color.parseColor("#33334D")) {
                if (PlayerState.running) toast("Matikan floating player dulu")
                else { File(cacheDir, "media").deleteRecursively(); updateCache(); toast("Cache dihapus") }
            },
            gap(), label("Server pencari lagu (opsional)", 15f, Color.WHITE, true),
            label("Kalau lagu sering gak ketemu, tempel alamat server Piped yang masih hidup.", 11f, MUTED),
            host, gap(6),
            pill("Simpan server", PURPLE, CYAN) {
                val h = host.text.toString().trim().trimEnd('/')
                Store.putStr(this, "host", h)
                Resolver.custom = h.ifEmpty { null }
                toast(if (h.isEmpty()) "Pakai server bawaan" else "Server disimpan")
            },
            gap(), pill("⇪  Bagikan app ke teman", CYAN, PINK) {
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "FF Music — player musik floating buat main game\nDownload: $APP_URL"),
                    "Bagikan app"
                ))
            },
            gap(16), label("FF Music v$VERSION • by Asep", 11f, MUTED)
        )
    }

    private fun updateSettings() {
        if (!::sleepTv.isInitialized) return
        val left = PlayerState.sleepAt - System.currentTimeMillis()
        sleepTv.text = if (PlayerState.running && PlayerState.sleepAt > 0 && left > 0) "Berhenti sekitar ${left / 60000 + 1} menit lagi" else ""
    }

    private fun permRow(text: String, ok: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = (if (ok) "✓  " else "✕  ") + text
        setTextColor(if (ok) Color.WHITE else PINK); textSize = 13f
        background = rounded(CARD, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun buildPerms() {
        if (!::permBox.isInitialized) return
        permBox.removeAllViews()
        permBox.addView(permRow("Tampil di atas aplikasi lain", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        permBox.addView(permRow("Notifikasi", notifOk) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        })
        val pm = getSystemService(PowerManager::class.java)
        permBox.addView(permRow("Baterai tanpa batasan (biar gak dimatiin sistem)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        val dnd = Booster.dndGranted(this)
        permBox.addView(permRow("Akses Jangan Ganggu (buat Mode Game)", dnd) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        if (::dndBox.isInitialized) {
            dndBox.removeAllViews()
            if (!dnd) dndBox.addView(permRow("Izinkan akses Jangan Ganggu dulu (tap di sini)", false) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            })
        }
    }

    private fun updateCache() {
        if (!::cacheTv.isInitialized) return
        val mb = File(cacheDir, "media").walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1048576.0
        cacheTv.text = "%.1f MB terpakai (maks 300 MB)".format(mb)
    }
}
