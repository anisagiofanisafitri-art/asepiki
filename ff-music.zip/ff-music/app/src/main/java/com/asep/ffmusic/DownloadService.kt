package com.asep.ffmusic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.app.ServiceCompat
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

// Daftar unduhan (dibaca UI buat nampilin progress)
object Downloads {
    @Volatile var gen = 0          // naik kalau semua unduhan dibatalkan
    @Volatile var version = 0      // naik tiap ada yang selesai/gagal (UI refresh daftar offline)
    val jobs = CopyOnWriteArrayList<Job>()

    // kind: "link" (YouTube/TikTok/link video, diunduh sesuai kualitas) atau "copy" (salin video dari HP ke dalam app)
    class Job(val title: String, val kind: String, val src: String, val height: Int) {
        val myGen = gen
        @Volatile var percent = 0
        @Volatile var status = "Antri"
        @Volatile var shown = ""
        @Volatile var queued = false
        @Volatile var done = false
        @Volatile var failed = false
        val tmp = CopyOnWriteArrayList<File>()   // file setengah jadi, dihapus kalau gagal
    }

    fun active(): List<Job> = jobs.filter { !it.done && !it.failed }

    fun summary(): String {
        val a = active()
        if (a.isEmpty()) return ""
        val j = a.first()
        return "${j.status} ${j.percent}% • ${j.title.take(40)}" + if (a.size > 1) "  (+${a.size - 1} antri)" else ""
    }

    fun enqueue(c: Context, j: Job) {
        jobs.removeAll { it.done || it.failed }
        jobs.add(j)
        c.startForegroundService(Intent(c, DownloadService::class.java).setAction("ADD"))
    }

    fun cancelAll() {
        gen++
        jobs.filter { !it.done }.forEach { it.failed = true; it.status = "Dibatalkan" }
        version++
    }
}

// Unduh video ke dalam app (foreground service, jalan terus walau layar mati / app ditutup)
class DownloadService : Service() {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var pending = 0
    private var okCount = 0
    private var failCount = 0
    private var lastNotif = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ffm_dl", "Unduhan video", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, 2, notif("Menyiapkan unduhan…", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        when (i?.action) {
            "CANCEL" -> {
                Downloads.cancelAll()
                if (pending <= 0) finishAll()
            }
            "ADD" -> {
                if (wake == null) {
                    wake = getSystemService(PowerManager::class.java)
                        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ffm:dl")
                        .apply { setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L) }
                }
                Downloads.jobs.filter { !it.queued && !it.done && !it.failed }.forEach { j ->
                    j.queued = true
                    pending++
                    io.execute { process(j) }
                }
                if (pending <= 0) finishAll()
            }
            else -> if (pending <= 0) finishAll()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        io.shutdownNow()
        try { wake?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun notif(text: String, pct: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction("CANCEL"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, "ffm_dl")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("FF Music • Simpan video offline")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Batal", cancel)
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun progress(j: Downloads.Job) {
        val now = System.currentTimeMillis()
        if (now - lastNotif < 600) return
        lastNotif = now
        getSystemService(NotificationManager::class.java)
            .notify(2, notif("${j.status} ${j.percent}% • ${j.title.take(40)}", j.percent))
    }

    private fun finishAll() {
        try { wake?.release() } catch (_: Throwable) {}
        wake = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (okCount + failCount > 0) {
            val open = PendingIntent.getActivity(
                this, 2, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            getSystemService(NotificationManager::class.java).notify(
                3,
                Notification.Builder(this, "ffm_dl")
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("FF Music")
                    .setContentText("$okCount video tersimpan offline" + if (failCount > 0) ", $failCount gagal" else "")
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
            )
        }
        okCount = 0
        failCount = 0
        stopSelf()
    }

    private fun ensureAlive(j: Downloads.Job) {
        if (j.myGen != Downloads.gen) throw IllegalStateException("Dibatalkan")
    }

    private fun process(j: Downloads.Job) {
        var error: String? = null
        try {
            ensureAlive(j)
            j.status = "Mengunduh"
            if (j.kind == "copy") copyJob(j) else linkJob(j)
            j.percent = 100
            j.status = "Selesai"
            j.done = true
        } catch (e: Exception) {
            error = if (j.myGen != Downloads.gen) "Dibatalkan" else (e.message ?: "gagal")
            j.failed = true
            j.status = "Gagal"
            j.tmp.forEach { try { it.delete() } catch (_: Exception) {} }
        }
        Downloads.version++
        ui.post {
            if (error == null) {
                okCount++
                Toast.makeText(this, "Tersimpan offline: ${j.shown.ifEmpty { j.title }.take(50)}", Toast.LENGTH_SHORT).show()
            } else {
                failCount++
                if (error != "Dibatalkan") Toast.makeText(this, "Gagal simpan: $error", Toast.LENGTH_LONG).show()
            }
            pending--
            if (pending <= 0) finishAll()
        }
    }

    private fun needSpace(total: Long) {
        if (total > 0 && total + 150L * 1024 * 1024 > filesDir.usableSpace) {
            throw IllegalStateException("Memori HP gak cukup (butuh ${fmtSize(total)})")
        }
    }

    // ---------- link: YouTube / TikTok / link video ----------
    private fun linkJob(j: Downloads.Job) {
        j.status = "Ambil link"
        val want = if (j.height > 0) j.height else 1080
        val r = VideoResolver.resolve(this, j.src, want)
        val s = r.streams[VideoResolver.pick(r.streams, want)]
        if (s.hls) throw IllegalStateException("Siaran live / HLS belum bisa disimpan")
        val dir = File(filesDir, "videos").apply { mkdirs() }
        val id = System.currentTimeMillis()
        val vf = File(dir, "${id}_v.mp4")
        val audioUrl = s.audioUrl
        val af = if (audioUrl != null) File(dir, "${id}_a.m4a") else null
        j.tmp.add(vf)
        af?.let { j.tmp.add(it) }
        j.shown = "${r.title} • ${s.label}"
        j.status = "Mengunduh ${s.label}"
        fetch(j, s.url, vf, 0, if (af != null) 85 else 100)
        if (af != null && audioUrl != null) {
            j.status = "Mengunduh audio"
            fetch(j, audioUrl, af, 85, 100)
        }
        val src = vf.absolutePath + if (af != null) "|" + af.absolutePath else ""
        Store.addSaved(this, VideoItem(j.shown, src, "saved"))
    }

    // unduh per potongan 4 MB (lebih kencang di server YouTube yang nge-throttle + kalau putus ngulang potongan itu aja)
    private fun fetch(j: Downloads.Job, url: String, out: File, p0: Int, p1: Int) {
        val part = File(out.path + ".part")
        j.tmp.add(part)
        var pos = 0L
        var total = -1L
        val chunk = 4L * 1024 * 1024
        var tries = 0
        RandomAccessFile(part, "rw").use { raf ->
            raf.setLength(0)
            while (total < 0 || pos < total) {
                ensureAlive(j)
                try {
                    val con = URL(url).openConnection() as HttpURLConnection
                    con.connectTimeout = 10000
                    con.readTimeout = 20000
                    con.instanceFollowRedirects = true
                    con.setRequestProperty("User-Agent", VideoResolver.UA)
                    con.setRequestProperty("Range", "bytes=$pos-${pos + chunk - 1}")
                    val code = con.responseCode
                    if (code == 416) break
                    if (code != 200 && code != 206) throw IOException("Server nolak (HTTP $code)")
                    if (code == 200) {
                        // server gak dukung Range: unduh penuh sekali jalan
                        raf.setLength(0)
                        raf.seek(0)
                        total = con.contentLengthLong
                        needSpace(total)
                        val n = con.inputStream.use { pump(it, raf, j, 0L, total, p0, p1) }
                        pos = n
                        break
                    }
                    val cr = con.getHeaderField("Content-Range")
                    total = cr?.substringAfter('/')?.toLongOrNull() ?: -1L
                    if (pos == 0L) needSpace(total)
                    raf.seek(pos)
                    val n = con.inputStream.use { pump(it, raf, j, pos, total, p0, p1) }
                    pos += n
                    tries = 0
                    if (n == 0L) break
                    if (total < 0 && n < chunk) break
                } catch (e: IOException) {
                    if (++tries > 3) throw e
                    Thread.sleep(1500)
                }
            }
        }
        if (total > 0 && part.length() < total) throw IllegalStateException("Unduhan terputus")
        if (part.length() <= 0L) throw IllegalStateException("File kosong")
        out.delete()
        if (!part.renameTo(out)) throw IllegalStateException("Gagal menyimpan file")
    }

    // salin stream ke file, update progress, berhenti kalau dibatalkan. Return jumlah byte.
    private fun pump(inp: InputStream, raf: RandomAccessFile, j: Downloads.Job, base: Long, total: Long, p0: Int, p1: Int): Long {
        val buf = ByteArray(64 * 1024)
        var n = 0L
        while (true) {
            ensureAlive(j)
            val r = inp.read(buf)
            if (r < 0) break
            raf.write(buf, 0, r)
            n += r
            if (total > 0) {
                j.percent = p0 + ((base + n) * (p1 - p0) / total).toInt()
                progress(j)
            }
        }
        return n
    }

    // ---------- upload: salin video dari HP ke dalam app ----------
    private fun copyJob(j: Downloads.Job) {
        val uri = Uri.parse(j.src)
        var size = -1L
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) size = c.getLong(0)
            }
        } catch (_: Exception) {}
        needSpace(size)
        val dir = File(filesDir, "videos").apply { mkdirs() }
        val vf = File(dir, "${System.currentTimeMillis()}_v.mp4")
        j.tmp.add(vf)
        j.status = "Menyalin"
        val inp = contentResolver.openInputStream(uri) ?: throw IllegalStateException("File asli gak bisa dibuka")
        inp.use { i ->
            RandomAccessFile(vf, "rw").use { raf ->
                raf.setLength(0)
                pump(i, raf, j, 0L, size, 0, 100)
            }
        }
        if (vf.length() <= 0L) throw IllegalStateException("File kosong")
        j.shown = j.title
        Store.addSaved(this, VideoItem(j.title, vf.absolutePath, "saved"))
    }
}
