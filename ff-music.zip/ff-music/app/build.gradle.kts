plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val baseVersion = rootProject.file("version.txt").takeIf { it.exists() }?.readText()?.trim() ?: "3.3"
val ciRun = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0

android {
    namespace = "com.asep.ffmusic"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.asep.ffmusic"
        minSdk = 26
        targetSdk = 34
        // versionCode naik terus tiap build di GitHub (wajib biar Android mau nimpa app lama)
        versionCode = 100 + ciRun
        versionName = System.getenv("APP_VERSION") ?: "$baseVersion.0"
        // repo GitHub otomatis ikut ke dalam app (buat cek update tanpa setting)
        buildConfigField("String", "UPDATE_REPO", "\"${System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
    }
    buildFeatures { buildConfig = true }
    // KUNCI TANDA TANGAN TETAP: semua build (debug & release, di laptop atau GitHub) pakai kunci yang sama,
    // jadi APK baru bisa menimpa APK lama tanpa error "app not installed / konflik".
    // Kalau kamu punya keystore sendiri, isi secret KEYSTORE_BASE64 di GitHub dan itu yang dipakai.
    signingConfigs {
        create("ffm") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null && File(ks).exists()) {
                storeFile = File(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else {
                storeFile = file("ffmusic.jks")
                storePassword = "ffmusic-store"
                keyAlias = "ffmusic"
                keyPassword = "ffmusic-store"
            }
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("ffm") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("ffm")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-datasource:1.3.1")
    implementation("androidx.media3:media3-database:1.3.1")
}
